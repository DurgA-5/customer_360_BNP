# UniBank MDM

Customer master data management: ingest customer records from Core Banking, Credit Card
and Loan systems, resolve them into one **golden customer**, and serve a Customer 360 view.

```
frontend (React + Vite :5173)
   │  /api/v1/*   (Vite dev proxy)
   ▼
backend (Express :5000) ── Supabase / Postgres   raw_* → golden_customer → bank_account, credit_card, loan, bank_transactions
   │  POST /api/match
   ▼
engine (FastAPI :8000)   matching → grouping → survivorship (stateless)
```

The backend owns all persistence; the engine is pure compute (records in, golden records out).

## Run locally

**1. Database** — `001`–`006` are the team schema. Run **`database/migrations/007_mdm_support.sql`**
once in the Supabase SQL editor (additive, safe to re-run). See `database/README.md`.

**2. Engine**
```bash
cd engine
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
pytest            # API contract tests
```

**3. Backend**
```bash
cd backend
cp .env.example .env    # fill SUPABASE_URL + key
npm install
npm run dev             # http://localhost:5000/api/v1/health
npm test
```

**4. Frontend**
```bash
cd frontend/frontend
npm install
npm run dev             # http://localhost:5173
```

## Try it

1. Admin › Data Ingestion → upload `engine/test_data/core_banking.csv`, then `credit_card.csv`, then `loan.csv`.
2. Admin › Customer Search → search "rahul" → **View 360**: one golden customer with the account, card and loan from all three systems, plus field lineage.
3. Customer portal (`/customer/dashboard`) → create a Core Banking record → you land on your own dashboard, linked to your `GC-` id.

API reference: [`docs/api-contract.md`](docs/api-contract.md).
