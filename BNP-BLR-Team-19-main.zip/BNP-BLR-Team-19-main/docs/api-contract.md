# UniBank MDM — API Contract

Base URL: `http://localhost:5000/api/v1` (the Vite dev server proxies `/api` here).

## Envelope

Every response uses the same shape.

```jsonc
// success
{ "success": true, "data": <payload>, "meta": { ... }?, "message": "..."? }

// failure
{ "success": false, "error": { "code": "BAD_REQUEST", "message": "...", "details": { "field": "reason" }? } }
```

| Status | When |
|---|---|
| 200 / 201 / 202 | OK / created / accepted for background processing |
| 400 | Validation error (`details` maps field → message), bad CSV, bad id |
| 404 | Unknown route or resource |
| 502 | MDM engine unreachable or failed |
| 503 | `/health` when the DB or engine is down |

Customer ids are exposed as `GC-<golden_customer_id>`; endpoints accept `GC-12` or `12`.
Golden ids are **stable** across matching runs.

---

## Health

`GET /health` → `{ api, database: {status, latencyMs}, engine: {status, latencyMs}, uptimeSeconds }`

## Admin

### `GET /admin/dashboard`
```jsonc
{
  "stats":   { "totalCustomers", "recordsProcessed", "duplicatesResolved", "multiSourceCustomers", "dataQuality" },
  "quality": { "overall", "completeness", "duplicateResolution", "standardization" },   // 0-100
  "sources": { "coreBanking", "creditCard", "loan" },                                   // raw row counts
  "unlinkedRecords": 0,          // raw records not yet in any golden customer (null if unknown)
  "matching": { "running": false, "lastRun": { "trigger", "finishedAt", "summary" } | null },
  "jobs": [ IngestionJob ]       // latest 5
}
```
Metric definitions live in `backend/src/services/dashboard.service.js`.

## Ingestion

### `POST /ingestion/upload` — `multipart/form-data` → **202**
| field | value |
|---|---|
| `source` | `core_banking` \| `credit_card` \| `loan` (alias `loan_system`) \| `transaction_data` |
| `file` | CSV, ≤ 10 MB |

The CSV is parsed synchronously (malformed file → 400), then processed in the background.
Returns an `IngestionJob`; poll it until `isTerminal`.

Accepted columns (headers are case/space-insensitive):

| source | columns (→ table) |
|---|---|
| core_banking | `customer_id`\*, `name`\*, `email`, `phone`, `address`, `dob` → `raw_core_banking` |
| credit_card | `cust_ref`\* (or `card_id`), `name`\*, `email`, `phone`, `address`, `credit_limit` → `raw_credit_card` |
| loan | `loan_cust_id`\* (or `loan_id`), `name`\*, `phone`\*, `address`, `loan_amt` → `raw_loan` |
| transaction_data | `txn_id`, `account_id`\* (= Core Banking `customer_id`), `amount`\*, `transaction_date`\* (YYYY-MM-DD or DD/MM/YYYY), `type` (CREDIT/DEBIT, inferred from sign if blank) → `raw_transactions` |

\* required. Customer rows also need a phone or an email.
After a customer upload, matching re-runs and rebuilds `bank_account`, `credit_card`, `loan`, `bank_transactions`.
After a transaction upload, only `bank_transactions` is rebuilt (`summary.transactions` reports attached / unlinked).

### `GET /ingestion/jobs/:jobId` → `IngestionJob`
### `GET /ingestion/jobs?limit=10` → `IngestionJob[]`

```jsonc
// IngestionJob
{
  "jobId": "uuid", "source": "loan", "sourceLabel": "Loan System", "fileName": "loan.csv",
  "status": "queued | processing | matching | completed | failed", "isTerminal": false,
  "recordsReceived": 6, "recordsInserted": 6, "recordsRejected": 0, "records": 6,
  "errorMessage": null,
  "summary": { "rejected": [{ "line": 4, "reason": "..." }], "matching": { ...run summary } },
  "createdAt": "...", "completedAt": "..."
}
```

## Matching

| Method | Path | Description |
|---|---|---|
| POST | `/matching/run` | Re-resolve all raw records and persist golden customers → `{ summary }` |
| GET | `/matching/dry-run` | Run the engine without persisting; returns match statistics and samples |
| GET | `/matching/status` | `{ running, lastRun }` |

Runs are serialised inside the backend process (one at a time).

## Customers

### `GET /customers?q=&page=1&limit=20`
`q` searches name / email / phone (`GC-12` searches by id). Returns `Customer[]` with
`meta: { total, page, limit, totalPages }`.

```jsonc
// Customer
{ "id": 1, "goldenCustomerId": "GC-1", "name", "email", "phone", "dob", "address",
  "profileCompleteness": 80, "qualityScore": 88 }
```

| Method | Path | Data |
|---|---|---|
| GET | `/customers/:id` | `Customer` + `sources: [{ source, label, records }]` |
| GET | `/customers/:id/products` | `{ accounts: [...], creditCards: [...], loans: [...] }` |
| GET | `/customers/:id/transactions?limit=100` | `{ transactions: [{ id, transactionId, accountId, amount, transactionDate, type }] }` |
| GET | `/customers/:id/lineage` | `[{ field, goldenValue, source, sourceLabel, sourceRawId, sourceValue, ruleUsed }]` |
| GET | `/customers/:id/360` | `{ customer, products, transactions, lineage, members }` — everything for the Customer 360 page |

Product shapes:
```jsonc
{ "accounts":    [{ "id", "accountId": "ACC-1", "sourceAccountId", "accountType", "openedDate", "status" }],
  "creditCards": [{ "id", "creditCardId": "CARD-1", "sourceCustRef", "creditLimit" }],
  "loans":       [{ "id", "loanId": "LOAN-1", "sourceLoanCustId", "loanAmount" }] }
```

## Customer portal (source records)

All return **201** with:
```jsonc
{ "source", "sourceLabel", "rawId", "recordId": "CB_7",
  "goldenCustomerId": "GC-7" | null,
  "matching": { "status": "completed | failed | skipped", "summary"?, "message"? } }
```
The raw record is stored, then matching re-runs: the record is linked to a golden customer and that
customer's `bank_account` / `credit_card` / `loan` row is rebuilt. `goldenCustomerId` is the result
(`null` if `AUTO_MATCH_ON_WRITE=false` or the engine was down; the next run links it).

| Method | Path | Body (JSON) |
|---|---|---|
| POST | `/sources/core-banking` | `customerId*`, `name*`, `email*`, `phone*`, `dob*` (YYYY-MM-DD), `address*` |
| POST | `/sources/credit-card` | `custRef*`, `name*`, `email*`, `phone*`, `creditLimit*`, `address*` |
| POST | `/sources/loan` | `loanCustId*`, `name*`, `phone*`, `loanAmount*`, `address*` |

## Frontend mapping

| Screen | Calls |
|---|---|
| Admin › Dashboard | `GET /admin/dashboard`, `POST /matching/run` |
| Admin › Data Ingestion | `POST /ingestion/upload`, poll `GET /ingestion/jobs/:jobId` |
| Admin › Customer Search | `GET /customers?q=&page=` |
| Admin › Customer 360 (`/admin/customer-360/:customerId`) | `GET /customers/:id/360` |
| Customer › Dashboard (`/customer/dashboard?id=GC-1`) | `GET /customers/:id`, `/products`, `/transactions` |
| Customer › Create forms | `POST /sources/core-banking` \| `credit-card` \| `loan` |
