-- =========================================================
-- 6. BANK ACCOUNT
-- =========================================================

CREATE TABLE bank_account (
    account_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    golden_customer_id BIGINT NOT NULL
        REFERENCES golden_customer(golden_customer_id),

    source_account_id TEXT NOT NULL,

    account_type TEXT,
    opened_date DATE,
    status TEXT,

    created_at TIMESTAMPTZ DEFAULT NOW()
);


-- =========================================================
-- 7. CREDIT CARD
-- =========================================================

CREATE TABLE credit_card (
    credit_card_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    golden_customer_id BIGINT NOT NULL
        REFERENCES golden_customer(golden_customer_id),

    source_cust_ref TEXT NOT NULL,

    credit_limit NUMERIC(15,2),

    created_at TIMESTAMPTZ DEFAULT NOW()
);


-- =========================================================
-- 8. LOAN
-- =========================================================

CREATE TABLE loan (
    loan_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    golden_customer_id BIGINT NOT NULL
        REFERENCES golden_customer(golden_customer_id),

    source_loan_cust_id TEXT NOT NULL,

    loan_amt NUMERIC(15,2),

    created_at TIMESTAMPTZ DEFAULT NOW()
);
