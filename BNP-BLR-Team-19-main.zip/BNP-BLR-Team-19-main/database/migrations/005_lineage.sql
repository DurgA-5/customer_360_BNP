-- =========================================================
-- 10. GOLDEN FIELD LINEAGE
-- =========================================================

CREATE TABLE golden_field_lineage (
    lineage_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    golden_customer_id BIGINT NOT NULL
        REFERENCES golden_customer(golden_customer_id),

    field_name TEXT NOT NULL,

    golden_value TEXT,

    source_system TEXT NOT NULL,

    source_raw_id BIGINT NOT NULL,

    source_value TEXT,

    rule_used TEXT,

    created_at TIMESTAMPTZ DEFAULT NOW()
);
