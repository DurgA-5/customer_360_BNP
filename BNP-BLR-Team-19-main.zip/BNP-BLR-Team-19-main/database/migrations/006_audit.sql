-- =========================================================
-- 11. AUDIT LOG
-- =========================================================

CREATE TABLE audit_log (
    audit_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    entity_type TEXT NOT NULL,

    entity_id BIGINT NOT NULL,

    field_name TEXT,

    old_value TEXT,

    new_value TEXT,

    source_system TEXT,

    source_raw_id BIGINT,

    reason TEXT,

    changed_by TEXT,

    changed_at TIMESTAMPTZ DEFAULT NOW()
);
