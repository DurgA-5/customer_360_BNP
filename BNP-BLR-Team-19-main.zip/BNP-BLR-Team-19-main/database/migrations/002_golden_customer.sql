-- =========================================================
-- 5. GOLDEN CUSTOMER
-- =========================================================

CREATE TABLE golden_customer (
    golden_customer_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    name TEXT,
    email TEXT,
    phone TEXT,
    dob DATE,
    address TEXT,

    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
