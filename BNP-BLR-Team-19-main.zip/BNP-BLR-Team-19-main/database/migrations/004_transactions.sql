-- =========================================================
-- 9. BANK TRANSACTIONS
-- =========================================================

CREATE TABLE bank_transactions (
    transaction_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    golden_customer_id BIGINT NOT NULL
        REFERENCES golden_customer(golden_customer_id),

    account_id BIGINT
        REFERENCES bank_account(account_id),

    source_account_id TEXT,

    amount NUMERIC(15,2),

    transaction_date DATE,

    type TEXT,

    created_at TIMESTAMPTZ DEFAULT NOW()
);
