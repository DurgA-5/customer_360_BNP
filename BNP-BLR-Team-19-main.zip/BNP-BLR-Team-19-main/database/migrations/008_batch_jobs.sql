CREATE TABLE IF NOT EXISTS batch_jobs (
    batch_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cron_second TEXT NOT NULL,
    cron_minute TEXT NOT NULL,
    cron_hour TEXT NOT NULL,
    cron_day_of_month TEXT NOT NULL,
    cron_month TEXT NOT NULL,
    cron_day_of_week TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('RUNNING', 'PASSED', 'FAILED')),
    started_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE,
    records_processed INTEGER DEFAULT 0,
    error_message TEXT
);
