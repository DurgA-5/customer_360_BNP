-- =========================================================
-- 1. CORE BANKING RAW DATA
-- =========================================================

CREATE TABLE raw_core_banking (
    raw_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    customer_id TEXT NOT NULL,

    name TEXT,
    email TEXT,
    phone TEXT,
    dob DATE,
    address TEXT,

    -- Normalized values used by matching engine
    normalized_name TEXT,
    normalized_email TEXT,
    normalized_phone TEXT,
    normalized_address TEXT,

    ingested_at TIMESTAMPTZ DEFAULT NOW()
);


-- =========================================================
-- 2. CREDIT CARD RAW DATA
-- =========================================================

CREATE TABLE raw_credit_card (
    raw_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    cust_ref TEXT NOT NULL,

    name TEXT,
    email TEXT,
    phone TEXT,
    credit_limit NUMERIC(15,2),
    address TEXT,

    -- Normalized values used by matching engine
    normalized_name TEXT,
    normalized_email TEXT,
    normalized_phone TEXT,
    normalized_address TEXT,

    ingested_at TIMESTAMPTZ DEFAULT NOW()
);


-- =========================================================
-- 3. LOAN RAW DATA
-- =========================================================

CREATE TABLE raw_loan (
    raw_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    loan_cust_id TEXT NOT NULL,

    name TEXT,
    phone TEXT,
    loan_amt NUMERIC(15,2),
    address TEXT,

    -- Normalized values used by matching engine
    normalized_name TEXT,
    normalized_phone TEXT,
    normalized_address TEXT,

    ingested_at TIMESTAMPTZ DEFAULT NOW()
);


-- =========================================================
-- 4. RAW TRANSACTIONS
-- =========================================================

CREATE TABLE raw_transactions (
    raw_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    txn_id TEXT NOT NULL,
    account_id TEXT NOT NULL,
    amount NUMERIC(15,2),
    transaction_date DATE,
    type TEXT,

    ingested_at TIMESTAMPTZ DEFAULT NOW()
);
