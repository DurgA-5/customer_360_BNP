from app.survivorship.resolver import build_golden_record


records = [
    {
        "record_id": "CB001",
        "source": "core_banking",
        "name": "Rahul Sharma",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210",
        "address": "12 MG Road Hyderabad"
    },
    {
        "record_id": "CC001",
        "source": "credit_card",
        "name": "Rahul S",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210",
        "address": "12 M G Road Hyderabad"
    },
    {
        "record_id": "LN001",
        "source": "loan",
        "name": "Rhaul Sharma",
        "email": None,
        "phone": "9876543210",
        "address": "12 MG Rd Hyderabad"
    }
]


# Temporary test hierarchy.
# Lower number = higher trust.
trust_hierarchy = {
    "core_banking": 1,
    "credit_card": 2,
    "loan": 3
}


result = build_golden_record(
    records,
    trust_hierarchy
)


print("GOLDEN RECORD")
print("=" * 60)

for field, value in result["golden_record"].items():
    print(f"{field}: {value}")


print("\nFIELD LINEAGE")
print("=" * 60)

for field, lineage in result["lineage"].items():
    print(f"{field}: {lineage}")