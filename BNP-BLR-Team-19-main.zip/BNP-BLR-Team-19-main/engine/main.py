from fastapi import FastAPI

from app.api.routes import router


app = FastAPI(
    title="UniBank MDM Engine",
    description="Customer Entity Resolution and Golden Record Engine",
    version="1.0.0"
)


app.include_router(
    router,
    prefix="/api"
)


@app.get("/")
def root():
    return {
        "success": True,
        "message": "UniBank MDM Engine API is running"
    }