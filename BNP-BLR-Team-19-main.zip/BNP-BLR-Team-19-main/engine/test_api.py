"""Contract tests for the endpoint the Node backend calls: POST /api/match."""
from fastapi.testclient import TestClient

from main import app

client = TestClient(app)

RECORDS = [
    {"record_id": "CB_1", "source": "core_banking", "name": "Rahul Sharma", "email": "rahul@gmail.com",
     "phone": "9876543210", "address": "12 MG Road", "dob": "1990-01-01", "source_raw_id": 1},
    {"record_id": "CC_1", "source": "credit_card", "name": "Rahul S", "email": "rahul@gmail.com",
     "phone": "9876543210", "address": "12 M G Road", "dob": None, "source_raw_id": 1},
    {"record_id": "LN_1", "source": "loan", "name": "Rhaul Sharma", "email": None,
     "phone": "9876543210", "address": "12 MG Rd", "dob": None, "source_raw_id": 1},
    {"record_id": "CB_2", "source": "core_banking", "name": "Priya Rao", "email": "priya@gmail.com",
     "phone": "9123456789", "address": "45 Banjara Hills", "dob": None, "source_raw_id": 2},
]


def test_health():
    assert client.get("/api/health").json()["success"] is True


def test_match_requires_records():
    assert client.post("/api/match", json={"records": []}).status_code == 400


def test_match_groups_and_builds_golden_records():
    body = client.post("/api/match", json={"records": RECORDS}).json()
    assert body["success"] is True
    data = body["data"]

    groups = sorted(sorted(members) for members in data["entity_groups"].values())
    assert groups == [["CB_1", "CC_1", "LN_1"], ["CB_2"]]

    rahul = next(g for g in data["golden_records"] if "CB_1" in g["members"])
    # Trust hierarchy: name from credit_card, phone + dob from core_banking.
    assert rahul["golden_record"]["name"] == "Rahul S"
    assert rahul["golden_record"]["dob"] == "1990-01-01"

    lineage = next(item for item in data["lineage"] if item["entity_id"] == rahul["entity_id"])
    assert lineage["lineage"]["phone"]["source"] == "core_banking"
    assert lineage["lineage"]["phone"]["source_raw_id"] == 1
