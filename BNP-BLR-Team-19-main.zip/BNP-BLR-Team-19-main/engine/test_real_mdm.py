from app.pipeline.mdm_pipeline import run_mdm_pipeline
import json


# Load the same records format that the Node backend sends.
# For now, we will fetch them through the backend API.
import requests


response = requests.get("http://localhost:5000/api/matching/records")

if response.status_code != 200:
    print("Failed to fetch records")
    print(response.text)
    exit()

records = response.json()["records"]

print("========================================")
print("REAL DATA MDM DRY RUN")
print("========================================")

print(f"Input records: {len(records)}")

result = run_mdm_pipeline(records)

match_results = result["match_results"]
entity_groups = result["entity_groups"]
golden_records = result["golden_records"]

matches = sum(
    1 for item in match_results
    if item["decision"] == "MATCH"
)

no_matches = sum(
    1 for item in match_results
    if item["decision"] == "NO_MATCH"
)

print()
print("=============== SUMMARY ===============")

print(f"Input records : {len(records)}")
print(f"Candidate pairs: {len(match_results)}")
print(f"MATCH         : {matches}")
print(f"NO_MATCH      : {no_matches}")
print(f"Entity groups : {len(entity_groups)}")
print(f"Golden records: {len(golden_records)}")

print()
print("=============== SAMPLE GOLDEN RECORDS ===============")

for record in golden_records[:5]:
    print()
    print("Entity:", record["entity_id"])
    print("Members:", record["members"])
    print("Golden:", record["golden_record"])

print()
print("========================================")
print("DRY RUN COMPLETE")
print("NO DATABASE WRITE WAS PERFORMED")
print("========================================")