class UnionFind:
    def __init__(self, records):
        self.parent = {
            record["record_id"]: record["record_id"]
            for record in records
        }

    def find(self, record_id):
        if self.parent[record_id] != record_id:
            self.parent[record_id] = self.find(self.parent[record_id])

        return self.parent[record_id]

    def union(self, record_a, record_b):
        root_a = self.find(record_a)
        root_b = self.find(record_b)

        if root_a != root_b:
            self.parent[root_b] = root_a


def group_entities(records, match_results):
    """
    Group records into customer entities.

    Exact matches are strong relationships.

    Fuzzy name matches are allowed only when they do not
    bridge two independently established exact-match groups.
    """

    uf = UnionFind(records)

    # ---------------------------------------------------------
    # STEP 1: Create groups using ONLY exact matches
    # ---------------------------------------------------------
    for result in match_results:

        if result.get("decision") != "MATCH":
            continue

        if result.get("match_type") != "EXACT":
            continue

        uf.union(
            result["record_a"],
            result["record_b"]
        )

    # ---------------------------------------------------------
    # STEP 2: Process fuzzy matches
    # ---------------------------------------------------------
    for result in match_results:

        if result.get("decision") != "MATCH":
            continue

        if result.get("match_type") != "FUZZY_NAME":
            continue

        record_a = result["record_a"]
        record_b = result["record_b"]

        root_a = uf.find(record_a)
        root_b = uf.find(record_b)

        # Already part of the same entity
        if root_a == root_b:
            continue

        # Do NOT merge two independently established
        # exact-match entities using only fuzzy name similarity.
        #
        # This prevents:
        #
        # Entity A -- EXACT -- Entity A
        #       \
        #        FUZZY NAME
        #       /
        # Entity B -- EXACT -- Entity B
        #
        # from becoming one customer.
        continue

    # ---------------------------------------------------------
    # STEP 3: Build final entity groups
    # ---------------------------------------------------------
    groups = {}

    for record in records:

        record_id = record["record_id"]
        root = uf.find(record_id)

        if root not in groups:
            groups[root] = []

        groups[root].append(record_id)

    return groups