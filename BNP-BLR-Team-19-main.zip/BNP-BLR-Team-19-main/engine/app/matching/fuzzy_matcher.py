from rapidfuzz import fuzz


def calculate_similarity(value_a, value_b):
    """
    Calculate fuzzy similarity between two strings.
    Returns a score between 0 and 100.
    """

    if not value_a or not value_b:
        return 0.0

    return fuzz.ratio(value_a, value_b)


def fuzzy_match(record_a, record_b):
    """
    Compare two records using name similarity.

    Decision:
        MATCH     -> name similarity >= 85
        NO_MATCH  -> name similarity < 85
    """

    name_score = calculate_similarity(
        record_a.get("name"),
        record_b.get("name")
    )

    if name_score >= 85:
        decision = "MATCH"
    else:
        decision = "NO_MATCH"

    return {
        "record_a": record_a["record_id"],
        "record_b": record_b["record_id"],
        "decision": decision,
        "name_score": round(name_score, 2)
    }