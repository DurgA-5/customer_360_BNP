from collections import defaultdict


def name_block_key(name):
    """
    Create a simple blocking key from the name.

    Example:
        Rahul Sharma -> rahul
        Rhaul Sharma -> rhaul

    This is only used to find possible candidates.
    It does NOT decide whether two records match.
    """

    if not name:
        return None

    name = name.strip().lower()

    parts = name.split()

    if not parts:
        return None

    return parts[0]


def generate_candidates(records):
    """
    Generate possible customer pairs using blocking keys.

    Candidate rules:
        1. Exact email
        2. Exact phone
        3. Same first-name block

    The fuzzy matcher makes the final decision for
    name/address similarity.
    """

    email_index = defaultdict(list)
    phone_index = defaultdict(list)
    name_index = defaultdict(list)

    for record in records:

        email = record.get("email")
        phone = record.get("phone")
        name_key = name_block_key(record.get("name"))

        if email:
            email_index[email].append(record)

        if phone:
            phone_index[phone].append(record)

        if name_key:
            name_index[name_key].append(record)

    candidates = {}

    def add_candidate(record_a, record_b, reason):

        id_a = record_a["record_id"]
        id_b = record_b["record_id"]

        pair_id = tuple(sorted([id_a, id_b]))

        if pair_id not in candidates:
            candidates[pair_id] = {
                "record_a": record_a,
                "record_b": record_b,
                "reasons": []
            }

        if reason not in candidates[pair_id]["reasons"]:
            candidates[pair_id]["reasons"].append(reason)

    def process_index(index, reason):

        for grouped_records in index.values():

            for i in range(len(grouped_records)):

                for j in range(i + 1, len(grouped_records)):

                    add_candidate(
                        grouped_records[i],
                        grouped_records[j],
                        reason
                    )

    process_index(email_index, "EXACT_EMAIL")
    process_index(phone_index, "EXACT_PHONE")
    process_index(name_index, "NAME_BLOCK")

    return list(candidates.values())