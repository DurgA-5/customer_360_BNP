def exact_match(record_a, record_b):
    """
    Determine whether two candidate records match
    using exact email or phone.

    Returns an explainable match result.
    """

    reasons = []

    email_a = record_a.get("email")
    email_b = record_b.get("email")

    phone_a = record_a.get("phone")
    phone_b = record_b.get("phone")

    # Exact email match
    if email_a and email_b and email_a == email_b:
        reasons.append("EXACT_EMAIL")

    # Exact phone match
    if phone_a and phone_b and phone_a == phone_b:
        reasons.append("EXACT_PHONE")

    # At least one strong exact identifier matched
    if reasons:
        return {
            "record_a": record_a["record_id"],
            "record_b": record_b["record_id"],
            "decision": "MATCH",
            "reasons": reasons,
            "confidence": 1.0
        }

    return {
        "record_a": record_a["record_id"],
        "record_b": record_b["record_id"],
        "decision": "NO_MATCH",
        "reasons": [],
        "confidence": 0.0
    }