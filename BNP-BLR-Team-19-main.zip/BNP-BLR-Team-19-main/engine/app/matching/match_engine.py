from app.matching.candidate_generator import generate_candidates
from app.matching.exact_matcher import exact_match
from app.matching.fuzzy_matcher import fuzzy_match


def match_records(records):
    """
    Run the complete matching process.

    Flow:
        Records
          ↓
        Candidate Generation
          ↓
        Exact Matching
          ↓
        Fuzzy Name Matching when exact match is unavailable
    """

    candidates = generate_candidates(records)

    results = []

    for candidate in candidates:

        record_a = candidate["record_a"]
        record_b = candidate["record_b"]

        # First try exact matching
        exact_result = exact_match(
            record_a,
            record_b
        )

        if exact_result["decision"] == "MATCH":

            result = exact_result

        else:

            # Exact matching failed.
            # Apply configured fuzzy NAME matching.
            result = fuzzy_match(
                record_a,
                record_b
            )

            result["match_type"] = "FUZZY_NAME"

        # Exact match provenance
        if exact_result["decision"] == "MATCH":
            result["match_type"] = "EXACT"

        # Preserve how the candidate was generated
        result["candidate_reasons"] = candidate["reasons"]

        results.append(result)

    return results