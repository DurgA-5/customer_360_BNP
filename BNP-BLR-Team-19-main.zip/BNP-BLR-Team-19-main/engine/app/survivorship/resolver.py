def resolve_field(records, field, field_trust_hierarchy):
    candidates = []

    priorities = field_trust_hierarchy.get(field, {})

    for record in records:
        value = record.get(field)

        if value is None or value == "":
            continue

        source = record.get("source")

        priority = priorities.get(source)

        if priority is None:
            continue

        candidates.append({
            "value": value,
            "source": source,
            "source_record": record["record_id"],
            "source_raw_id": record.get("source_raw_id"),
            "priority": priority
        })

    if not candidates:
        return None

    return min(
        candidates,
        key=lambda candidate: candidate["priority"]
    )


def build_golden_record(records, field_trust_hierarchy):
    fields = [
        "name",
        "email",
        "phone",
        "address",
        "dob"
    ]

    golden_record = {}
    lineage = {}

    for field in fields:

        winner = resolve_field(
            records,
            field,
            field_trust_hierarchy
        )

        if winner is None:
            golden_record[field] = None
            lineage[field] = None
            continue

        golden_record[field] = winner["value"]

        lineage[field] = {
            "source": winner["source"],
            "source_record": winner["source_record"],
            "source_raw_id": winner["source_raw_id"],
            "source_value": winner["value"],
            "priority": winner["priority"],
            "rule_used": "field_specific_trust"
        }

    return {
        "golden_record": golden_record,
        "lineage": lineage
    }