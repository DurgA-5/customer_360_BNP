from app.matching.match_engine import match_records
from app.matching.grouper import group_entities
from app.survivorship.resolver import build_golden_record
from app.config.trust_hierarchy import FIELD_TRUST_HIERARCHY


def run_mdm_pipeline(records):
    """
    Run the complete MDM pipeline.

    Steps:
        1. Match records
        2. Group confirmed matches
        3. Build Golden Records
        4. Generate field lineage

    REVIEW and NO_MATCH records are not automatically merged.
    """

    # --------------------------------------------------
    # STEP 1: MATCHING
    # --------------------------------------------------

    match_results = match_records(records)

    # --------------------------------------------------
    # STEP 2: ENTITY GROUPING
    # --------------------------------------------------

    entity_groups = group_entities(
        records,
        match_results
    )

    # Create quick lookup:
    # record_id -> complete record
    record_lookup = {
        record["record_id"]: record
        for record in records
    }

    golden_records = []
    all_lineage = []

    # --------------------------------------------------
    # STEP 3: SURVIVORSHIP
    # --------------------------------------------------

    for entity_id, member_ids in entity_groups.items():

        entity_records = [
            record_lookup[record_id]
            for record_id in member_ids
        ]

        result = build_golden_record(
            entity_records,
            FIELD_TRUST_HIERARCHY
        )

        golden_records.append({
            "entity_id": entity_id,
            "members": member_ids,
            "golden_record": result["golden_record"]
        })

        all_lineage.append({
            "entity_id": entity_id,
            "lineage": result["lineage"]
        })

    # --------------------------------------------------
    # FINAL RESULT
    # --------------------------------------------------

    return {
        "match_results": match_results,
        "entity_groups": entity_groups,
        "golden_records": golden_records,
        "lineage": all_lineage
    }