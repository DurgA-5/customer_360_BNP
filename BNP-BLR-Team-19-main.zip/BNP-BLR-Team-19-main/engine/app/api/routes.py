from fastapi import APIRouter, HTTPException

from app.pipeline.mdm_pipeline import run_mdm_pipeline


router = APIRouter()


@router.get("/health")
def health_check():
    return {
        "success": True,
        "message": "MDM Engine is running"
    }


@router.post("/match")
def run_matching(payload: dict):

    try:

        records = payload.get("records")

        if not records:
            raise HTTPException(
                status_code=400,
                detail="records are required"
            )

        result = run_mdm_pipeline(records)

        return {
            "success": True,
            "data": result
        }

    except HTTPException:
        raise

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )