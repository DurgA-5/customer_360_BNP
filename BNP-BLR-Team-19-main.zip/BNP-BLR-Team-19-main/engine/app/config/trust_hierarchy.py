FIELD_TRUST_HIERARCHY = {
    "phone": {
        "core_banking": 1,
        "credit_card": 2,
        "loan": 3
    },
    "email": {
        "credit_card": 1,
        "core_banking": 2,
        "loan": 3
    },
    "name": {
        "credit_card": 1,
        "core_banking": 2,
        "loan": 3
    },
    "address": {
        "credit_card": 1,
        "core_banking": 2,
        "loan": 3
    },
    "dob": {
        "core_banking": 1,
        "credit_card": 2,
        "loan": 3
    }
}