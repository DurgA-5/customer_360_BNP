from app.matching.candidate_generator import generate_candidates
from app.matching.exact_matcher import exact_match


records = [
    {
        "record_id": "CB001",
        "source": "core_banking",
        "name": "Rahul Sharma",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210"
    },
    {
        "record_id": "CC001",
        "source": "credit_card",
        "name": "Rahul S",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210"
    },
    {
        "record_id": "LN001",
        "source": "loan",
        "name": "Rhaul Sharma",
        "email": None,
        "phone": "9876543210"
    },
    {
        "record_id": "LN006",
        "source": "loan",
        "name": "Rahul Verma",
        "email": None,
        "phone": "9887766554"
    }
]


candidates = generate_candidates(records)

print("Exact Matching Results:")
print("-" * 60)

for candidate in candidates:

    result = exact_match(
        candidate["record_a"],
        candidate["record_b"]
    )

    print(result)