from app.matching.match_engine import match_records
from app.matching.grouper import group_entities


records = [
    {
        "record_id": "CB001",
        "source": "core_banking",
        "name": "Rahul Sharma",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210",
        "address": "12 MG Road Hyderabad"
    },
    {
        "record_id": "CC001",
        "source": "credit_card",
        "name": "Rahul S",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210",
        "address": "12 M G Road Hyderabad"
    },
    {
        "record_id": "LN001",
        "source": "loan",
        "name": "Rhaul Sharma",
        "email": None,
        "phone": "9876543210",
        "address": "12 MG Rd Hyderabad"
    },
    {
        "record_id": "LN006",
        "source": "loan",
        "name": "Rahul Verma",
        "email": None,
        "phone": "9887766554",
        "address": "99 Hitech City Hyderabad"
    }
]


# Step 1: Run matching
match_results = match_records(records)

# Step 2: Group confirmed matches
groups = group_entities(records, match_results)


print("CUSTOMER ENTITIES")
print("=" * 50)

for entity_id, members in groups.items():
    print(f"{entity_id} -> {members}")