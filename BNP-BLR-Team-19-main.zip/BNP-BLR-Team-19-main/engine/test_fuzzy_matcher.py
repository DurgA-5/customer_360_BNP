from app.matching.fuzzy_matcher import fuzzy_match


records = [
    {
        "record_id": "CB001",
        "name": "Rahul Sharma",
        "address": "12 MG Road Hyderabad"
    },
    {
        "record_id": "LN001",
        "name": "Rhaul Sharma",
        "address": "12 MG Rd Hyderabad"
    },
    {
        "record_id": "LN006",
        "name": "Rahul Verma",
        "address": "99 Hitech City Hyderabad"
    }
]


print("Fuzzy Matching Results:")
print("-" * 60)

result1 = fuzzy_match(records[0], records[1])
print(result1)

result2 = fuzzy_match(records[0], records[2])
print(result2)