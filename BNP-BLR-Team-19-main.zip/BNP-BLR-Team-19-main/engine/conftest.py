# test_real_mdm.py is a manual script that needs a running backend; keep it out of pytest.
collect_ignore = ["test_real_mdm.py"]
