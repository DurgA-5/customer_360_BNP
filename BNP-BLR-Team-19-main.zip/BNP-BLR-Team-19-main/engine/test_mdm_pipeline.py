from app.pipeline.mdm_pipeline import run_mdm_pipeline


records = [
    {
        "record_id": "CB001",
        "source": "core_banking",
        "source_raw_id": 1,
        "name": "rahul sharma",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210",
        "address": "12 mg road hyderabad"
    },
    {
        "record_id": "CC001",
        "source": "credit_card",
        "source_raw_id": 2,
        "name": "rahul s",
        "email": "rahul.sharma@gmail.com",
        "phone": "9876543210",
        "address": "12 m g road hyderabad"
    },
    {
        "record_id": "LN001",
        "source": "loan",
        "source_raw_id": 3,
        "name": "rhaul sharma",
        "email": None,
        "phone": "9876543210",
        "address": "12 mg rd hyderabad"
    },
    {
        "record_id": "LN006",
        "source": "loan",
        "source_raw_id": 6,
        "name": "rahul verma",
        "email": None,
        "phone": "9887766554",
        "address": "99 hitech city hyderabad"
    }
]


result = run_mdm_pipeline(records)


print("\n================ MATCH RESULTS ================")

for match in result["match_results"]:
    print(match)


print("\n================ ENTITY GROUPS ================")

for entity_id, members in result["entity_groups"].items():
    print(entity_id, "->", members)


print("\n================ GOLDEN RECORDS ================")

for golden in result["golden_records"]:
    print("\nEntity:", golden["entity_id"])
    print("Members:", golden["members"])
    print("Golden Record:")
    print(golden["golden_record"])


print("\n================ FIELD LINEAGE ================")

for lineage in result["lineage"]:
    print("\nEntity:", lineage["entity_id"])

    for field, details in lineage["lineage"].items():
        print(field, "->", details)