require("dotenv").config();

const {
    getMDMRecords
} = require("./src/services/mdm-record.service");

async function test() {
    try {
        const records = await getMDMRecords();

        console.log("Total MDM records:", records.length);

        console.log("\nFirst Core Banking record:");
        console.log(records[0]);

        console.log("\nFirst Credit Card record:");
        console.log(
            records.find(record => record.source === "credit_card")
        );

        console.log("\nFirst Loan record:");
        console.log(
            records.find(record => record.source === "loan")
        );

    } catch (error) {
        console.error("MDM record mapping failed:");
        console.error(error.message);
    }
}

test();