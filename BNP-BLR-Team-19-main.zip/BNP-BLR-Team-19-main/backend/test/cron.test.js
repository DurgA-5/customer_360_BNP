const { test } = require("node:test");
const assert = require("node:assert/strict");
const cronService = require("../src/services/cron.service");

test("cronService validates 6-field cron expressions", () => {
    // Valid 6 fields
    const context = cronService.setSchedule("0 */5 * * * *");
    assert.equal(context.cron_second, "0");
    assert.equal(context.cron_minute, "*/5");
    assert.equal(context.cron_hour, "*");
    assert.equal(context.cron_day_of_month, "*");
    assert.equal(context.cron_month, "*");
    assert.equal(context.cron_day_of_week, "*");

    // Invalid number of fields
    assert.throws(() => {
        cronService.setSchedule("*/5 * * * *");
    }, /must have exactly 6 fields/);
});
