// Pure-logic tests (no database / engine needed): node --test test/
process.env.SUPABASE_URL ||= "http://localhost:54321";
process.env.SUPABASE_ANON_KEY ||= "test";

const { test } = require("node:test");
const assert = require("node:assert/strict");

const n = require("../src/utils/normalize");
const { planGoldenIds } = require("../src/repositories/golden.repository");
const { toRawRow, toRawTransactionRow } = require("../src/services/source-mapping");
const { buildTransactionRows } = require("../src/services/product-rebuild.service");
const { buildAuditEntries } = require("../src/repositories/golden.repository");
const { parseCustomerId, scoreCustomer } = require("../src/services/customer.service");
const { normalizeSource } = require("../src/config/sources");

test("normalisation makes exact matching reliable", () => {
    assert.equal(n.normalizePhone("+91 98765-43210"), "9876543210");
    assert.equal(n.normalizePhone("09876543210"), "9876543210");
    assert.equal(n.normalizeEmail("  Rahul.Sharma@Gmail.COM "), "rahul.sharma@gmail.com");
    assert.equal(n.normalizeName("  rahul   SHARMA "), "Rahul Sharma");
    assert.equal(n.normalizeAddress("12 m g rd,hyderabad"), "12 MG Road, Hyderabad");
    assert.equal(n.normalizeDate("24/09/2026"), "2026-09-24");
    assert.equal(n.normalizeDate("2026-02-30"), null);
});

test("planGoldenIds reuses the id most members previously had", () => {
    const previous = new Map([
        ["core_banking:1", 10], ["credit_card:1", 10], ["loan:1", 10],
        ["core_banking:2", 20]
    ]);
    const entities = [
        { members: [{ source: "core_banking", source_raw_id: 2 }] },
        { members: [
            { source: "core_banking", source_raw_id: 1 },
            { source: "credit_card", source_raw_id: 1 },
            { source: "loan", source_raw_id: 99 } // new record joins existing customer
        ] },
        { members: [{ source: "loan", source_raw_id: 50 }] } // brand new customer
    ];
    assert.deepEqual(planGoldenIds(entities, previous), [20, 10, null]);
});

test("planGoldenIds: after a split only one entity keeps the old id", () => {
    const previous = new Map([["core_banking:1", 10], ["credit_card:1", 10], ["loan:1", 10]]);
    const entities = [
        { members: [{ source: "loan", source_raw_id: 1 }] },
        { members: [{ source: "core_banking", source_raw_id: 1 }, { source: "credit_card", source_raw_id: 1 }] }
    ];
    assert.deepEqual(planGoldenIds(entities, previous), [null, 10]);
});

test("source mapping validates and normalises rows for the team schema", () => {
    assert.equal(toRawRow("core_banking", { name: "X", phone: "9876543210" }).error, "customer_id is required");
    assert.equal(toRawRow("core_banking", { customer_id: "C1", name: "X" }).error, "at least one of phone or email is required");
    assert.match(toRawRow("core_banking", { customer_id: "C1", name: "X", phone: "9876543210", dob: "31/31/2020" }).error, /invalid dob/);

    const { row } = toRawRow("credit_card", { card_id: "CC1", name: "a b", email: "A@B.COM", phone: "98765 43210", credit_limit: "1,50,000" });
    assert.equal(row.cust_ref, "CC1");
    assert.equal(row.normalized_email, "a@b.com");
    assert.equal(row.normalized_phone, "9876543210");
    assert.equal(row.credit_limit, 150000);

    const loan = toRawRow("loan", { loan_id: "L1", name: "x", email: "x@y.z", phone: "9876543210", loan_amount: "500000" }).row;
    assert.equal("email" in loan, false, "raw_loan has no email column");
    assert.equal(loan.loan_amt, 500000);
    assert.match(toRawRow("loan", { loan_id: "L1", name: "x", phone: "9876543210", loan_amt: "-5" }).error, /invalid loan_amt/);

    assert.deepEqual(toRawTransactionRow({ account_id: "CB001", amount: "-500", date: "01/02/2026" }, "job-2").row, {
        txn_id: "job-2", account_id: "CB001", amount: 500, transaction_date: "2026-02-01", type: "DEBIT"
    });
});

test("transactions attach to accounts by source account id; duplicates collapse", () => {
    const accounts = [
        { account_id: 1, golden_customer_id: 10, source_account_id: "CB001" },
        { account_id: 2, golden_customer_id: 20, source_account_id: "CB002" }
    ];
    const raw = [
        { txn_id: "T1", account_id: "CB001", amount: 10, transaction_date: "2026-01-01", type: "CREDIT" },
        { txn_id: "T1", account_id: "CB001", amount: 10, transaction_date: "2026-01-01", type: "CREDIT" },
        { txn_id: "T2", account_id: "CB002", amount: 5, transaction_date: "2026-01-02", type: "DEBIT" },
        { txn_id: "T3", account_id: "NOPE", amount: 1, transaction_date: "2026-01-03", type: "DEBIT" }
    ];
    const { rows, unlinked } = buildTransactionRows(raw, accounts);
    assert.equal(rows.length, 2);
    assert.equal(unlinked, 1);
    assert.deepEqual(rows.map((r) => r.golden_customer_id), [10, 20]);
});

test("transactions attach to credit card and loan references as well as bank accounts", () => {
    const accounts = [
        { account_id: 1, golden_customer_id: 10, source_account_id: "C001" }
    ];
    const cards = [
        { card_id: 100, golden_customer_id: 20, source_cust_ref: "CC_870" }
    ];
    const loans = [
        { loan_id: 200, golden_customer_id: 30, source_loan_cust_id: "L_540" }
    ];
    const raw = [
        { txn_id: "T1", account_id: "C001", amount: 100, transaction_date: "2026-01-01", type: "CREDIT" },
        { txn_id: "T2", account_id: "CC_870", amount: 200, transaction_date: "2026-01-02", type: "DEBIT" },
        { txn_id: "T3", account_id: "L_540", amount: 300, transaction_date: "2026-01-03", type: "DEBIT" },
        { txn_id: "T4", account_id: "MISSING", amount: 400, transaction_date: "2026-01-04", type: "DEBIT" }
    ];
    const { rows, unlinked } = buildTransactionRows(raw, accounts, cards, loans);
    assert.equal(rows.length, 3);
    assert.equal(unlinked, 1);
    assert.deepEqual(rows.map((r) => r.golden_customer_id), [10, 20, 30]);
});

test("audit entries record created, changed and removed golden customers", () => {
    const entries = buildAuditEntries({
        entities: [
            { golden_record: { name: "Rahul S", email: "r@x.com" }, lineage: { name: { source: "credit_card", source_raw_id: 4, rule_used: "field_specific_trust" } }, members: [{}] },
            { golden_record: { name: "New" }, lineage: {}, members: [{}, {}] }
        ],
        goldenIds: [1, 2],
        previousById: new Map([[1, { name: "Rahul Sharma", email: "r@x.com" }]]),
        reusedIds: new Set([1]),
        orphanIds: [3],
        reason: "MATCHING_RUN (test)"
    });
    assert.deepEqual(entries.map((e) => [e.entityId, e.fieldName ?? null]), [[1, "name"], [2, null], [2, "name"], [3, null]]);
    assert.equal(entries[0].oldValue, "Rahul Sharma");
    assert.equal(entries[0].newValue, "Rahul S");
    assert.equal(entries[0].sourceSystem, "credit_card");
});

test("customer id parsing and scoring", () => {
    assert.equal(parseCustomerId("GC-12"), 12);
    assert.equal(parseCustomerId("12"), 12);
    assert.throws(() => parseCustomerId("abc"));
    assert.deepEqual(scoreCustomer({ name: "A", email: "a@b.co", phone: "9876543210", dob: "1990-01-01", address: "x" }),
        { profileCompleteness: 100, qualityScore: 100 });
});

test("source aliases from the UI map to engine names", () => {
    assert.equal(normalizeSource("loan_system"), "loan");
    assert.equal(normalizeSource("Core_Banking"), "core_banking");
    assert.equal(normalizeSource("nope"), null);
});
