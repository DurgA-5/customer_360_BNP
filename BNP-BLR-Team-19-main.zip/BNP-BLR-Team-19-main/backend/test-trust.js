require("dotenv").config();

const supabase = require("./src/clients/supabase.client");

async function test() {
    const { data, error } = await supabase
        .from("trust_hierarchy")
        .select("*");

    if (error) {
        console.error("Failed to fetch trust hierarchy:");
        console.error(error.message);
        return;
    }

    console.log("Trust hierarchy rows:");
    console.log(data);
}

test();