const TABLES = require("../config/tables");
const {
  supabase,
  dbError,
  isMissingTable,
  fetchAll,
  count,
} = require("../utils/db");

const CUSTOMER_COLUMNS = "golden_customer_id, name, email, phone, dob, address";

/** Strip characters that have meaning inside a PostgREST or() filter. */
function sanitizeSearch(term) {
  return String(term)
    .replace(/[,()*%\\:"]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

async function search({ q, goldenId, limit, offset }) {
  let query = supabase
    .from(TABLES.goldenCustomer)
    .select(CUSTOMER_COLUMNS, { count: "exact" })
    .order("golden_customer_id", { ascending: true })
    .range(offset, offset + limit - 1);

  if (goldenId) {
    query = query.eq("golden_customer_id", goldenId);
  } else if (q) {
    const term = sanitizeSearch(q);
    if (term) {
      const digits = term.replace(/\D/g, "");
      const filters = [`name.ilike.*${term}*`, `email.ilike.*${term}*`];
      if (digits.length >= 3) filters.push(`phone.ilike.*${digits}*`);
      query = query.or(filters.join(","));
    }
  }

  const { data, error, count: total } = await query;
  if (error) throw dbError("search", TABLES.goldenCustomer, error);

  return { rows: data || [], total: total || 0 };
}

async function findById(goldenCustomerId) {
  const { data, error } = await supabase
    .from(TABLES.goldenCustomer)
    .select(CUSTOMER_COLUMNS)
    .eq("golden_customer_id", goldenCustomerId)
    .maybeSingle();

  if (error) throw dbError("fetch", TABLES.goldenCustomer, error);
  return data;
}

async function getLineage(goldenCustomerId) {
  return fetchAll(TABLES.goldenLineage, {
    filter: (query) => query.eq("golden_customer_id", goldenCustomerId),
    orderBy: "lineage_id",
  });
}

async function getMembers(goldenCustomerId) {
  try {
    return await fetchAll(TABLES.goldenMember, {
      columns: "source_system, source_raw_id, record_id",
      filter: (query) => query.eq("golden_customer_id", goldenCustomerId),
    });
  } catch (error) {
    if (!isMissingTable(error)) throw error;
  }

  const lineage = await getLineage(goldenCustomerId);
  const seen = new Map();
  for (const row of lineage) {
    seen.set(`${row.source_system}:${row.source_raw_id}`, {
      source_system: row.source_system,
      source_raw_id: row.source_raw_id,
    });
  }
  return [...seen.values()];
}

async function findGoldenIdForRecord(source, rawId) {
  const { data, error } = await supabase
    .from(TABLES.goldenMember)
    .select("golden_customer_id")
    .eq("source_system", source)
    .eq("source_raw_id", rawId)
    .maybeSingle();

  if (error) {
    if (isMissingTable(error)) return null;
    throw dbError("fetch", TABLES.goldenMember, error);
  }
  return data?.golden_customer_id ?? null;
}

/** Golden customers whose phone or email equals the given (normalised) values. */
async function findByContact({ phone, email }) {
  const quote = (value) => `"${String(value).replace(/["\\]/g, "")}"`;
  const filters = [];
  if (phone) filters.push(`phone.eq.${quote(phone)}`);
  if (email) filters.push(`email.eq.${quote(email)}`);
  if (!filters.length) return [];

  const { data, error } = await supabase
    .from(TABLES.goldenCustomer)
    .select(CUSTOMER_COLUMNS)
    .or(filters.join(","))
    .order("golden_customer_id", { ascending: true })
    .limit(10);

  if (error) throw dbError("search", TABLES.goldenCustomer, error);
  return data || [];
}

/** Golden customer ids that the given raw records currently belong to. */
async function findGoldenIdsForRecords(records) {
  const bySource = new Map();
  for (const { source, raw_id: rawId } of records) {
    if (!bySource.has(source)) bySource.set(source, []);
    bySource.get(source).push(rawId);
  }

  const ids = new Set();
  for (const [source, rawIds] of bySource) {
    const { data, error } = await supabase
      .from(TABLES.goldenMember)
      .select("golden_customer_id")
      .eq("source_system", source)
      .in("source_raw_id", rawIds);
    if (error) {
      if (isMissingTable(error)) return [];
      throw dbError("fetch", TABLES.goldenMember, error);
    }
    for (const row of data || []) ids.add(row.golden_customer_id);
  }
  return [...ids].sort((a, b) => a - b);
}

async function findByIds(goldenIds) {
  if (!goldenIds.length) return [];
  const { data, error } = await supabase
    .from(TABLES.goldenCustomer)
    .select(CUSTOMER_COLUMNS)
    .in("golden_customer_id", goldenIds)
    .order("golden_customer_id", { ascending: true });
  if (error) throw dbError("fetch", TABLES.goldenCustomer, error);
  return data || [];
}

async function countAll() {
  return count(TABLES.goldenCustomer);
}

async function getAllForQuality() {
  return fetchAll(TABLES.goldenCustomer, {
    columns: "name, email, phone, dob, address",
    orderBy: "golden_customer_id",
  });
}

async function countMultiSourceCustomers() {
  try {
    const members = await fetchAll(TABLES.goldenMember, {
      columns: "golden_customer_id",
    });
    const perCustomer = new Map();
    for (const { golden_customer_id: id } of members) {
      perCustomer.set(id, (perCustomer.get(id) || 0) + 1);
    }
    return [...perCustomer.values()].filter((n) => n > 1).length;
  } catch (error) {
    if (isMissingTable(error)) return null;
    throw error;
  }
}

module.exports = {
  search,
  findById,
  getLineage,
  getMembers,
  findGoldenIdForRecord,
  findByContact,
  findGoldenIdsForRecords,
  findByIds,
  countAll,
  getAllForQuality,
  countMultiSourceCustomers,
};
