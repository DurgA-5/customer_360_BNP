/**
 * Persistence of engine output (golden customers, field lineage, membership).
 *
 * Golden customer IDs are kept STABLE across matching runs: each new entity
 * reuses the golden_customer_id that most of its member records belonged to
 * last time. Without this, every run wiped and re-inserted golden_customer,
 * so customer IDs (and any bookmarked Customer 360 link) changed each run.
 *
 * NOTE: PostgREST has no multi-statement transactions. For production move
 * replaceGoldenData into a Postgres function and call it via supabase.rpc().
 */
const TABLES = require("../config/tables");
const {
    supabase,
    dbError,
    isMissingTable,
    fetchAll,
    insertMany,
    upsertMany,
    deleteIn
} = require("../utils/db");

const memberKey = (source, rawId) => `${source}:${rawId}`;

/**
 * Pure function: decide which previous golden id each entity should reuse.
 *
 * @param {Array<{members: Array<{source, source_raw_id}>}>} entities
 * @param {Map<string, number>} previousMembership memberKey -> golden_customer_id
 * @returns {Array<number|null>} id to reuse per entity (null = allocate new)
 */
function planGoldenIds(entities, previousMembership) {
    // Score every (entity, previousId) pair by how many members it shares.
    const candidates = [];

    entities.forEach((entity, index) => {
        const votes = new Map();
        for (const member of entity.members) {
            const previousId = previousMembership.get(memberKey(member.source, member.source_raw_id));
            if (previousId !== undefined) {
                votes.set(previousId, (votes.get(previousId) || 0) + 1);
            }
        }
        for (const [goldenId, score] of votes) {
            candidates.push({ index, goldenId, score });
        }
    });

    // Greedy: highest overlap wins; ties go to the lower (older) id for determinism.
    candidates.sort((a, b) => b.score - a.score || a.goldenId - b.goldenId || a.index - b.index);

    const plan = new Array(entities.length).fill(null);
    const claimed = new Set();

    for (const { index, goldenId } of candidates) {
        if (plan[index] !== null || claimed.has(goldenId)) continue;
        plan[index] = goldenId;
        claimed.add(goldenId);
    }

    return plan;
}

async function loadPreviousMembership() {
    try {
        const rows = await fetchAll(TABLES.goldenMember, {
            columns: "golden_customer_id, source_system, source_raw_id"
        });
        return new Map(rows.map((row) => [memberKey(row.source_system, row.source_raw_id), row.golden_customer_id]));
    } catch (error) {
        if (isMissingTable(error)) return null;
        throw error;
    }
}

async function clearTable(table, keyColumn) {
    const { error } = await supabase.from(table).delete().gte(keyColumn, 0);
    if (error && !isMissingTable(error)) throw dbError("clear", table, error);
    return !error;
}

function toCustomerRow(entity) {
    const golden = entity.golden_record || {};
    return {
        name: golden.name || null,
        email: golden.email || null,
        phone: golden.phone || null,
        dob: golden.dob || null,
        address: golden.address || null
    };
}

function lineageRows(entity, goldenCustomerId) {
    const rows = [];
    for (const [fieldName, details] of Object.entries(entity.lineage || {})) {
        if (!details) continue;
        rows.push({
            golden_customer_id: goldenCustomerId,
            field_name: fieldName,
            golden_value: details.source_value,
            source_system: details.source,
            source_raw_id: details.source_raw_id,
            source_value: details.source_value,
            rule_used: details.rule_used
        });
    }
    return rows;
}

function memberRows(entity, goldenCustomerId) {
    return entity.members.map((member) => ({
        golden_customer_id: goldenCustomerId,
        source_system: member.source,
        source_raw_id: member.source_raw_id,
        record_id: member.record_id
    }));
}

const AUDITED_FIELDS = ["name", "email", "phone", "dob", "address"];

function sameValue(a, b) {
    return (a ?? null) === null ? (b ?? null) === null : String(a) === String(b ?? "");
}

/**
 * Field-level audit entries for the audit_log table:
 * created customers, changed golden values (old -> new, with winning source),
 * and customers removed because their records were merged elsewhere.
 */
function buildAuditEntries({ entities, goldenIds, previousById, reusedIds, orphanIds, reason }) {
    const entries = [];

    entities.forEach((entity, i) => {
        const goldenId = goldenIds[i];
        const next = entity.golden_record || {};
        const lineage = entity.lineage || {};
        const isReused = reusedIds.has(goldenId);
        const previous = isReused ? (previousById.get(goldenId) || {}) : {};

        if (!isReused) {
            entries.push({
                entityType: "golden_customer",
                entityId: goldenId,
                reason: `${reason}: golden customer created from ${entity.members.length} source record(s)`,
                changedBy: "mdm-engine"
            });
        }

        for (const field of AUDITED_FIELDS) {
            const nextValue = next[field] ?? null;
            const prevValue = isReused ? (previous[field] ?? null) : null;

            if (sameValue(prevValue, nextValue)) continue;

            const fieldLineage = lineage[field];
            entries.push({
                entityType: "golden_customer",
                entityId: goldenId,
                fieldName: field,
                oldValue: prevValue,
                newValue: nextValue,
                sourceSystem: fieldLineage?.source ?? null,
                sourceRawId: fieldLineage?.source_raw_id ?? null,
                reason: `${reason}: ${fieldLineage?.rule_used || (isReused ? "survivorship" : "initial_survivorship")}`,
                changedBy: "mdm-engine"
            });
        }
    });

    for (const goldenId of orphanIds) {
        entries.push({
            entityType: "golden_customer",
            entityId: goldenId,
            reason: `${reason}: golden customer removed (its records were merged into another customer)`,
            changedBy: "mdm-engine"
        });
    }

    return entries;
}

/**
 * Persist engine output. Callers must clear the derived product tables
 * first (they reference golden_customer) and rebuild them afterwards.
 *
 * @param {Array<{golden_record, lineage, members: Array<{record_id, source, source_raw_id}>}>} entities
 * @param {{reason?: string}} [options]
 */
async function replaceGoldenData(entities, { reason = "MATCHING_RUN" } = {}) {
    const previousMembership = await loadPreviousMembership();
    const membershipSupported = previousMembership !== null;

    const previousRows = await fetchAll(TABLES.goldenCustomer, {
        columns: "golden_customer_id, name, email, phone, dob, address",
        orderBy: "golden_customer_id"
    });
    const previousById = new Map(previousRows.map((row) => [row.golden_customer_id, row]));
    const existingIds = previousRows.map((row) => row.golden_customer_id);

    const plan = membershipSupported
        ? planGoldenIds(entities, previousMembership)
        : new Array(entities.length).fill(null);

    // 1. Children first (FKs reference golden_customer).
    await clearTable(TABLES.goldenLineage, "lineage_id");
    if (membershipSupported) await clearTable(TABLES.goldenMember, "golden_customer_id");

    // 2. Update reused customers in place, insert new ones.
    const reused = [];
    const fresh = [];
    entities.forEach((entity, index) => {
        if (plan[index] !== null) {
            reused.push({
                index,
                row: {
                    golden_customer_id: plan[index],
                    ...toCustomerRow(entity),
                    updated_at: new Date().toISOString()
                }
            });
        } else {
            fresh.push({ index, row: toCustomerRow(entity) });
        }
    });

    // Without membership we cannot keep ids stable: fall back to full replace.
    if (!membershipSupported && existingIds.length) {
        await deleteIn(TABLES.goldenCustomer, "golden_customer_id", existingIds);
    }

    if (reused.length) {
        await upsertMany(TABLES.goldenCustomer, reused.map((item) => item.row), "golden_customer_id");
    }

    const insertedFresh = await insertMany(TABLES.goldenCustomer, fresh.map((item) => item.row), {
        returning: "golden_customer_id"
    });
    const goldenIds = [...plan];
    fresh.forEach((item, i) => {
        goldenIds[item.index] = insertedFresh[i].golden_customer_id;
    });

    // 3. Remove golden customers that no longer correspond to any entity.
    const used = new Set(goldenIds);
    const orphanIds = membershipSupported ? existingIds.filter((id) => !used.has(id)) : [];
    if (orphanIds.length) await deleteIn(TABLES.goldenCustomer, "golden_customer_id", orphanIds);

    // 4. Lineage + membership.
    const allLineage = entities.flatMap((entity, i) => lineageRows(entity, goldenIds[i]));
    const lineage = await insertMany(TABLES.goldenLineage, allLineage, { returning: "lineage_id" });

    let membersInserted = 0;
    if (membershipSupported) {
        const allMembers = entities.flatMap((entity, i) => memberRows(entity, goldenIds[i]));
        membersInserted = (await insertMany(TABLES.goldenMember, allMembers, { returning: "golden_customer_id" })).length;
    }

    const recordToGoldenId = new Map();
    entities.forEach((entity, i) => {
        for (const member of entity.members) recordToGoldenId.set(member.record_id, goldenIds[i]);
    });

    const auditEntries = buildAuditEntries({
        entities,
        goldenIds,
        previousById,
        reusedIds: new Set(reused.map((item) => item.row.golden_customer_id)),
        orphanIds,
        reason
    });

    return {
        customersInserted: fresh.length,
        customersReused: reused.length,
        customersDeleted: membershipSupported ? orphanIds.length : existingIds.length,
        lineageInserted: lineage.length,
        membersInserted,
        membershipSupported,
        recordToGoldenId,
        auditEntries
    };
}

module.exports = {
    planGoldenIds,
    buildAuditEntries,
    replaceGoldenData
};
