const TABLES = require("../config/tables");
const { SOURCES } = require("../config/sources");
const {
  supabase,
  dbError,
  fetchAll,
  fetchIn,
  insertMany,
  count,
} = require("../utils/db");

const TABLE_BY_SOURCE = {
  [SOURCES.CORE_BANKING]: TABLES.rawCoreBanking,
  [SOURCES.CREDIT_CARD]: TABLES.rawCreditCard,
  [SOURCES.LOAN]: TABLES.rawLoan,
};

function tableFor(source) {
  const table = TABLE_BY_SOURCE[source];
  if (!table) throw new Error(`Unknown raw source: ${source}`);
  return table;
}

async function getCoreBankingRecords() {
  return fetchAll(TABLES.rawCoreBanking, { orderBy: "raw_id" });
}

async function getCreditCardRecords() {
  return fetchAll(TABLES.rawCreditCard, { orderBy: "raw_id" });
}

async function getLoanRecords() {
  return fetchAll(TABLES.rawLoan, { orderBy: "raw_id" });
}

async function getAllSourceRecords() {
  const [coreBanking, creditCard, loan] = await Promise.all([
    getCoreBankingRecords(),
    getCreditCardRecords(),
    getLoanRecords(),
  ]);

  return { coreBanking, creditCard, loan };
}

/** Insert already-mapped rows into the raw table for `source`; returns inserted rows (with raw_id). */
async function insertRecords(source, rows) {
  return insertMany(tableFor(source), rows);
}

async function getByRawIds(source, rawIds) {
  return fetchIn(tableFor(source), "raw_id", rawIds);
}

/** Column holding each source system's own customer identifier. */
const SOURCE_KEY_COLUMN = {
  [SOURCES.CORE_BANKING]: "customer_id",
  [SOURCES.CREDIT_CARD]: "cust_ref",
  [SOURCES.LOAN]: "loan_cust_id",
};

/**
 * Find raw records by their source-system id (CB001, CC-77821, LN001...).
 * Case-insensitive exact match across all three raw tables.
 */
async function findBySourceKey(key) {
  const pattern = String(key)
    .trim()
    .replace(/[\\%_]/g, (c) => `\\${c}`);
  if (!pattern) return [];

  const results = await Promise.all(
    Object.entries(SOURCE_KEY_COLUMN).map(async ([source, column]) => {
      const { data, error } = await supabase
        .from(tableFor(source))
        .select(`raw_id, ${column}`)
        .ilike(column, pattern)
        .limit(50);
      if (error) throw dbError("search", tableFor(source), error);
      return (data || []).map((row) => ({
        source,
        raw_id: row.raw_id,
        source_key: row[column],
      }));
    }),
  );

  return results.flat();
}

/** Customer-record counts (total) plus raw transactions, which are not matched. */
async function countAll() {
  const [coreBanking, creditCard, loan, transactions] = await Promise.all([
    count(TABLES.rawCoreBanking),
    count(TABLES.rawCreditCard),
    count(TABLES.rawLoan),
    count(TABLES.rawTransactions),
  ]);
  return {
    coreBanking,
    creditCard,
    loan,
    transactions,
    total: coreBanking + creditCard + loan,
  };
}

module.exports = {
  getCoreBankingRecords,
  getCreditCardRecords,
  getLoanRecords,
  getAllSourceRecords,
  insertRecords,
  getByRawIds,
  findBySourceKey,
  countAll,
};
