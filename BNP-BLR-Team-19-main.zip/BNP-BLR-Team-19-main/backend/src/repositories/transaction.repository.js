const TABLES = require("../config/tables");
const { supabase, dbError, fetchAll, insertMany, deleteAll } = require("../utils/db");

// ---- raw_transactions (source of truth) ----

const insertRawTransactions = (rows) => insertMany(TABLES.rawTransactions, rows, { returning: "raw_id" });

const getAllRawTransactions = () => fetchAll(TABLES.rawTransactions, { orderBy: "raw_id" });

// ---- bank_transactions (derived per golden customer) ----

async function getByGoldenId(goldenCustomerId, { limit = 100 } = {}) {
    const { data, error } = await supabase
        .from(TABLES.bankTransactions)
        .select("*")
        .eq("golden_customer_id", goldenCustomerId)
        .order("transaction_date", { ascending: false })
        .order("transaction_id", { ascending: false })
        .limit(limit);

    if (error) throw dbError("fetch", TABLES.bankTransactions, error);
    return data || [];
}

const insertBankTransactions = (rows) => insertMany(TABLES.bankTransactions, rows, { returning: "transaction_id" });

const clearBankTransactions = () => deleteAll(TABLES.bankTransactions, "transaction_id");

module.exports = {
    insertRawTransactions,
    getAllRawTransactions,
    getByGoldenId,
    insertBankTransactions,
    clearBankTransactions
};
