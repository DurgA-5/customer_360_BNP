const TABLES = require("../config/tables");
const { supabase, dbError } = require("../utils/db");

function normalizeStatus(status) {
    if (!status) return "PASSED";
    const s = String(status).toUpperCase();
    if (s === "FAILED" || s === "ERROR") return "FAILED";
    return "PASSED";
}

async function createJob(job = {}) {
    const payload = {
        cron_second: job.cron_second || "0",
        cron_minute: job.cron_minute || "*",
        cron_hour: job.cron_hour || "*",
        cron_day_of_month: job.cron_day_of_month || "*",
        cron_month: job.cron_month || "*",
        cron_day_of_week: job.cron_day_of_week || "*",
        ...job,
        status: normalizeStatus(job.status)
    };

    const { data, error } = await supabase
        .from(TABLES.batchJob)
        .insert(payload)
        .select()
        .single();

    if (error) throw dbError("insert into", TABLES.batchJob, error);
    return data;
}

async function updateJob(jobId, patch = {}) {
    const payload = {
        ...patch,
        completed_at: new Date().toISOString()
    };
    if (payload.status) {
        payload.status = normalizeStatus(payload.status);
    }

    const { data, error } = await supabase
        .from(TABLES.batchJob)
        .update(payload)
        .eq("batch_id", jobId)
        .select()
        .single();

    if (error) throw dbError("update", TABLES.batchJob, error);
    return data;
}

module.exports = { createJob, updateJob, normalizeStatus };
