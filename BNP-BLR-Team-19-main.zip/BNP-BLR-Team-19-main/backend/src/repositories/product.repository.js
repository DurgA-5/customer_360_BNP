/**
 * bank_account, credit_card, loan: derived tables keyed by golden_customer_id.
 * Rebuilt from raw tables after every matching run (product-rebuild.service).
 */
const TABLES = require("../config/tables");
const { fetchAll, insertMany, deleteAll } = require("../utils/db");

const byGolden = (table, orderBy) => (goldenCustomerId) =>
    fetchAll(table, {
        filter: (query) => query.eq("golden_customer_id", goldenCustomerId),
        orderBy
    });

const getAccountsByGoldenId = byGolden(TABLES.bankAccount, "account_id");
const getCreditCardsByGoldenId = byGolden(TABLES.creditCard, "credit_card_id");
const getLoansByGoldenId = byGolden(TABLES.loan, "loan_id");

const insertAccounts = (rows) => insertMany(TABLES.bankAccount, rows);
const insertCreditCards = (rows) => insertMany(TABLES.creditCard, rows, { returning: "credit_card_id" });
const insertLoans = (rows) => insertMany(TABLES.loan, rows, { returning: "loan_id" });

/**
 * Remove every derived row. Children first: bank_transactions references
 * bank_account, and all four reference golden_customer.
 */
async function clearDerived() {
    await deleteAll(TABLES.bankTransactions, "transaction_id");
    await deleteAll(TABLES.bankAccount, "account_id");
    await deleteAll(TABLES.creditCard, "credit_card_id");
    await deleteAll(TABLES.loan, "loan_id");
}

module.exports = {
    getAccountsByGoldenId,
    getCreditCardsByGoldenId,
    getLoansByGoldenId,
    insertAccounts,
    insertCreditCards,
    insertLoans,
    clearDerived
};
