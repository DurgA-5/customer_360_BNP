const TABLES = require("../config/tables");
const { supabase, dbError, isMissingTable } = require("../utils/db");

async function create(job) {
    const { data, error } = await supabase
        .from(TABLES.ingestionJob)
        .insert(job)
        .select()
        .single();

    if (error) throw dbError("insert into", TABLES.ingestionJob, error);
    return data;
}

async function update(jobId, patch) {
    const { data, error } = await supabase
        .from(TABLES.ingestionJob)
        .update({ ...patch, updated_at: new Date().toISOString() })
        .eq("job_id", jobId)
        .select()
        .single();

    if (error) throw dbError("update", TABLES.ingestionJob, error);
    return data;
}

async function findById(jobId) {
    const { data, error } = await supabase
        .from(TABLES.ingestionJob)
        .select("*")
        .eq("job_id", jobId)
        .maybeSingle();

    if (error) throw dbError("fetch", TABLES.ingestionJob, error);
    return data;
}

async function listRecent(limit = 10) {
    const { data, error } = await supabase
        .from(TABLES.ingestionJob)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);

    if (error) {
        if (isMissingTable(error)) return [];
        throw dbError("fetch", TABLES.ingestionJob, error);
    }
    return data || [];
}

module.exports = { create, update, findById, listRecent };
