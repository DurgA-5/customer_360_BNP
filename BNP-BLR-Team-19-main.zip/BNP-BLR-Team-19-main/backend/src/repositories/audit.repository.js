/**
 * audit_log (team schema): one row per change to an entity/field.
 *
 *   entity_type, entity_id (NOT NULL), field_name, old_value, new_value,
 *   source_system, source_raw_id, reason, changed_by, changed_at
 *
 * Auditing must never break the operation it describes, so failures are
 * logged and swallowed.
 */
const TABLES = require("../config/tables");
const { insertMany } = require("../utils/db");

function toRow(entry) {
    const str = (value) => (value === null || value === undefined ? null : String(value));
    return {
        entity_type: entry.entityType,
        entity_id: entry.entityId,
        field_name: entry.fieldName ?? null,
        old_value: str(entry.oldValue),
        new_value: str(entry.newValue),
        source_system: entry.sourceSystem ?? null,
        source_raw_id: entry.sourceRawId ?? null,
        reason: entry.reason ?? null,
        changed_by: entry.changedBy ?? "system"
    };
}

async function logMany(entries) {
    const rows = entries.filter((e) => e.entityType && e.entityId !== null && e.entityId !== undefined).map(toRow);
    if (!rows.length) return 0;
    try {
        return (await insertMany(TABLES.auditLog, rows, { returning: "audit_id" })).length;
    } catch (error) {
        console.warn(`[audit] ${rows.length} entries not recorded: ${error.message}`);
        return 0;
    }
}

const log = (entry) => logMany([entry]);

module.exports = { log, logMany };
