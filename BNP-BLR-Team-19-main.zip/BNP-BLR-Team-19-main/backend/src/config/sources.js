/**
 * Source-system registry.
 *
 * The frontend, CSV uploads and the Python engine historically used
 * slightly different names for the same system ("loan" vs "loan_system").
 * Everything is normalised to the canonical keys below at the API boundary.
 */
const SOURCES = Object.freeze({
    CORE_BANKING: "core_banking",
    CREDIT_CARD: "credit_card",
    LOAN: "loan",
    TRANSACTIONS: "transaction_data"
});

const ALIASES = {
    core: SOURCES.CORE_BANKING,
    core_banking: SOURCES.CORE_BANKING,
    "core-banking": SOURCES.CORE_BANKING,

    credit_card: SOURCES.CREDIT_CARD,
    "credit-card": SOURCES.CREDIT_CARD,
    card: SOURCES.CREDIT_CARD,

    loan: SOURCES.LOAN,
    loan_system: SOURCES.LOAN,
    "loan-system": SOURCES.LOAN,

    transaction_data: SOURCES.TRANSACTIONS,
    transactions: SOURCES.TRANSACTIONS
};

const LABELS = {
    [SOURCES.CORE_BANKING]: "Core Banking",
    [SOURCES.CREDIT_CARD]: "Credit Card",
    [SOURCES.LOAN]: "Loan System",
    [SOURCES.TRANSACTIONS]: "Transaction Data",
    mdm: "MDM"
};

// Prefix used for engine record ids, e.g. CB_42
const RECORD_PREFIX = {
    [SOURCES.CORE_BANKING]: "CB",
    [SOURCES.CREDIT_CARD]: "CC",
    [SOURCES.LOAN]: "LN"
};

function normalizeSource(value) {
    if (!value) return null;
    return ALIASES[String(value).trim().toLowerCase()] || null;
}

function sourceLabel(source) {
    return LABELS[source] || source || "Unknown";
}

function recordId(source, rawId) {
    return `${RECORD_PREFIX[source]}_${rawId}`;
}

module.exports = {
    SOURCES,
    RECORD_PREFIX,
    normalizeSource,
    sourceLabel,
    recordId
};
