/**
 * Single source of truth for table names (team schema: database/migrations).
 */
module.exports = Object.freeze({
    // Raw source data (source of truth)
    rawCoreBanking: "raw_core_banking",
    rawCreditCard: "raw_credit_card",
    rawLoan: "raw_loan",
    rawTransactions: "raw_transactions",

    // Golden records
    goldenCustomer: "golden_customer",
    goldenLineage: "golden_field_lineage",
    goldenMember: "golden_customer_member", // 007_mdm_support.sql

    // Derived per golden customer; rebuilt after every matching run
    bankAccount: "bank_account",
    creditCard: "credit_card",
    loan: "loan",
    bankTransactions: "bank_transactions",

    ingestionJob: "ingestion_job", // 007_mdm_support.sql
    auditLog: "audit_log",
    batchJob: "batch_jobs"
});
