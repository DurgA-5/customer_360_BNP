/**
 * Centralised, validated configuration.
 *
 * Every module reads config from here instead of process.env so that
 * missing variables fail fast at boot with a clear message.
 */
require("dotenv").config();

function required(name) {
    const value = process.env[name];
    if (!value) {
        throw new Error(`Missing required environment variable: ${name}`);
    }
    return value;
}

function bool(name, fallback) {
    const value = process.env[name];
    if (value === undefined || value === "") return fallback;
    return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}

const env = {
    nodeEnv: process.env.NODE_ENV || "development",
    port: Number(process.env.PORT) || 5000,

    supabaseUrl: required("SUPABASE_URL"),
    // Prefer the service-role key on the server; fall back to anon for local dev.
    supabaseKey:
        process.env.SUPABASE_SERVICE_ROLE_KEY || required("SUPABASE_ANON_KEY"),

    engineUrl: (process.env.ENGINE_URL || "http://localhost:8000").replace(/\/+$/, ""),
    engineTimeoutMs: Number(process.env.ENGINE_TIMEOUT_MS) || 120000,

    // Comma-separated list of allowed browser origins. "*" allows all (dev only).
    corsOrigins: (process.env.CORS_ORIGINS || "*")
        .split(",")
        .map((origin) => origin.trim())
        .filter(Boolean),

    // Re-run entity resolution after a customer form submit so the new record
    // is attached to (or creates) a golden customer immediately.
    autoMatchOnWrite: bool("AUTO_MATCH_ON_WRITE", true),

    // Re-run entity resolution after every successful CSV ingestion job.
    autoMatchOnIngest: bool("AUTO_MATCH_ON_INGEST", true),

    maxUploadBytes: Number(process.env.MAX_UPLOAD_BYTES) || 10 * 1024 * 1024,

    batchFolderPath: process.env.BATCH_FOLDER_PATH || require("path").join(__dirname, "../../../engine/test_data")
};

module.exports = env;
