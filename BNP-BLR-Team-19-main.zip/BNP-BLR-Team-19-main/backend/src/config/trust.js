/**
 * Field-level trust hierarchy (1 = most trusted).
 * MUST stay identical to engine/app/config/trust_hierarchy.py - the engine
 * uses it to pick winners, the backend uses it to explain them.
 */
const FIELD_TRUST_HIERARCHY = Object.freeze({
  phone: { core_banking: 1, credit_card: 2, loan: 3 },
  email: { credit_card: 1, core_banking: 2, loan: 3 },
  name: { credit_card: 1, core_banking: 2, loan: 3 },
  address: { credit_card: 1, core_banking: 2, loan: 3 },
  dob: { core_banking: 1, credit_card: 2, loan: 3 },
});

const GOLDEN_FIELDS = ["name", "email", "phone", "address", "dob"];

const FIELD_LABELS = {
  name: "Name",
  email: "Email",
  phone: "Phone",
  address: "Address",
  dob: "Date of birth",
};

/** Sources for a field, most trusted first: [{ source, rank }] */
function priorityFor(field) {
  return Object.entries(FIELD_TRUST_HIERARCHY[field] || {})
    .map(([source, rank]) => ({ source, rank }))
    .sort((a, b) => a.rank - b.rank);
}

module.exports = {
  FIELD_TRUST_HIERARCHY,
  GOLDEN_FIELDS,
  FIELD_LABELS,
  priorityFor,
};
