/**
 * HTTP client for the Python MDM engine (FastAPI).
 *
 * The engine is stateless compute: records in -> matches, entity groups,
 * golden records and lineage out. All persistence stays in this backend.
 */
const env = require("../config/env");
const { AppError } = require("../utils/response");

async function request(path, { method = "GET", body } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), env.engineTimeoutMs);

    let response;
    try {
        response = await fetch(`${env.engineUrl}${path}`, {
            method,
            headers: body ? { "Content-Type": "application/json" } : undefined,
            body: body ? JSON.stringify(body) : undefined,
            signal: controller.signal
        });
    } catch (error) {
        const reason =
            error.name === "AbortError"
                ? `timed out after ${env.engineTimeoutMs}ms`
                : error.cause?.code || error.message;
        throw AppError.upstream(`MDM engine unreachable at ${env.engineUrl} (${reason})`);
    } finally {
        clearTimeout(timer);
    }

    const payload = await response.json().catch(() => null);

    if (!response.ok) {
        throw AppError.upstream(
            `MDM engine returned ${response.status}: ${payload?.detail || response.statusText}`
        );
    }

    return payload;
}

/**
 * @param {Array<object>} records engine records ({record_id, source, name, email, phone, address, dob, source_raw_id})
 * @returns {Promise<{match_results, entity_groups, golden_records, lineage}>}
 */
async function runMatching(records) {
    if (!records.length) {
        return { match_results: [], entity_groups: {}, golden_records: [], lineage: [] };
    }

    const payload = await request("/api/match", {
        method: "POST",
        body: { records }
    });

    return payload.data;
}

async function health() {
    return request("/api/health");
}

module.exports = {
    runMatching,
    health
};
