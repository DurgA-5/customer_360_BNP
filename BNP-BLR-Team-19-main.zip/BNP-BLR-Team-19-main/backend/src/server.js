const env = require("./config/env");
const app = require("./app");

const server = app.listen(env.port, () => {
    console.log(`UniBank MDM Backend running on http://localhost:${env.port}/api/v1`);
    console.log(`MDM engine: ${env.engineUrl}`);
});

function shutdown(signal) {
    console.log(`${signal} received, shutting down`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10000).unref();
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("unhandledRejection", (reason) => {
    console.error("Unhandled rejection:", reason);
});
