/**
 * Consistent response envelope for every endpoint:
 *
 *   success: { success: true,  data, meta? , message? }
 *   failure: { success: false, error: { code, message, details? } }
 */

class AppError extends Error {
    constructor(status, message, code = "ERROR", details = undefined) {
        super(message);
        this.name = "AppError";
        this.status = status;
        this.code = code;
        this.details = details;
    }

    static badRequest(message, details) {
        return new AppError(400, message, "BAD_REQUEST", details);
    }

    static notFound(message = "Resource not found") {
        return new AppError(404, message, "NOT_FOUND");
    }

    static upstream(message, details) {
        return new AppError(502, message, "UPSTREAM_ERROR", details);
    }
}

function ok(res, data, { status = 200, meta, message } = {}) {
    const body = { success: true, data };
    if (meta !== undefined) body.meta = meta;
    if (message !== undefined) body.message = message;
    return res.status(status).json(body);
}

function created(res, data, options = {}) {
    return ok(res, data, { ...options, status: 201 });
}

function accepted(res, data, options = {}) {
    return ok(res, data, { ...options, status: 202 });
}

/**
 * Wrap an async controller so rejected promises reach the error middleware.
 * (Express 5 does this natively, but being explicit keeps controllers portable.)
 */
const asyncHandler = (fn) => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch(next);

module.exports = {
    AppError,
    ok,
    created,
    accepted,
    asyncHandler
};
