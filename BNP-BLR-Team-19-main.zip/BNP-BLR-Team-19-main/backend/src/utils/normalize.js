/**
 * Field normalisation applied before records are stored.
 *
 * The Python engine does EXACT equality on email/phone and case-sensitive
 * fuzzy matching on name, so normalising consistently here directly
 * improves match quality.
 */

function clean(value) {
    if (value === undefined || value === null) return null;
    const text = String(value).replace(/\s+/g, " ").trim();
    return text === "" ? null : text;
}

function titleCase(text) {
    return text
        .toLowerCase()
        .replace(/\b([a-z])/g, (char) => char.toUpperCase());
}

function normalizeName(value) {
    const text = clean(value);
    if (!text) return null;
    return titleCase(text.replace(/[^\p{L}\p{M}\s.'-]/gu, "").replace(/\s+/g, " ").trim()) || null;
}

function normalizeEmail(value) {
    const text = clean(value);
    return text ? text.toLowerCase() : null;
}

/**
 * Keeps the last 10 digits so "+91 98765-43210", "09876543210" and
 * "9876543210" all normalise to the same value.
 */
function normalizePhone(value) {
    const text = clean(value);
    if (!text) return null;
    const digits = text.replace(/\D/g, "");
    if (!digits) return null;
    return digits.length > 10 ? digits.slice(-10) : digits;
}

const ADDRESS_ABBREVIATIONS = [
    [/\brd\b\.?/gi, "Road"],
    [/\bst\b\.?/gi, "Street"],
    [/\bave?\b\.?/gi, "Avenue"],
    [/\bm\s*g\b/gi, "MG"]
];

function normalizeAddress(value) {
    let text = clean(value);
    if (!text) return null;
    text = text.replace(/\s*,\s*/g, ", ");
    for (const [pattern, replacement] of ADDRESS_ABBREVIATIONS) {
        text = text.replace(pattern, replacement);
    }
    return titleCase(text).replace(/\bMg\b/g, "MG");
}

/**
 * Accepts YYYY-MM-DD, DD-MM-YYYY, DD/MM/YYYY. Returns ISO date or null.
 */
function normalizeDate(value) {
    const text = clean(value);
    if (!text) return null;

    let match = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (match) return toIso(match[1], match[2], match[3]);

    match = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
    if (match) return toIso(match[3], match[2], match[1]);

    return null;
}

function toIso(year, month, day) {
    const y = Number(year);
    const m = Number(month);
    const d = Number(day);
    const date = new Date(Date.UTC(y, m - 1, d));
    if (
        date.getUTCFullYear() !== y ||
        date.getUTCMonth() !== m - 1 ||
        date.getUTCDate() !== d
    ) {
        return null;
    }
    return `${year.padStart(4, "0")}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

function normalizeAmount(value) {
    const text = clean(value);
    if (!text) return null;
    const number = Number(text.replace(/[,₹\s]/g, ""));
    return Number.isFinite(number) ? number : null;
}

module.exports = {
    clean,
    normalizeName,
    normalizeEmail,
    normalizePhone,
    normalizeAddress,
    normalizeDate,
    normalizeAmount
};
