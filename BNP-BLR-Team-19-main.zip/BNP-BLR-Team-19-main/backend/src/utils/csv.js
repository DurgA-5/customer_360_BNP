const { parse } = require("csv-parse/sync");
const { AppError } = require("./response");

/**
 * Parse a CSV buffer into objects keyed by lower_snake_case headers.
 * "Customer ID" / "customerId" / "customer_id" all become "customer_id".
 */
function parseCsv(buffer) {
    let rows;
    try {
        rows = parse(buffer, {
            columns: (headers) => headers.map(toSnakeCase),
            skip_empty_lines: true,
            trim: true,
            bom: true,
            relax_column_count: true
        });
    } catch (error) {
        throw AppError.badRequest(`Invalid CSV: ${error.message}`);
    }

    if (!rows.length) {
        throw AppError.badRequest("CSV file has no data rows");
    }

    return rows;
}

function toSnakeCase(header) {
    return String(header)
        .trim()
        .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
        .replace(/[^a-zA-Z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "")
        .toLowerCase();
}

/** First non-empty value among candidate column names. */
function pick(row, ...columns) {
    for (const column of columns) {
        const value = row[column];
        if (value !== undefined && value !== null && String(value).trim() !== "") {
            return value;
        }
    }
    return null;
}

module.exports = { parseCsv, pick, toSnakeCase };
