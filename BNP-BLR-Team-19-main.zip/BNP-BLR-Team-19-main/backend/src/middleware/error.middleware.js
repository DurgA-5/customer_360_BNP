const multer = require("multer");
const { AppError } = require("../utils/response");

function notFoundHandler(req, res) {
    res.status(404).json({
        success: false,
        error: {
            code: "ROUTE_NOT_FOUND",
            message: `Route ${req.method} ${req.originalUrl} not found`
        }
    });
}

// eslint-disable-next-line no-unused-vars
function errorMiddleware(err, req, res, next) {
    let status = 500;
    let code = "INTERNAL_ERROR";
    let message = "Internal Server Error";
    let details;

    if (err instanceof AppError) {
        ({ status, code, message, details } = err);
    } else if (err instanceof multer.MulterError) {
        status = 400;
        code = err.code;
        message =
            err.code === "LIMIT_FILE_SIZE"
                ? "File is too large"
                : err.message;
    } else if (err?.type === "entity.parse.failed") {
        status = 400;
        code = "INVALID_JSON";
        message = "Request body is not valid JSON";
    } else if (err?.message) {
        message = err.message;
    }

    if (status >= 500) {
        console.error(`[${req.method} ${req.originalUrl}]`, err);
    }

    res.status(status).json({
        success: false,
        error: { code, message, ...(details ? { details } : {}) }
    });
}

module.exports = errorMiddleware;
module.exports.notFoundHandler = notFoundHandler;
