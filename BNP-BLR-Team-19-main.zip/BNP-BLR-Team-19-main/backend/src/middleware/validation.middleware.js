/**
 * Minimal declarative body validation (no extra dependency).
 *
 * schema = {
 *   name:  { required: true, type: "string", maxLength: 200 },
 *   email: { type: "email" },
 *   phone: { required: true, type: "phone" },
 *   dob:   { type: "date" },
 *   creditLimit: { required: true, type: "number", min: 0 }
 * }
 */
const { AppError } = require("../utils/response");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function checkField(field, rule, value) {
    const isEmpty = value === undefined || value === null || String(value).trim() === "";

    if (isEmpty) {
        return rule.required ? `${field} is required` : null;
    }

    switch (rule.type) {
        case "string":
            if (typeof value !== "string") return `${field} must be a string`;
            break;
        case "email":
            if (!EMAIL_RE.test(String(value).trim())) return `${field} must be a valid email`;
            break;
        case "phone": {
            const digits = String(value).replace(/\D/g, "");
            if (digits.length < 10 || digits.length > 13) return `${field} must be a valid phone number`;
            break;
        }
        case "date":
            if (!DATE_RE.test(String(value)) || Number.isNaN(Date.parse(value))) {
                return `${field} must be a date in YYYY-MM-DD format`;
            }
            if (rule.past && new Date(value) > new Date()) return `${field} cannot be in the future`;
            break;
        case "number": {
            const number = Number(value);
            if (!Number.isFinite(number)) return `${field} must be a number`;
            if (rule.min !== undefined && number < rule.min) return `${field} must be at least ${rule.min}`;
            break;
        }
        default:
            break;
    }

    if (rule.maxLength && String(value).length > rule.maxLength) {
        return `${field} must be at most ${rule.maxLength} characters`;
    }

    return null;
}

function validateBody(schema) {
    return (req, res, next) => {
        const body = req.body || {};
        const errors = {};

        for (const [field, rule] of Object.entries(schema)) {
            const message = checkField(field, rule, body[field]);
            if (message) errors[field] = message;
        }

        if (Object.keys(errors).length) {
            return next(AppError.badRequest("Validation failed", errors));
        }

        next();
    };
}

module.exports = { validateBody };
