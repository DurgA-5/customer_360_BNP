const multer = require("multer");
const env = require("../config/env");
const { AppError } = require("../utils/response");

const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
        fileSize: env.maxUploadBytes,
        files: 1
    },
    fileFilter: (req, file, cb) => {
        const isCsv =
            file.originalname.toLowerCase().endsWith(".csv") ||
            ["text/csv", "application/vnd.ms-excel"].includes(file.mimetype);

        if (isCsv) {
            cb(null, true);
        } else {
            cb(AppError.badRequest("Only CSV files are allowed"));
        }
    }
});

module.exports = { upload };
