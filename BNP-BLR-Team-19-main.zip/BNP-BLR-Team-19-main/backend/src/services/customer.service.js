/**
 * Golden customer read model: search, profile, products, transactions,
 * lineage (with source trace), Customer 360 and the customer-portal lookup.
 */
const { sourceLabel } = require("../config/sources");
const { AppError } = require("../utils/response");
const customerRepository = require("../repositories/customer.repository");
const productRepository = require("../repositories/product.repository");
const transactionRepository = require("../repositories/transaction.repository");
const { GOLDEN_FIELDS, FIELD_LABELS } = require("../config/trust");
const { explainLineage } = require("./lineage-explain.service");

const IDENTITY_FIELDS = ["name", "email", "phone", "dob", "address"];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const formatGoldenId = (id) => `GC-${id}`;

/** Accepts "GC-12", "gc-12" or "12". */
function parseCustomerId(value) {
  const match = String(value ?? "")
    .trim()
    .match(/^(?:gc-?)?(\d+)$/i);
  if (!match)
    throw AppError.badRequest(
      `Invalid customer id "${value}". Expected e.g. GC-12`,
    );
  return Number(match[1]);
}

function isValidField(field, value) {
  switch (field) {
    case "email":
      return EMAIL_RE.test(value);
    case "phone":
      return /^\d{10}$/.test(String(value));
    case "dob":
      return !Number.isNaN(Date.parse(value));
    default:
      return String(value).trim().length > 0;
  }
}

/** Completeness = populated fields / 5. Quality = completeness weighted with validity. */
function scoreCustomer(row) {
  const populated = IDENTITY_FIELDS.filter((field) => row[field]);
  const valid = populated.filter((field) => isValidField(field, row[field]));

  const completeness = Math.round(
    (populated.length / IDENTITY_FIELDS.length) * 100,
  );
  const validity = populated.length
    ? Math.round((valid.length / populated.length) * 100)
    : 0;

  return {
    profileCompleteness: completeness,
    qualityScore: Math.round(completeness * 0.6 + validity * 0.4),
  };
}

function formatCustomer(row) {
  return {
    id: row.golden_customer_id,
    goldenCustomerId: formatGoldenId(row.golden_customer_id),
    name: row.name,
    email: row.email,
    phone: row.phone,
    dob: row.dob,
    address: row.address,
    ...scoreCustomer(row),
  };
}

function formatLineage(rows) {
  return rows.map((row) => ({
    field: row.field_name,
    goldenValue: row.golden_value,
    source: row.source_system,
    sourceLabel: sourceLabel(row.source_system),
    sourceRawId: row.source_raw_id,
    sourceValue: row.source_value,
    ruleUsed: row.rule_used,
  }));
}

/**
 * Lineage for all five golden fields, each with its source trace:
 * winning source + raw record, the priority chain and a plain-language "why".
 */
async function buildExplainedLineage(goldenId, { members, lineageRows } = {}) {
  const [memberRows, rows] = await Promise.all([
    members || customerRepository.getMembers(goldenId),
    lineageRows || customerRepository.getLineage(goldenId),
  ]);
  const explanations = await explainLineage(memberRows, rows);
  const byField = new Map(
    formatLineage(rows).map((item) => [item.field, item]),
  );

  return GOLDEN_FIELDS.map((field) => {
    const item = byField.get(field) || {
      field,
      goldenValue: null,
      source: null,
      sourceLabel: null,
      sourceRawId: null,
      sourceValue: null,
      ruleUsed: null,
    };
    const explanation = explanations.get(field);
    return {
      ...item,
      fieldLabel: FIELD_LABELS[field],
      why: explanation.why,
      priority: explanation.priority,
      candidates: explanation.candidates,
    };
  });
}

async function requireCustomer(goldenId) {
  const row = await customerRepository.findById(goldenId);
  if (!row)
    throw AppError.notFound(`Customer ${formatGoldenId(goldenId)} not found`);
  return row;
}

async function loadProducts(goldenId) {
  const [accounts, creditCards, loans] = await Promise.all([
    productRepository.getAccountsByGoldenId(goldenId),
    productRepository.getCreditCardsByGoldenId(goldenId),
    productRepository.getLoansByGoldenId(goldenId),
  ]);
  return { accounts, creditCards, loans };
}

const toNumber = (value) =>
  value === null || value === undefined ? null : Number(value);

function formatProducts({ accounts, creditCards, loans }) {
  return {
    accounts: accounts.map((row) => ({
      id: row.account_id,
      accountId: `ACC-${row.account_id}`,
      sourceAccountId: row.source_account_id,
      accountType: row.account_type,
      openedDate: row.opened_date,
      status: row.status,
    })),
    creditCards: creditCards.map((row) => ({
      id: row.credit_card_id,
      creditCardId: `CARD-${row.credit_card_id}`,
      sourceCustRef: row.source_cust_ref,
      creditLimit: toNumber(row.credit_limit),
    })),
    loans: loans.map((row) => ({
      id: row.loan_id,
      loanId: `LOAN-${row.loan_id}`,
      sourceLoanCustId: row.source_loan_cust_id,
      loanAmount: toNumber(row.loan_amt),
    })),
  };
}

function formatTransactions(rows) {
  return rows.map((row) => ({
    id: row.transaction_id,
    transactionId: `TXN-${row.transaction_id}`,
    accountId:
      row.source_account_id ||
      (row.account_id ? `ACC-${row.account_id}` : null),
    amount: toNumber(row.amount),
    transactionDate: row.transaction_date,
    type: row.type,
  }));
}

function summarizeSources(members) {
  const counts = {};
  for (const member of members) {
    counts[member.source_system] = (counts[member.source_system] || 0) + 1;
  }
  return Object.entries(counts).map(([source, recordCount]) => ({
    source,
    label: sourceLabel(source),
    records: recordCount,
  }));
}

// ---------------------------------------------------------------------------

async function search({ q, page = 1, limit = 20 }) {
  const safeLimit = Math.min(Math.max(Number(limit) || 20, 1), 100);
  const safePage = Math.max(Number(page) || 1, 1);
  const term = (q || "").trim();

  // "GC-12" searches by id; anything else searches name / email / phone.
  const idMatch = term.match(/^gc-?(\d+)$/i);

  const { rows, total } = await customerRepository.search({
    q: idMatch ? undefined : term,
    goldenId: idMatch ? Number(idMatch[1]) : undefined,
    limit: safeLimit,
    offset: (safePage - 1) * safeLimit,
  });

  return {
    customers: rows.map(formatCustomer),
    meta: {
      total,
      page: safePage,
      limit: safeLimit,
      totalPages: Math.max(Math.ceil(total / safeLimit), 1),
    },
  };
}

async function getProfile(customerId) {
  const goldenId = parseCustomerId(customerId);
  const [row, members] = await Promise.all([
    requireCustomer(goldenId),
    customerRepository.getMembers(goldenId),
  ]);
  return { ...formatCustomer(row), sources: summarizeSources(members) };
}

async function getProducts(customerId) {
  const goldenId = parseCustomerId(customerId);
  await requireCustomer(goldenId);
  return formatProducts(await loadProducts(goldenId));
}

async function getTransactions(customerId, { limit } = {}) {
  const goldenId = parseCustomerId(customerId);
  await requireCustomer(goldenId);
  return {
    transactions: formatTransactions(
      await transactionRepository.getByGoldenId(goldenId, { limit }),
    ),
  };
}

async function getLineage(customerId) {
  const goldenId = parseCustomerId(customerId);
  await requireCustomer(goldenId);
  return buildExplainedLineage(goldenId);
}

/** Everything the admin Customer 360 page needs in one round trip. */
async function get360(customerId) {
  const goldenId = parseCustomerId(customerId);

  const [row, members, lineageRows] = await Promise.all([
    requireCustomer(goldenId),
    customerRepository.getMembers(goldenId),
    customerRepository.getLineage(goldenId),
  ]);

  const [rawProducts, transactionRows, lineage] = await Promise.all([
    loadProducts(goldenId),
    transactionRepository.getByGoldenId(goldenId),
    buildExplainedLineage(goldenId, { members, lineageRows }),
  ]);

  return {
    customer: { ...formatCustomer(row), sources: summarizeSources(members) },
    products: formatProducts(rawProducts),
    transactions: formatTransactions(transactionRows),
    lineage,
    members: members.map((member) => ({
      source: member.source_system,
      sourceLabel: sourceLabel(member.source_system),
      sourceRawId: member.source_raw_id,
      recordId: member.record_id || null,
    })),
  };
}

// ---------------------------------------------------------------------------
// Customer portal: "do we already know you?"
// ---------------------------------------------------------------------------

function maskPhone(phone) {
  return phone ? `******${String(phone).slice(-4)}` : null;
}

function maskEmail(email) {
  if (!email) return null;
  const [user, domain] = String(email).split("@");
  return `${user.slice(0, 2)}***@${domain}`;
}

/** Public (masked) view of a golden customer for lookup results. */
function toPublicCustomer(row) {
  return {
    goldenCustomerId: formatGoldenId(row.golden_customer_id),
    firstName: row.name ? row.name.split(" ")[0] : null,
    phone: maskPhone(row.phone),
    email: maskEmail(row.email),
  };
}

function lookupResult(rows, matchedOn, extra = {}) {
  return {
    found: rows.length > 0,
    status:
      rows.length === 0 ? "new" : rows.length === 1 ? "existing" : "conflict",
    matchedOn,
    customers: rows.map(toPublicCustomer),
    ...extra,
  };
}

/**
 * Look a person up in the golden table by the phone and/or email they type.
 * Returns only masked details: there is no login yet, so anyone can call this.
 */
async function lookupByContact({ phone, email }) {
  // Required lazily: golden-lookup.service depends on this module.
  const goldenLookup = require("./golden-lookup.service");
  const check = await goldenLookup.lookupContact({ phone, email });

  return {
    found: check.status !== "new",
    status: check.status,
    matchedOn: check.matchedOn,
    customers: check.customers.map(toPublicCustomer),
  };
}

/**
 * One search box for the customer portal. Detects what was typed:
 *   GC-12                    -> golden customer id
 *   something@domain         -> email
 *   10+ digits (+91, spaces) -> phone
 *   anything else            -> source-system id (customer_id / cust_ref / loan_cust_id)
 */
async function lookupByQuery(query) {
  const term = String(query || "").trim();
  if (!term)
    throw AppError.badRequest("Enter a customer ID, phone number or email");

  const goldenMatch = term.match(/^gc-?(\d+)$/i);
  if (goldenMatch) {
    const row = await customerRepository.findById(Number(goldenMatch[1]));
    return lookupResult(row ? [row] : [], ["customer_id"], {
      searchType: "golden_id",
    });
  }

  if (term.includes("@")) {
    return { ...(await lookupByContact({ email: term })), searchType: "email" };
  }

  if (/^[+\d\s()-]+$/.test(term) && term.replace(/\D/g, "").length >= 10) {
    return { ...(await lookupByContact({ phone: term })), searchType: "phone" };
  }

  // Source-system id: find the raw records, then the golden customers they belong to.
  const rawRepository = require("../repositories/raw.repository");
  const records = await rawRepository.findBySourceKey(term);
  const goldenIds = await customerRepository.findGoldenIdsForRecords(records);
  const rows = await customerRepository.findByIds(goldenIds);

  return lookupResult(rows, ["source_id"], {
    searchType: "source_id",
    sources: [...new Set(records.map((r) => sourceLabel(r.source)))],
    // Record exists but matching hasn't linked it yet.
    pendingMatch: records.length > 0 && rows.length === 0,
  });
}

module.exports = {
  buildExplainedLineage,
  lookupByContact,
  lookupByQuery,
  parseCustomerId,
  formatGoldenId,
  scoreCustomer,
  search,
  getProfile,
  getProducts,
  getTransactions,
  getLineage,
  get360,
};
