/**
 * Customer-portal writes: a customer opens a Core Banking account, a Credit
 * Card or a Loan. Each stores a raw source record, then re-runs entity
 * resolution, which links the record to a golden customer and rebuilds that
 * customer's bank_account / credit_card / loan rows.
 */
const env = require("../config/env");
const { SOURCES, recordId, sourceLabel } = require("../config/sources");
const { AppError } = require("../utils/response");
const rawRepository = require("../repositories/raw.repository");
const customerRepository = require("../repositories/customer.repository");
const auditRepository = require("../repositories/audit.repository");
const matchingService = require("./matching.service");
const goldenLookup = require("./golden-lookup.service");
const { toRawRow } = require("./source-mapping");
const {
  formatGoldenId,
  parseCustomerId,
  buildExplainedLineage,
} = require("./customer.service");

/** camelCase request body -> snake_case input understood by source-mapping. */
const BODY_TO_INPUT = {
  [SOURCES.CORE_BANKING]: (b) => ({
    customer_id: b.customerId,
    name: b.name,
    email: b.email,
    phone: b.phone,
    dob: b.dob,
    address: b.address,
  }),
  [SOURCES.CREDIT_CARD]: (b) => ({
    cust_ref: b.custRef,
    name: b.name,
    email: b.email,
    phone: b.phone,
    address: b.address,
    credit_limit: b.creditLimit,
  }),
  [SOURCES.LOAN]: (b) => ({
    loan_cust_id: b.loanCustId,
    name: b.name,
    phone: b.phone,
    address: b.address,
    loan_amt: b.loanAmount,
  }),
};

const RAW_TABLE = {
  [SOURCES.CORE_BANKING]: "raw_core_banking",
  [SOURCES.CREDIT_CARD]: "raw_credit_card",
  [SOURCES.LOAN]: "raw_loan",
};

const PRODUCT_NAME = {
  [SOURCES.CORE_BANKING]: "savings account",
  [SOURCES.CREDIT_CARD]: "credit card",
  [SOURCES.LOAN]: "loan",
};

/** Customer-facing message for the result of the golden check + matching. */
function buildMessage(source, check, goldenCustomerId) {
  const label = PRODUCT_NAME[source];
  if (!goldenCustomerId) {
    return `Your ${label} was saved. Your profile will be linked shortly.`;
  }
  if (check.status === "existing") {
    return `Welcome back! Your ${label} was added to your existing profile ${goldenCustomerId}.`;
  }
  if (check.status === "conflict") {
    return `Your ${label} was saved and your profiles ${check.goldenIds.map(formatGoldenId).join(" and ")} were combined into ${goldenCustomerId}.`;
  }
  return `Welcome to UniBank! Your new customer profile ${goldenCustomerId} was created with your ${label}.`;
}

/**
 * Source trace for one incremental record: for each golden field, the value
 * before this record arrived, the value now, which source supplied it and why.
 */
async function buildTrace({ beforeRow, goldenCustomerId, source, rawId }) {
  const goldenId = parseCustomerId(goldenCustomerId);
  const lineage = await buildExplainedLineage(goldenId);

  const fields = lineage.map((item) => {
    const before = beforeRow ? (beforeRow[item.field] ?? null) : null;
    const now = item.goldenValue ?? null;
    const changed = String(before ?? "") !== String(now ?? "");
    return {
      field: item.field,
      label: item.fieldLabel,
      before,
      now,
      changed,
      source: item.source,
      sourceLabel: item.sourceLabel,
      sourceRawId: item.sourceRawId,
      // Did the record just submitted supply this value?
      fromThisRecord:
        item.source === source && Number(item.sourceRawId) === Number(rawId),
      why: item.why,
    };
  });

  return {
    isNewCustomer: !beforeRow,
    changedCount: fields.filter((f) => f.changed).length,
    fromThisRecordCount: fields.filter((f) => f.fromThisRecord).length,
    fields,
  };
}

async function createSourceRecord(source, body) {
  const { row, error } = toRawRow(source, BODY_TO_INPUT[source](body));
  if (error) throw AppError.badRequest(error);

  // 1. Is this person already in the golden table? (phone OR email)
  const check = await goldenLookup.lookupContact({
    phone: row.phone,
    email: row.email,
  });

  // Snapshot of the existing golden record, to show what this record changes.
  const beforeRow =
    check.customers.find((c) => c.golden_customer_id === check.goldenIds[0]) ||
    null;

  // 2. Usual process: store the raw record, then run matching.
  const [rawRow] = await rawRepository.insertRecords(source, [row]);
  const engineRecordId = recordId(source, rawRow.raw_id);

  auditRepository.log({
    entityType: RAW_TABLE[source],
    entityId: rawRow.raw_id,
    sourceSystem: source,
    sourceRawId: rawRow.raw_id,
    reason: "Source record created via customer portal",
    changedBy: "customer_portal",
  });

  const response = {
    source,
    sourceLabel: sourceLabel(source),
    rawId: rawRow.raw_id,
    recordId: engineRecordId,
    goldenCheck: {
      status: check.status, // existing | conflict | new
      matchedOn: check.matchedOn,
      existingCustomerIds: check.goldenIds.map(formatGoldenId),
    },
    goldenCustomerId: null,
    matching: { status: "skipped" },
  };

  if (!env.autoMatchOnWrite) {
    response.message = buildMessage(source, check, null);
    return response;
  }

  try {
    const { summary, recordToGoldenId } =
      await matchingService.runMatchingFromDatabase({
        trigger: `portal:${engineRecordId}`,
      });
    const goldenId =
      recordToGoldenId.get(engineRecordId) ??
      (await customerRepository.findGoldenIdForRecord(source, rawRow.raw_id));

    response.goldenCustomerId = goldenId ? formatGoldenId(goldenId) : null;
    response.matching = { status: "completed", summary };
  } catch (matchError) {
    // The raw record is saved; it is linked (and its product created) on the next successful run.
    response.matching = { status: "failed", message: matchError.message };
  }

  if (response.goldenCustomerId) {
    try {
      // "Before" is the customer the pre-check found. If matching put the record
      // somewhere else (e.g. a merge), there is no meaningful before-state.
      const sameCustomer =
        beforeRow &&
        formatGoldenId(beforeRow.golden_customer_id) ===
          response.goldenCustomerId;
      response.trace = await buildTrace({
        beforeRow: sameCustomer ? beforeRow : null,
        goldenCustomerId: response.goldenCustomerId,
        source,
        rawId: rawRow.raw_id,
      });
    } catch (traceError) {
      // The trace is informational; never fail the submission because of it.
      console.warn("[source] could not build trace:", traceError.message);
    }
  }

  response.message = buildMessage(source, check, response.goldenCustomerId);
  return response;
}

module.exports = {
  createCoreBanking: (body) => createSourceRecord(SOURCES.CORE_BANKING, body),
  createCreditCard: (body) => createSourceRecord(SOURCES.CREDIT_CARD, body),
  createLoan: (body) => createSourceRecord(SOURCES.LOAN, body),
};
