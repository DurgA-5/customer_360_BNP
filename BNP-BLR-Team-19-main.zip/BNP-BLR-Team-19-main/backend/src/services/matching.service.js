const engineClient = require("../clients/engine.client");
const mdmRecordService = require("./mdm-record.service");
const productRebuildService = require("./product-rebuild.service");
const rawRepository = require("../repositories/raw.repository");
const goldenRepository = require("../repositories/golden.repository");
const productRepository = require("../repositories/product.repository");
const auditRepository = require("../repositories/audit.repository");

/*
 * A matching run rewrites golden_customer, lineage, membership and the
 * derived product tables as a whole, so two concurrent runs (e.g. a CSV
 * upload finishing while a customer submits a form) would interleave their
 * deletes and inserts. Serialise runs inside this process. (Multiple backend
 * instances would need a Postgres advisory lock instead.)
 */
let queue = Promise.resolve();
let lastRun = null;
let running = false;

function withMatchingLock(task) {
    const run = queue.then(async () => {
        running = true;
        try {
            return await task();
        } finally {
            running = false;
        }
    });
    queue = run.catch(() => {});
    return run;
}

function getMatchingState() {
    return { running, lastRun };
}

/**
 * raw_* -> engine -> golden_customer (+ lineage, membership, audit_log)
 *       -> rebuild bank_account / credit_card / loan / bank_transactions
 */
async function runMatchingFromDatabase({ trigger = "manual" } = {}) {
    return withMatchingLock(async () => {
        const startedAt = Date.now();

        const raw = await rawRepository.getAllSourceRecords();
        const records = mdmRecordService.toEngineRecords(raw);

        // Engine first: if it fails, nothing in the database has been touched.
        const result = await engineClient.runMatching(records);

        const recordLookup = new Map(records.map((record) => [record.record_id, record]));
        const lineageByEntity = new Map(
            (result.lineage || []).map((item) => [item.entity_id, item.lineage])
        );

        const entities = (result.golden_records || []).map((golden) => ({
            golden_record: golden.golden_record,
            lineage: lineageByEntity.get(golden.entity_id) || {},
            members: golden.members.map((memberId) => {
                const record = recordLookup.get(memberId);
                return {
                    record_id: memberId,
                    source: record?.source,
                    source_raw_id: record?.source_raw_id
                };
            })
        }));

        // Derived tables reference golden_customer, so clear them before it changes...
        await productRepository.clearDerived();

        const persisted = await goldenRepository.replaceGoldenData(entities, {
            reason: `MATCHING_RUN (${trigger})`
        });

        // ...and rebuild them against the (stable) golden ids.
        const products = await productRebuildService.rebuildAll(raw, persisted.recordToGoldenId);

        const auditEntries = await auditRepository.logMany(persisted.auditEntries);

        const summary = {
            input_records: records.length,
            entity_groups: Object.keys(result.entity_groups || {}).length,
            golden_records: entities.length,
            customers_inserted: persisted.customersInserted,
            customers_reused: persisted.customersReused,
            customers_deleted: persisted.customersDeleted,
            lineage_inserted: persisted.lineageInserted,
            members_inserted: persisted.membersInserted,
            stable_ids: persisted.membershipSupported,
            products,
            audit_entries: auditEntries,
            duration_ms: Date.now() - startedAt
        };

        lastRun = { trigger, finishedAt: new Date().toISOString(), summary };
        console.log(
            `[matching] ${trigger}: ${records.length} records -> ${entities.length} golden customers ` +
            `(${products.accounts} accounts, ${products.credit_cards} cards, ${products.loans} loans, ` +
            `${products.transactions} transactions)`
        );

        return {
            summary,
            recordToGoldenId: persisted.recordToGoldenId
        };
    });
}

/** Transactions-only upload: re-attach raw_transactions without re-matching. */
async function rebuildTransactions() {
    return withMatchingLock(() => productRebuildService.rebuildTransactions());
}


async function dryRunMatchingFromDatabase() {

    const records =
        await mdmRecordService.getMDMRecords();

    console.log(
        `Fetched ${records.length} records from Supabase`
    );


    // Send records to Python MDM engine.
    // (Kept in the { data } shape the analysis below was written against.)
    const result = {
        data: await engineClient.runMatching(records)
    };


    const goldenRecords =
        result.data.golden_records || [];

    const matchResults =
        result.data.match_results || [];


    // Count MATCH results
    const matches =
        matchResults.filter(
            (item) =>
                item.decision === "MATCH"
        ).length;


    // Count NO_MATCH results
    const noMatches =
        matchResults.filter(
            (item) =>
                item.decision === "NO_MATCH"
        ).length;


    /*
     * Fuzzy matches are matches that contain
     * a name_score.
     */
    const fuzzyMatches =
        matchResults.filter(
            (item) =>
                item.decision === "MATCH" &&
                item.name_score !== undefined
        );


    // ============================================
    // MATCHING VALIDATION STATISTICS
    // ============================================

    /*
     * Count exact matches.
     *
     * Exact matches are created using
     * exact email or exact phone.
     */
    const exactMatches =
        matchResults.filter(
            (item) =>
                item.decision === "MATCH" &&
                item.match_type === "EXACT"
        );


    /*
     * Count fuzzy name matches.
     */
    const fuzzyNameMatches =
        matchResults.filter(
            (item) =>
                item.decision === "MATCH" &&
                item.match_type === "FUZZY_NAME"
        );


    /*
     * Map every record to the entity
     * to which it currently belongs.
     *
     * Example:
     *
     * CB_001 -> entity A
     * CC_001 -> entity A
     * LN_001 -> entity A
     */
    const entityGroupByRecord = {};


    for (
        const [entityId, memberIds]
        of Object.entries(
            result.data.entity_groups || {}
        )
    ) {

        for (const recordId of memberIds) {

            entityGroupByRecord[recordId] =
                entityId;
        }
    }


    /*
     * Find fuzzy matches where the two
     * records belong to DIFFERENT entities.
     *
     * These are important because they are
     * fuzzy suggestions that did NOT create
     * an entity merge.
     */
    const fuzzyCrossEntityMatches =
        fuzzyNameMatches.filter(
            (match) =>
                entityGroupByRecord[
                    match.record_a
                ] !==
                entityGroupByRecord[
                    match.record_b
                ]
        );


    /*
     * Convert entity groups into an array.
     */
    const entityGroups =
        Object.values(
            result.data.entity_groups || {}
        );


    /*
     * Entities containing more than
     * one source record.
     */
    const multiRecordEntities =
        entityGroups.filter(
            (members) =>
                members.length > 1
        );


    /*
     * Entities containing only one
     * source record.
     */
    const singletonEntities =
        entityGroups.filter(
            (members) =>
                members.length === 1
        );


    // ============================================
    // CREATE RECORD LOOKUP
    // ============================================

    /*
     * Create record lookup.
     *
     * Example:
     *
     * CB_459 -> complete CB_459 record
     * CC_51  -> complete CC_51 record
     */
    const recordLookup = {};


    for (const record of records) {

        recordLookup[
            record.record_id
        ] = record;
    }


    // ============================================
    // FUZZY MATCH DETAILS
    // ============================================

    /*
     * Convert fuzzy matches into a
     * readable format.
     */
    const fuzzyMatchDetails =
        fuzzyMatches
            .slice(0, 30)
            .map((match) => {

                const recordA =
                    recordLookup[
                        match.record_a
                    ];

                const recordB =
                    recordLookup[
                        match.record_b
                    ];

                return {

                    record_a:
                        match.record_a,

                    name_a:
                        recordA?.name ||
                        null,

                    record_b:
                        match.record_b,

                    name_b:
                        recordB?.name ||
                        null,

                    name_score:
                        match.name_score,

                    candidate_reasons:
                        match.candidate_reasons ||
                        []
                };
            });


    // ============================================
    // FUZZY ENTITY GROUPS
    // ============================================

    /*
     * Find entity groups that contain
     * at least one fuzzy match.
     */
    const fuzzyEntityGroups = [];


    for (
        const [entityId, memberIds]
        of Object.entries(
            result.data.entity_groups || {}
        )
    ) {

        /*
         * Get complete information about
         * every member of this entity.
         */
        const members =
            memberIds.map(
                (recordId) => {

                    const record =
                        recordLookup[
                            recordId
                        ];

                    return {

                        record_id:
                            recordId,

                        source:
                            record?.source ||
                            null,

                        name:
                            record?.name ||
                            null,

                        email:
                            record?.email ||
                            null,

                        phone:
                            record?.phone ||
                            null,

                        address:
                            record?.address ||
                            null
                    };
                }
            );


        /*
         * Find fuzzy matches where BOTH
         * records belong to this entity.
         *
         * Important:
         *
         * This does NOT mean fuzzy matching
         * created this entity.
         *
         * The entity was created through
         * exact matching.
         */
        const entityFuzzyMatches =
            fuzzyMatches.filter(
                (match) =>
                    memberIds.includes(
                        match.record_a
                    ) &&
                    memberIds.includes(
                        match.record_b
                    )
            );


        /*
         * Only include entities that
         * contain fuzzy evidence.
         */
        if (
            entityFuzzyMatches.length > 0
        ) {

            fuzzyEntityGroups.push({

                entity_id:
                    entityId,

                members:
                    members,

                fuzzy_matches:
                    entityFuzzyMatches.map(
                        (match) => {

                            const recordA =
                                recordLookup[
                                    match.record_a
                                ];

                            const recordB =
                                recordLookup[
                                    match.record_b
                                ];

                            return {

                                record_a:
                                    match.record_a,

                                name_a:
                                    recordA?.name ||
                                    null,

                                record_b:
                                    match.record_b,

                                name_b:
                                    recordB?.name ||
                                    null,

                                name_score:
                                    match.name_score
                            };
                        }
                    )
            });
        }
    }


    // ============================================
    // FINAL DRY-RUN RESPONSE
    // ============================================

    return {

        summary: {

            // Total source records
            input_records:
                records.length,

            // Candidate pairs checked
            candidate_pairs:
                matchResults.length,

            // Total matches
            matches,

            // Total non-matches
            no_matches:
                noMatches,

            // Exact Email / Phone matches
            exact_matches:
                exactMatches.length,

            // Fuzzy Name matches
            fuzzy_name_matches:
                fuzzyNameMatches.length,

            /*
             * Fuzzy matches whose records
             * currently belong to different
             * entities.
             *
             * These are NOT merged.
             */
            fuzzy_cross_entity_matches:
                fuzzyCrossEntityMatches.length,

            // Total entity groups
            entity_groups:
                entityGroups.length,

            // Entities containing 2+ records
            multi_record_entities:
                multiRecordEntities.length,

            // Entities containing 1 record
            singleton_entities:
                singletonEntities.length,

            // Generated Golden Records
            golden_records:
                goldenRecords.length
        },


        /*
         * First 30 fuzzy matches.
         */
        fuzzy_matches:
            fuzzyMatchDetails,


        /*
         * First 20 entity groups that
         * contain fuzzy matches.
         */
        fuzzy_entity_groups:
            fuzzyEntityGroups.slice(0, 20),


        /*
         * First 5 Golden Records.
         */
        sample_golden_records:
            goldenRecords.slice(0, 5),


        /*
         * First 5 lineage records.
         */
        sample_lineage:
            (result.data.lineage || [])
                .slice(0, 5)
    };
}


module.exports = {
    runMatchingFromDatabase,
    dryRunMatchingFromDatabase,
    rebuildTransactions,
    getMatchingState
};