const cron = require("node-cron");
const batchService = require("./batch.service");

let currentTask = null;

function setSchedule(expression) {
    if (!cron.validate(expression)) {
        throw new Error(`Invalid cron expression: ${expression}`);
    }

    if (currentTask) {
        currentTask.stop();
    }

    const parts = expression.split(" ");
    if (parts.length !== 6) {
        throw new Error("Cron expression must have exactly 6 fields: SECOND MINUTE HOUR DAY_OF_MONTH MONTH DAY_OF_WEEK");
    }

    const cronContext = {
        cron_second: parts[0],
        cron_minute: parts[1],
        cron_hour: parts[2],
        cron_day_of_month: parts[3],
        cron_month: parts[4],
        cron_day_of_week: parts[5]
    };

    currentTask = cron.schedule(expression, () => {
        batchService.runBatchPipeline(cronContext);
    });

    console.log(`[cron] Batch pipeline scheduled with expression: ${expression}`);
    
    return cronContext;
}

module.exports = {
    setSchedule
};
