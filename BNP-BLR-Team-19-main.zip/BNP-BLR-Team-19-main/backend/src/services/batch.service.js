const fs = require("fs");
const path = require("path");
const env = require("../config/env");
const { SOURCES } = require("../config/sources");
const { parseCsv } = require("../utils/csv");
const { toRawRow, toRawTransactionRow } = require("./source-mapping");
const rawRepository = require("../repositories/raw.repository");
const transactionRepository = require("../repositories/transaction.repository");
const matchingService = require("./matching.service");
const batchRepository = require("../repositories/batch.repository");
const { AppError } = require("../utils/response");

let isBatchRunning = false;

async function runBatchPipeline(cronJobContext) {
    if (isBatchRunning) {
        console.log("[batch] Batch pipeline is already running. Skipping execution.");
        return;
    }
    isBatchRunning = true;
    
    let batchId;
    let recordsProcessed = 0;

    try {
        const job = await batchRepository.createJob({
            ...cronJobContext,
            status: "PASSED"
        });
        batchId = job.batch_id;

        const fileDefs = [
            { source: SOURCES.CORE_BANKING, candidates: ["core_banking.csv", "core.csv"] },
            { source: SOURCES.CREDIT_CARD, candidates: ["credit_card.csv", "card.csv"] },
            { source: SOURCES.LOAN, candidates: ["loan_system.csv", "loan.csv"] },
            { source: SOURCES.TRANSACTIONS, candidates: ["transaction_data.csv", "transactions.csv"] }
        ];

        const batchFolder = env.batchFolderPath;
        const resolvedFiles = [];

        for (const def of fileDefs) {
            let foundPath = null;
            let foundName = null;
            for (const cand of def.candidates) {
                const candidatePath = path.join(batchFolder, cand);
                if (fs.existsSync(candidatePath)) {
                    foundPath = candidatePath;
                    foundName = cand;
                    break;
                }
            }
            if (foundPath) {
                resolvedFiles.push({ source: def.source, filePath: foundPath, fileName: foundName });
            }
        }

        if (resolvedFiles.length === 0) {
            throw new Error(`No CSV files found for batch processing in folder: ${batchFolder}`);
        }

        // Process resolved files
        for (const file of resolvedFiles) {
            const buffer = fs.readFileSync(file.filePath);
            const rows = parseCsv(buffer);
            
            if (file.source === SOURCES.TRANSACTIONS) {
                const valid = [];
                const batchPrefix = String(batchId).slice(0, 8);
                rows.forEach((input, index) => {
                    const line = index + 2;
                    const { row, error } = toRawTransactionRow(input, `${batchPrefix}-${line}`);
                    if (!error) {
                        valid.push(row);
                    }
                });

                if (valid.length > 0) {
                    const inserted = await transactionRepository.insertRawTransactions(valid);
                    recordsProcessed += inserted.length;
                }
            } else {
                const valid = [];
                rows.forEach((input) => {
                    const { row, error } = toRawRow(file.source, input);
                    if (!error) {
                        valid.push(row);
                    }
                });

                if (valid.length > 0) {
                    const inserted = await rawRepository.insertRecords(file.source, valid);
                    recordsProcessed += inserted.length;
                }
            }
        }

        // Run matching (Python engine communication & Golden Customer persistence & derived products rebuild)
        await matchingService.runMatchingFromDatabase({ trigger: `batch:${batchId}` });

        // Update success status
        await batchRepository.updateJob(batchId, {
            status: "PASSED",
            records_processed: recordsProcessed
        });
        
    } catch (error) {
        console.error(`[batch] Batch execution failed:`, error.message);
        if (batchId) {
            await batchRepository.updateJob(batchId, {
                status: "FAILED",
                error_message: error.message
            });
        }
    } finally {
        isBatchRunning = false;
    }
}

module.exports = { runBatchPipeline };
