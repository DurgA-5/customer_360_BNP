/**
 * Golden-table pre-check for incoming source records.
 *
 *   existing  - exactly one golden customer has this phone/email
 *   conflict  - phone points at one customer, email at another
 *               (matching will merge them into one)
 *   new       - not in the golden table; goes through full matching
 */
const TABLES = require("../config/tables");
const { fetchAll } = require("../utils/db");
const { normalizePhone, normalizeEmail } = require("../utils/normalize");
const customerRepository = require("../repositories/customer.repository");
const { formatGoldenId } = require("./customer.service");

/** Build phone/email -> golden_customer_id maps from golden rows. */
function buildGoldenIndex(customers) {
  const byPhone = new Map();
  const byEmail = new Map();

  for (const customer of customers) {
    const phone = normalizePhone(customer.phone);
    const email = normalizeEmail(customer.email);
    if (phone && !byPhone.has(phone))
      byPhone.set(phone, customer.golden_customer_id);
    if (email && !byEmail.has(email))
      byEmail.set(email, customer.golden_customer_id);
  }

  return { byPhone, byEmail, size: customers.length };
}

function lookupRow(index, row) {
  const matchedOn = [];
  const ids = new Set();

  const phoneId = row.normalized_phone
    ? index.byPhone.get(row.normalized_phone)
    : undefined;
  if (phoneId !== undefined) {
    matchedOn.push("phone");
    ids.add(phoneId);
  }

  const emailId = row.normalized_email
    ? index.byEmail.get(row.normalized_email)
    : undefined;
  if (emailId !== undefined) {
    matchedOn.push("email");
    ids.add(emailId);
  }

  const goldenIds = [...ids].sort((a, b) => a - b);
  const status =
    goldenIds.length === 0
      ? "new"
      : goldenIds.length === 1
        ? "existing"
        : "conflict";

  return { status, goldenIds, matchedOn };
}

async function loadGoldenIndex() {
  const customers = await fetchAll(TABLES.goldenCustomer, {
    columns: "golden_customer_id, phone, email",
    orderBy: "golden_customer_id",
  });
  return buildGoldenIndex(customers);
}

/** Customer portal: is this person already a golden customer? */
async function lookupContact({ phone, email }) {
  const normalizedPhone = normalizePhone(phone);
  const normalizedEmail = normalizeEmail(email);

  const customers = await customerRepository.findByContact({
    phone: normalizedPhone,
    email: normalizedEmail,
  });

  const check = lookupRow(buildGoldenIndex(customers), {
    normalized_phone: normalizedPhone,
    normalized_email: normalizedEmail,
  });

  return {
    ...check,
    customers: customers.filter((c) =>
      check.goldenIds.includes(c.golden_customer_id),
    ),
  };
}

function toReport({ line, name, check }) {
  return {
    line,
    name,
    status: check.status,
    matchedOn: check.matchedOn,
    existingCustomerIds: check.goldenIds.map(formatGoldenId),
    goldenCustomerId: null,
  };
}

module.exports = {
  buildGoldenIndex,
  lookupRow,
  loadGoldenIndex,
  lookupContact,
  toReport,
};
