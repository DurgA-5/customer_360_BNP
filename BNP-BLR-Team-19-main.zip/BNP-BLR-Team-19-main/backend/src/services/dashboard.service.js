/**
 * Admin dashboard aggregates.
 *
 * Metric definitions (documented because they drive the UI):
 *   totalCustomers      golden customers
 *   recordsProcessed    raw source records across all systems
 *   duplicatesResolved  recordsProcessed - totalCustomers (records merged away)
 *   completeness        avg % of the 5 identity fields populated per golden customer
 *   standardization     % of populated golden fields in canonical format
 *   duplicateResolution % of raw records currently linked to a golden customer
 *   overall             mean of the three
 */
const customerRepository = require("../repositories/customer.repository");
const rawRepository = require("../repositories/raw.repository");
const { fetchAll, isMissingTable } = require("../utils/db");
const TABLES = require("../config/tables");
const ingestionService = require("./ingestion.service");
const matchingService = require("./matching.service");

const FIELDS = ["name", "email", "phone", "dob", "address"];
const CANONICAL = {
    email: (v) => /^[^\s@A-Z]+@[^\s@A-Z]+\.[^\s@A-Z]+$/.test(v),
    phone: (v) => /^\d{10}$/.test(v),
    dob: (v) => /^\d{4}-\d{2}-\d{2}$/.test(v),
    name: (v) => v === v.trim() && !/\s{2,}/.test(v),
    address: (v) => v === v.trim() && !/\s{2,}/.test(v)
};

const pct = (part, whole) => (whole ? Math.round((part / whole) * 100) : 0);

function qualityMetrics(customers) {
    let populated = 0;
    let canonical = 0;

    for (const customer of customers) {
        for (const field of FIELDS) {
            const value = customer[field];
            if (value === null || value === undefined || value === "") continue;
            populated += 1;
            if (CANONICAL[field](String(value))) canonical += 1;
        }
    }

    return {
        completeness: pct(populated, customers.length * FIELDS.length),
        standardization: pct(canonical, populated)
    };
}

async function countLinkedRecords() {
    try {
        return (await fetchAll(TABLES.goldenMember, { columns: "golden_customer_id" })).length;
    } catch (error) {
        if (isMissingTable(error)) return null;
        throw error;
    }
}

async function getDashboard() {
    const [rawCounts, customers, linkedRecords, jobs, multiSource] = await Promise.all([
        rawRepository.countAll(),
        customerRepository.getAllForQuality(),
        countLinkedRecords(),
        ingestionService.listJobs(5),
        customerRepository.countMultiSourceCustomers()
    ]);

    const totalCustomers = customers.length;
    const recordsProcessed = rawCounts.total;
    const { completeness, standardization } = qualityMetrics(customers);

    const duplicateResolution =
        linkedRecords === null
            ? (totalCustomers ? 100 : 0)
            : pct(linkedRecords, recordsProcessed);

    const overall = Math.round((completeness + standardization + duplicateResolution) / 3);

    return {
        stats: {
            totalCustomers,
            recordsProcessed,
            duplicatesResolved: Math.max(recordsProcessed - totalCustomers, 0),
            multiSourceCustomers: multiSource,
            dataQuality: overall
        },
        quality: {
            overall,
            completeness,
            duplicateResolution,
            standardization
        },
        sources: {
            coreBanking: rawCounts.coreBanking,
            creditCard: rawCounts.creditCard,
            loan: rawCounts.loan,
            transactions: rawCounts.transactions
        },
        unlinkedRecords: linkedRecords === null ? null : Math.max(recordsProcessed - linkedRecords, 0),
        matching: matchingService.getMatchingState(),
        jobs
    };
}

module.exports = { getDashboard, qualityMetrics };
