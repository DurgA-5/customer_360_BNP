/**
 * Rebuilds the derived per-customer tables from the raw tables:
 *
 *   raw_core_banking  -> bank_account       (source_account_id = customer_id)
 *   raw_credit_card   -> credit_card        (source_cust_ref = cust_ref, credit_limit)
 *   raw_loan          -> loan               (source_loan_cust_id = loan_cust_id, loan_amt)
 *   raw_transactions  -> bank_transactions  (raw account_id = bank_account.source_account_id)
 *
 * Runs after golden customers are written, so every golden_customer_id FK
 * points at a current customer. Re-uploaded duplicates collapse into one
 * product per (customer, source id); the latest raw row wins.
 */
const TABLES = require("../config/tables");
const { SOURCES, recordId } = require("../config/sources");
const { fetchAll } = require("../utils/db");
const productRepository = require("../repositories/product.repository");
const transactionRepository = require("../repositories/transaction.repository");

/** Keep the last row per key (rows arrive ordered by raw_id). */
function latestByKey(rows, keyFn) {
    const map = new Map();
    for (const row of rows) {
        const key = keyFn(row);
        if (key !== null) map.set(key, row);
    }
    return [...map.values()];
}

function derive(rawRows, source, recordToGoldenId, sourceIdColumn, toRow) {
    const withGolden = rawRows
        .map((raw) => ({ raw, goldenId: recordToGoldenId.get(recordId(source, raw.raw_id)) }))
        .filter((item) => item.goldenId !== undefined && item.raw[sourceIdColumn]);

    return latestByKey(withGolden, (item) => `${item.goldenId}|${item.raw[sourceIdColumn]}`).map((item) =>
        toRow(item.raw, item.goldenId)
    );
}

function buildTransactionRows(rawTransactions, accounts, cards = [], loans = []) {
    const accountBySourceId = new Map();
    const accountByGoldenId = new Map();
    for (const account of accounts) {
        // If two customers share a source account id, the first (lowest id) wins.
        if (!accountBySourceId.has(account.source_account_id)) {
            accountBySourceId.set(account.source_account_id, account);
        }
        if (!accountByGoldenId.has(account.golden_customer_id)) {
            accountByGoldenId.set(account.golden_customer_id, account);
        }
    }

    const cardGoldenIdBySourceId = new Map();
    for (const card of cards) {
        if (!cardGoldenIdBySourceId.has(card.source_cust_ref)) {
            cardGoldenIdBySourceId.set(card.source_cust_ref, card.golden_customer_id);
        }
    }

    const loanGoldenIdBySourceId = new Map();
    for (const loan of loans) {
        if (!loanGoldenIdBySourceId.has(loan.source_loan_cust_id)) {
            loanGoldenIdBySourceId.set(loan.source_loan_cust_id, loan.golden_customer_id);
        }
    }

    let unlinked = 0;
    const rows = [];
    const unique = latestByKey(rawTransactions, (txn) => `${txn.account_id}|${txn.txn_id}`);

    for (const txn of unique) {
        let goldenCustomerId = null;
        let accountId = null;

        const account = accountBySourceId.get(txn.account_id);
        if (account) {
            goldenCustomerId = account.golden_customer_id;
            accountId = account.account_id;
        } else if (cardGoldenIdBySourceId.has(txn.account_id)) {
            goldenCustomerId = cardGoldenIdBySourceId.get(txn.account_id);
            const linkedAccount = accountByGoldenId.get(goldenCustomerId);
            accountId = linkedAccount ? linkedAccount.account_id : null;
        } else if (loanGoldenIdBySourceId.has(txn.account_id)) {
            goldenCustomerId = loanGoldenIdBySourceId.get(txn.account_id);
            const linkedAccount = accountByGoldenId.get(goldenCustomerId);
            accountId = linkedAccount ? linkedAccount.account_id : null;
        }

        if (!goldenCustomerId) {
            unlinked += 1;
            continue;
        }

        rows.push({
            golden_customer_id: goldenCustomerId,
            account_id: accountId,
            source_account_id: txn.account_id,
            amount: txn.amount,
            transaction_date: txn.transaction_date,
            type: txn.type
        });
    }

    return { rows, unlinked };
}

/**
 * Full rebuild after a matching run. Caller has already cleared the derived
 * tables (productRepository.clearDerived) before golden_customer was rewritten.
 *
 * @param {{coreBanking: object[], creditCard: object[], loan: object[]}} raw
 * @param {Map<string, number>} recordToGoldenId engine record id -> golden_customer_id
 */
async function rebuildAll(raw, recordToGoldenId) {
    const accountRows = derive(raw.coreBanking, SOURCES.CORE_BANKING, recordToGoldenId, "customer_id", (r, gid) => ({
        golden_customer_id: gid,
        source_account_id: r.customer_id,
        account_type: "Savings",
        opened_date: r.ingested_at ? String(r.ingested_at).slice(0, 10) : null,
        status: "Active"
    }));

    const cardRows = derive(raw.creditCard, SOURCES.CREDIT_CARD, recordToGoldenId, "cust_ref", (r, gid) => ({
        golden_customer_id: gid,
        source_cust_ref: r.cust_ref,
        credit_limit: r.credit_limit
    }));

    const loanRows = derive(raw.loan, SOURCES.LOAN, recordToGoldenId, "loan_cust_id", (r, gid) => ({
        golden_customer_id: gid,
        source_loan_cust_id: r.loan_cust_id,
        loan_amt: r.loan_amt
    }));

    const [accounts, cards, loans, rawTransactions] = await Promise.all([
        productRepository.insertAccounts(accountRows),
        productRepository.insertCreditCards(cardRows),
        productRepository.insertLoans(loanRows),
        transactionRepository.getAllRawTransactions()
    ]);

    const { rows: txnRows, unlinked } = buildTransactionRows(rawTransactions, accounts, cards, loans);
    const transactions = await transactionRepository.insertBankTransactions(txnRows);

    return {
        accounts: accounts.length,
        credit_cards: cards.length,
        loans: loans.length,
        transactions: transactions.length,
        unlinked_transactions: unlinked
    };
}

/** After a transactions-only upload: re-attach raw_transactions to existing accounts/cards/loans. */
async function rebuildTransactions() {
    const [accounts, cards, loans, rawTransactions] = await Promise.all([
        fetchAll(TABLES.bankAccount, {
            columns: "account_id, golden_customer_id, source_account_id",
            orderBy: "account_id"
        }),
        fetchAll(TABLES.creditCard, {
            columns: "card_id, golden_customer_id, source_cust_ref",
            orderBy: "card_id"
        }),
        fetchAll(TABLES.loan, {
            columns: "loan_id, golden_customer_id, source_loan_cust_id",
            orderBy: "loan_id"
        }),
        transactionRepository.getAllRawTransactions()
    ]);

    const { rows, unlinked } = buildTransactionRows(rawTransactions, accounts, cards, loans);
    await transactionRepository.clearBankTransactions();
    const inserted = await transactionRepository.insertBankTransactions(rows);

    return { transactions: inserted.length, unlinked_transactions: unlinked };
}

module.exports = {
    rebuildAll,
    rebuildTransactions,
    buildTransactionRows
};
