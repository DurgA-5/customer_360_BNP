/**
 * Converts raw source rows into the flat record format the Python engine expects.
 */
const rawRepository = require("../repositories/raw.repository");
const { SOURCES, recordId } = require("../config/sources");

function mapCoreBanking(record) {
    return {
        record_id: recordId(SOURCES.CORE_BANKING, record.raw_id),
        source: SOURCES.CORE_BANKING,

        name: record.normalized_name || record.name,
        email: record.normalized_email || record.email,
        phone: record.normalized_phone || record.phone,
        address: record.normalized_address || record.address,

        dob: record.dob || null,

        source_raw_id: record.raw_id,
        source_record_id: record.customer_id
    };
}

function mapCreditCard(record) {
    return {
        record_id: recordId(SOURCES.CREDIT_CARD, record.raw_id),
        source: SOURCES.CREDIT_CARD,

        name: record.normalized_name || record.name,
        email: record.normalized_email || record.email,
        phone: record.normalized_phone || record.phone,
        address: record.normalized_address || record.address,

        dob: null,

        source_raw_id: record.raw_id,
        source_record_id: record.cust_ref
    };
}

function mapLoan(record) {
    return {
        record_id: recordId(SOURCES.LOAN, record.raw_id),
        source: SOURCES.LOAN,

        name: record.normalized_name || record.name,
        email: null,
        phone: record.normalized_phone || record.phone,
        address: record.normalized_address || record.address,

        dob: null,

        source_raw_id: record.raw_id,
        source_record_id: record.loan_cust_id
    };
}

/** @param {{coreBanking, creditCard, loan}} raw rows from the raw_* tables */
function toEngineRecords({ coreBanking, creditCard, loan }) {
    return [
        ...coreBanking.map(mapCoreBanking),
        ...creditCard.map(mapCreditCard),
        ...loan.map(mapLoan)
    ];
}

async function getMDMRecords() {
    return toEngineRecords(await rawRepository.getAllSourceRecords());
}

module.exports = {
    mapCoreBanking,
    mapCreditCard,
    mapLoan,
    toEngineRecords,
    getMDMRecords
};
