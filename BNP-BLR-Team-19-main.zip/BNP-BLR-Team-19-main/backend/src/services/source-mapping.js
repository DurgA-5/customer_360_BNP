/**
 * Maps a source record (CSV row or customer form, already snake_case) to a
 * row for its raw_* table (team schema, database/migrations/001_raw_tables.sql).
 *
 * Raw tables are the source of truth. Product tables (bank_account,
 * credit_card, loan, bank_transactions) are derived from them after each
 * matching run - see product-rebuild.service.js.
 */
const { SOURCES } = require("../config/sources");
const { pick } = require("../utils/csv");
const n = require("../utils/normalize");

/** Accepted column names for each source's NOT NULL identifier. */
const SOURCE_KEY_COLUMNS = {
    [SOURCES.CORE_BANKING]: ["customer_id", "cust_id", "core_customer_id"],
    [SOURCES.CREDIT_CARD]: ["cust_ref", "card_id", "customer_ref", "customer_reference"],
    [SOURCES.LOAN]: ["loan_cust_id", "loan_customer_id", "loan_id"]
};

const SOURCE_KEY_LABEL = {
    [SOURCES.CORE_BANKING]: "customer_id",
    [SOURCES.CREDIT_CARD]: "cust_ref",
    [SOURCES.LOAN]: "loan_cust_id"
};

function identity(input) {
    const name = n.clean(pick(input, "name", "full_name", "customer_name"));
    const email = n.clean(pick(input, "email", "email_address"));
    const phone = n.clean(pick(input, "phone", "mobile", "phone_number", "contact"));
    const address = n.clean(pick(input, "address", "addr", "full_address"));

    return {
        name,
        email,
        phone,
        address,
        normalized_name: n.normalizeName(name),
        normalized_email: n.normalizeEmail(email),
        normalized_phone: n.normalizePhone(phone),
        normalized_address: n.normalizeAddress(address)
    };
}

function amountField(input, columns, label) {
    const text = pick(input, ...columns);
    if (text === null) return { value: null };
    const value = n.normalizeAmount(text);
    if (value === null || value < 0) return { error: `invalid ${label} "${text}"` };
    return { value };
}

/**
 * @returns {{row?: object, error?: string}}
 */
function toRawRow(source, input) {
    const sourceKey = n.clean(pick(input, ...SOURCE_KEY_COLUMNS[source]));
    const base = identity(input);

    if (!sourceKey) return { error: `${SOURCE_KEY_LABEL[source]} is required` };
    if (!base.name) return { error: "name is required" };
    if (!base.normalized_phone && !base.normalized_email) {
        return { error: "at least one of phone or email is required" };
    }

    switch (source) {
        case SOURCES.CORE_BANKING: {
            const dobRaw = pick(input, "dob", "date_of_birth", "birth_date");
            const dob = n.normalizeDate(dobRaw);
            if (dobRaw && !dob) return { error: `invalid dob "${dobRaw}"` };
            return { row: { customer_id: sourceKey, ...base, dob } };
        }

        case SOURCES.CREDIT_CARD: {
            const limit = amountField(input, ["credit_limit", "limit"], "credit_limit");
            if (limit.error) return { error: limit.error };
            return { row: { cust_ref: sourceKey, ...base, credit_limit: limit.value } };
        }

        case SOURCES.LOAN: {
            // raw_loan has no email columns.
            const { email, normalized_email, ...loanFields } = base; // eslint-disable-line no-unused-vars
            if (!loanFields.normalized_phone) return { error: "phone is required for loan records" };
            const amount = amountField(input, ["loan_amt", "loan_amount", "amount", "principal"], "loan_amt");
            if (amount.error) return { error: amount.error };
            return { row: { loan_cust_id: sourceKey, ...loanFields, loan_amt: amount.value } };
        }

        default:
            return { error: `unsupported source ${source}` };
    }
}

/**
 * Transaction CSV row -> raw_transactions row.
 * `account_id` is the source account id, i.e. raw_core_banking.customer_id.
 * @param {object} input
 * @param {string} fallbackTxnId used when the CSV has no txn_id column
 * @returns {{row?: object, error?: string}}
 */
function toRawTransactionRow(input, fallbackTxnId) {
    const accountId = n.clean(pick(input, "account_id", "source_account_id", "account", "account_number", "customer_id"));
    const amountText = pick(input, "amount", "txn_amount", "transaction_amount");
    const rawAmount = n.normalizeAmount(amountText);
    const date = n.normalizeDate(pick(input, "transaction_date", "date", "txn_date"));
    let type = (n.clean(pick(input, "type", "transaction_type", "txn_type", "dr_cr")) || "").toUpperCase();

    if (!accountId) return { error: "account_id is required" };
    if (rawAmount === null) {
        return { error: amountText ? `invalid amount "${amountText}"` : "amount is required" };
    }
    if (!date) return { error: "transaction_date is required (YYYY-MM-DD or DD/MM/YYYY)" };

    if (["CR", "C"].includes(type)) type = "CREDIT";
    if (["DR", "D"].includes(type)) type = "DEBIT";
    if (!["CREDIT", "DEBIT"].includes(type)) type = rawAmount < 0 ? "DEBIT" : "CREDIT";

    return {
        row: {
            txn_id: n.clean(pick(input, "txn_id", "transaction_id", "id")) || fallbackTxnId,
            account_id: accountId,
            amount: Math.abs(rawAmount),
            transaction_date: date,
            type
        }
    };
}

module.exports = {
    toRawRow,
    toRawTransactionRow
};
