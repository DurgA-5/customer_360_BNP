/**
 * Source trace: explains, in plain language, why each golden value won.
 * Uses the same trust hierarchy and the same normalised values the engine
 * saw, so the explanation always matches the engine's decision.
 */
const { SOURCES, sourceLabel } = require("../config/sources");
const { GOLDEN_FIELDS, FIELD_LABELS, priorityFor } = require("../config/trust");
const rawRepository = require("../repositories/raw.repository");
const {
  mapCoreBanking,
  mapCreditCard,
  mapLoan,
} = require("./mdm-record.service");

const MAPPER = {
  [SOURCES.CORE_BANKING]: mapCoreBanking,
  [SOURCES.CREDIT_CARD]: mapCreditCard,
  [SOURCES.LOAN]: mapLoan,
};

const isEmpty = (value) =>
  value === null || value === undefined || String(value).trim() === "";

function listLabels(sources) {
  const labels = sources.map(sourceLabel);
  if (labels.length <= 1) return labels.join("");
  return `${labels.slice(0, -1).join(", ")} and ${labels[labels.length - 1]}`;
}

/**
 * Pure function.
 * @param {string} field
 * @param {Array<{source, rawId, value}>} candidates every member record's value for this field
 * @param {{source, rawId}|null} winner from golden_field_lineage
 */
function explainField(field, candidates, winner) {
  const priority = priorityFor(field);
  const chain = priority.map((p) => sourceLabel(p.source)).join(" → ");
  const fieldLabel = FIELD_LABELS[field] || field;

  const bySource = new Map();
  for (const candidate of candidates) {
    if (!bySource.has(candidate.source)) bySource.set(candidate.source, []);
    bySource.get(candidate.source).push(candidate);
  }

  const rankOf = (source) =>
    priority.find((p) => p.source === source)?.rank ?? null;

  const described = candidates.map((c) => ({
    source: c.source,
    label: sourceLabel(c.source),
    rawId: c.rawId,
    value: isEmpty(c.value) ? null : c.value,
    rank: rankOf(c.source),
    status:
      winner &&
      c.source === winner.source &&
      Number(c.rawId) === Number(winner.rawId)
        ? "winner"
        : isEmpty(c.value)
          ? "no value"
          : "lower priority",
  }));

  if (!winner) {
    return {
      priority: priority.map((p) => ({ ...p, label: sourceLabel(p.source) })),
      candidates: described,
      why: `None of this customer's records has a ${fieldLabel.toLowerCase()}, so it is empty.`,
    };
  }

  const winnerRank = rankOf(winner.source);
  const higher = priority
    .filter((p) => p.rank < winnerRank)
    .map((p) => p.source);
  const higherEmpty = higher.filter((s) => bySource.has(s));
  const higherMissing = higher.filter((s) => !bySource.has(s));
  const winnerValue = described.find((c) => c.status === "winner")?.value;
  const sameText = (a, b) =>
    String(a ?? "")
      .trim()
      .toLowerCase() ===
    String(b ?? "")
      .trim()
      .toLowerCase();
  const lowerRanked = described.filter(
    (c) =>
      c.status === "lower priority" && c.rank > winnerRank && c.value !== null,
  );
  const lowerSame = [
    ...new Set(
      lowerRanked
        .filter((c) => sameText(c.value, winnerValue))
        .map((c) => c.source),
    ),
  ];
  const lowerWithValue = [
    ...new Set(
      lowerRanked
        .filter((c) => !sameText(c.value, winnerValue))
        .map((c) => c.source),
    ),
  ];

  const parts = [
    `${sourceLabel(winner.source)} is priority ${winnerRank} for ${fieldLabel.toLowerCase()} (${chain}).`,
  ];
  if (higherEmpty.length) {
    parts.push(
      `${listLabels(higherEmpty)} had no value, so it fell through to ${sourceLabel(winner.source)}.`,
    );
  }
  if (higherMissing.length) {
    parts.push(`This customer has no ${listLabels(higherMissing)} record.`);
  }
  if (lowerWithValue.length) {
    const verb = lowerWithValue.length > 1 ? "rank" : "ranks";
    parts.push(
      `${listLabels(lowerWithValue)} had a different value but ${verb} lower.`,
    );
  }
  if (lowerSame.length) {
    parts.push(
      `${listLabels(lowerSame)} ${lowerSame.length > 1 ? "have" : "has"} the same value.`,
    );
  }
  if (
    winnerRank === 1 &&
    !lowerWithValue.length &&
    !lowerSame.length &&
    !higherEmpty.length
  ) {
    parts.push("It is the most trusted source for this field.");
  }

  return {
    priority: priority.map((p) => ({ ...p, label: sourceLabel(p.source) })),
    candidates: described,
    why: parts.join(" "),
  };
}

/** Load every member record's values (as the engine saw them). */
async function loadCandidates(members) {
  const bySource = new Map();
  for (const m of members) {
    if (!MAPPER[m.source_system]) continue;
    if (!bySource.has(m.source_system)) bySource.set(m.source_system, []);
    bySource.get(m.source_system).push(m.source_raw_id);
  }

  const records = [];
  for (const [source, rawIds] of bySource) {
    const rows = await rawRepository.getByRawIds(source, rawIds);
    for (const row of rows) records.push(MAPPER[source](row));
  }
  return records;
}

/**
 * @param {Array<{source_system, source_raw_id}>} members
 * @param {Array} lineageRows golden_field_lineage rows for the customer
 * @returns {Promise<Map<string, {priority, candidates, why}>>} field -> explanation
 */
async function explainLineage(members, lineageRows) {
  const records = await loadCandidates(members);
  const winners = new Map(
    lineageRows.map((row) => [
      row.field_name,
      { source: row.source_system, rawId: row.source_raw_id },
    ]),
  );

  const result = new Map();
  for (const field of GOLDEN_FIELDS) {
    const candidates = records.map((r) => ({
      source: r.source,
      rawId: r.source_raw_id,
      value: r[field],
    }));
    result.set(
      field,
      explainField(field, candidates, winners.get(field) || null),
    );
  }
  return result;
}

module.exports = { explainField, explainLineage };
