/**
 * CSV ingestion.
 *
 * Flow:
 *   POST /ingestion/upload  -> validate + parse synchronously (bad files get a 400 immediately)
 *                           -> create ingestion_job (status "queued") and return 202 + jobId
 *   background              -> "processing": check each row against golden_customer
 *                                            (phone or email) -> existing / conflict / new,
 *                                            then insert rows into the raw_* table
 *                           -> "matching":   re-run entity resolution, which rebuilds
 *                                            bank_account / credit_card / loan / bank_transactions
 *                              (transaction uploads only re-attach bank_transactions)
 *                           -> "completed" | "failed"
 *   GET /ingestion/jobs/:id -> frontend polls until a terminal status
 */
const env = require("../config/env");
const {
  SOURCES,
  normalizeSource,
  sourceLabel,
  recordId,
} = require("../config/sources");
const { AppError } = require("../utils/response");
const { parseCsv } = require("../utils/csv");
const ingestionRepository = require("../repositories/ingestion.repository");
const rawRepository = require("../repositories/raw.repository");
const transactionRepository = require("../repositories/transaction.repository");
const matchingService = require("./matching.service");
const goldenLookup = require("./golden-lookup.service");
const { formatGoldenId } = require("./customer.service");
const { toRawRow, toRawTransactionRow } = require("./source-mapping");

const MAX_REPORTED_ERRORS = 25;
const MAX_REPORTED_ROWS = 500; // per-row golden check details kept in the job summary
const TERMINAL_STATUSES = new Set(["completed", "failed"]);

function formatJob(job) {
  if (!job) return null;
  return {
    jobId: job.job_id,
    source: job.source,
    sourceLabel: sourceLabel(job.source),
    fileName: job.file_name,
    status: job.status,
    isTerminal: TERMINAL_STATUSES.has(job.status),
    recordsReceived: job.records_received ?? 0,
    recordsInserted: job.records_inserted ?? 0,
    recordsRejected: job.records_rejected ?? 0,
    // Shape expected by the dashboard's RecentIngestion table.
    records: job.records_inserted ?? job.records_received ?? 0,
    errorMessage: job.error_message || null,
    summary: job.summary || null,
    createdAt: job.created_at,
    completedAt: job.completed_at || null,
  };
}

async function startUpload({ source, file }) {
  const canonicalSource = normalizeSource(source);
  if (!canonicalSource) {
    throw AppError.badRequest(
      `Unknown source "${source}". Use one of: ${Object.values(SOURCES).join(", ")}`,
    );
  }
  if (!file)
    throw AppError.badRequest('CSV file is required (form field "file")');

  const rows = parseCsv(file.buffer);

  const job = await ingestionRepository.create({
    source: canonicalSource,
    file_name: file.originalname,
    status: "queued",
    records_received: rows.length,
  });

  // Fire-and-forget; progress is visible via GET /ingestion/jobs/:jobId.
  setImmediate(() => {
    processJob(job.job_id, canonicalSource, rows).catch((error) => {
      console.error(`[ingestion] job ${job.job_id} crashed`, error);
    });
  });

  return formatJob(job);
}

async function processJob(jobId, source, rows) {
  const summary = { rejected: [] };

  try {
    await ingestionRepository.update(jobId, { status: "processing" });

    const outcome =
      source === SOURCES.TRANSACTIONS
        ? await ingestTransactions(jobId, rows, summary)
        : await ingestSourceRecords(source, rows, summary);

    let matchingError = null;
    if (outcome.inserted > 0) {
      try {
        if (source === SOURCES.TRANSACTIONS) {
          await ingestionRepository.update(jobId, {
            status: "matching",
            records_inserted: outcome.inserted,
          });
          summary.transactions = await matchingService.rebuildTransactions();
        } else if (env.autoMatchOnIngest) {
          await ingestionRepository.update(jobId, {
            status: "matching",
            records_inserted: outcome.inserted,
          });
          const matching = await matchingService.runMatchingFromDatabase({
            trigger: `ingestion:${jobId}`,
          });
          summary.matching = matching.summary;
          applyFinalGoldenIds(
            source,
            outcome,
            summary,
            matching.recordToGoldenId,
          );
        }
      } catch (error) {
        // Raw data is safely stored; matching can be re-run from the admin dashboard.
        matchingError = error.message;
        summary.matching = { error: error.message };
      }
    }

    summary.rejected = summary.rejected.slice(0, MAX_REPORTED_ERRORS);

    await ingestionRepository.update(jobId, {
      status: "completed",
      records_inserted: outcome.inserted,
      records_rejected: outcome.rejected,
      error_message: matchingError
        ? `Records stored, but matching failed: ${matchingError}. Use "Run Matching" on the dashboard to retry.`
        : null,
      summary,
      completed_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error(`[ingestion] job ${jobId} failed:`, error.message);
    await ingestionRepository
      .update(jobId, {
        status: "failed",
        error_message: error.message,
        summary,
        completed_at: new Date().toISOString(),
      })
      .catch((updateError) =>
        console.error("[ingestion] could not mark job failed", updateError),
      );
  }
}

async function ingestSourceRecords(source, rows, summary) {
  const valid = [];

  rows.forEach((input, index) => {
    const { row, error } = toRawRow(source, input);
    if (error) {
      summary.rejected.push({ line: index + 2, reason: error });
    } else {
      valid.push({ row, line: index + 2 });
    }
  });

  // 1. Is each row already a golden customer? (phone OR email)
  const index = await goldenLookup.loadGoldenIndex();
  const reports = valid.map(({ row, line }) =>
    goldenLookup.toReport({
      line,
      name: row.name,
      check: goldenLookup.lookupRow(index, row),
    }),
  );

  summary.golden_check = {
    existing: reports.filter((r) => r.status === "existing").length,
    conflict: reports.filter((r) => r.status === "conflict").length,
    new: reports.filter((r) => r.status === "new").length,
  };

  // 2. Usual process: store every valid row (matching runs afterwards).
  const inserted = await rawRepository.insertRecords(
    source,
    valid.map((item) => item.row),
  );

  inserted.forEach((rawRow, i) => {
    reports[i].rawId = rawRow.raw_id;
    // Existing customers are linked straight away; matching confirms it.
    if (reports[i].status === "existing")
      reports[i].goldenCustomerId = reports[i].existingCustomerIds[0];
  });

  summary.rows = reports.slice(0, MAX_REPORTED_ROWS);
  summary.rows_truncated = reports.length > MAX_REPORTED_ROWS;

  return { inserted: inserted.length, rejected: rows.length - inserted.length };
}

/** After matching: record the golden customer every uploaded row ended up in. */
function applyFinalGoldenIds(source, outcome, summary, recordToGoldenId) {
  if (!summary.rows) return;
  for (const report of summary.rows) {
    if (report.rawId === undefined) continue;
    const goldenId = recordToGoldenId.get(recordId(source, report.rawId));
    if (goldenId !== undefined)
      report.goldenCustomerId = formatGoldenId(goldenId);
  }
}

async function ingestTransactions(jobId, rows, summary) {
  const valid = [];
  const jobPrefix = String(jobId).slice(0, 8);

  rows.forEach((input, index) => {
    const line = index + 2;
    const { row, error } = toRawTransactionRow(input, `${jobPrefix}-${line}`);
    if (error) {
      summary.rejected.push({ line, reason: error });
    } else {
      valid.push(row);
    }
  });

  const inserted = await transactionRepository.insertRawTransactions(valid);
  return { inserted: inserted.length, rejected: rows.length - inserted.length };
}

async function getJob(jobId) {
  const job = await ingestionRepository.findById(jobId);
  if (!job) throw AppError.notFound(`Ingestion job ${jobId} not found`);
  return formatJob(job);
}

async function listJobs(limit = 10) {
  return (await ingestionRepository.listRecent(limit)).map(formatJob);
}

module.exports = {
  startUpload,
  getJob,
  listJobs,
  formatJob,
};
