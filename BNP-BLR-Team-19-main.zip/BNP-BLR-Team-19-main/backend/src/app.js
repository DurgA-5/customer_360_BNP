const express = require("express");
const cors = require("cors");

const env = require("./config/env");
const apiRoutes = require("./routes");
const errorMiddleware = require("./middleware/error.middleware");
const { notFoundHandler } = require("./middleware/error.middleware");

const app = express();

app.disable("x-powered-by");

app.use(
    cors({
        origin: env.corsOrigins.includes("*") ? true : env.corsOrigins
    })
);
app.use(express.json({ limit: "1mb" }));

// Lightweight request log.
app.use((req, res, next) => {
    const started = Date.now();
    res.on("finish", () => {
        if (req.path !== "/api/v1/health") {
            console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - started}ms`);
        }
    });
    next();
});

app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "UniBank MDM Backend is running",
        apiBase: "/api/v1"
    });
});

app.use("/api/v1", apiRoutes);

app.use(notFoundHandler);
app.use(errorMiddleware);

module.exports = app;
