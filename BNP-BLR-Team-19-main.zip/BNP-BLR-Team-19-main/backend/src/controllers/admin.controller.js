const dashboardService = require("../services/dashboard.service");
const { ok } = require("../utils/response");

async function getDashboard(req, res) {
    ok(res, await dashboardService.getDashboard());
}

module.exports = { getDashboard };
