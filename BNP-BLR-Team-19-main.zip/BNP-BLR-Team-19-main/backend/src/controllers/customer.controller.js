const customerService = require("../services/customer.service");
const { ok } = require("../utils/response");

async function searchCustomers(req, res) {
  const { customers, meta } = await customerService.search({
    q: req.query.q,
    page: req.query.page,
    limit: req.query.limit,
  });
  ok(res, customers, { meta });
}

async function lookupCustomer(req, res) {
  const { query, phone, email } = req.body || {};
  ok(
    res,
    query
      ? await customerService.lookupByQuery(query)
      : await customerService.lookupByContact({ phone, email }),
  );
}

async function getCustomer(req, res) {
  ok(res, await customerService.getProfile(req.params.customerId));
}

async function getCustomerProducts(req, res) {
  ok(res, await customerService.getProducts(req.params.customerId));
}

async function getCustomerTransactions(req, res) {
  const limit = Math.min(Number(req.query.limit) || 100, 500);
  ok(
    res,
    await customerService.getTransactions(req.params.customerId, { limit }),
  );
}

async function getCustomerLineage(req, res) {
  ok(res, await customerService.getLineage(req.params.customerId));
}

async function getCustomer360(req, res) {
  ok(res, await customerService.get360(req.params.customerId));
}

module.exports = {
  lookupCustomer,
  searchCustomers,
  getCustomer,
  getCustomerProducts,
  getCustomerTransactions,
  getCustomerLineage,
  getCustomer360,
};
