const cronService = require("../services/cron.service");
const batchService = require("../services/batch.service");
const { AppError, ok } = require("../utils/response");

async function scheduleBatch(req, res) {
    const cronExpression = req.body.cronExpression || req.body.cron_expression || req.body.expression;
    if (!cronExpression) {
        throw AppError.badRequest("cronExpression is required");
    }

    const parts = String(cronExpression).trim().split(/\s+/);
    if (parts.length !== 6) {
        throw AppError.badRequest("Cron expression must contain exactly 6 fields: SECOND MINUTE HOUR DAY_OF_MONTH MONTH DAY_OF_WEEK");
    }

    try {
        const cronContext = cronService.setSchedule(cronExpression.trim());
        return ok(res, {
            message: "Batch job scheduled successfully",
            cronExpression: cronExpression.trim(),
            schedule: cronContext
        });
    } catch (error) {
        throw AppError.badRequest(error.message);
    }
}

async function triggerBatch(req, res) {
    // Manual trigger option
    const manualContext = {
        cron_second: "0",
        cron_minute: "*",
        cron_hour: "*",
        cron_day_of_month: "*",
        cron_month: "*",
        cron_day_of_week: "*"
    };

    // Run async in background or wait
    batchService.runBatchPipeline(manualContext).catch(err => {
        console.error("[batch] Manual trigger error:", err);
    });

    return ok(res, { message: "Batch pipeline triggered manually" });
}

module.exports = {
    scheduleBatch,
    triggerBatch
};
