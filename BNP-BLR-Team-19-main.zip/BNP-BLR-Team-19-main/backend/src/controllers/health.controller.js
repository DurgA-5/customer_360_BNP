const engineClient = require("../clients/engine.client");
const { count } = require("../utils/db");
const TABLES = require("../config/tables");

async function check(fn) {
    const started = Date.now();
    try {
        await fn();
        return { status: "up", latencyMs: Date.now() - started };
    } catch (error) {
        return { status: "down", error: error.message };
    }
}

async function health(req, res) {
    const [database, engine] = await Promise.all([
        check(() => count(TABLES.goldenCustomer)),
        check(() => engineClient.health())
    ]);

    const healthy = database.status === "up" && engine.status === "up";
    res.status(healthy ? 200 : 503).json({
        success: healthy,
        data: { api: "up", database, engine, uptimeSeconds: Math.round(process.uptime()) }
    });
}

module.exports = { health };
