const matchingService = require("../services/matching.service");
const { ok } = require("../utils/response");

async function runMatching(req, res) {
    const { summary } = await matchingService.runMatchingFromDatabase({ trigger: "admin" });
    ok(res, { summary });
}

async function dryRunMatching(req, res) {
    ok(res, await matchingService.dryRunMatchingFromDatabase());
}

async function getMatchingStatus(req, res) {
    ok(res, matchingService.getMatchingState());
}

module.exports = {
    runMatching,
    dryRunMatching,
    getMatchingStatus
};
