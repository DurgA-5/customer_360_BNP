const ingestionService = require("../services/ingestion.service");
const { ok, accepted } = require("../utils/response");

async function uploadFile(req, res) {
    const job = await ingestionService.startUpload({
        source: req.body?.source,
        file: req.file
    });
    accepted(res, job, { message: "File accepted for processing" });
}

async function getIngestionStatus(req, res) {
    ok(res, await ingestionService.getJob(req.params.jobId));
}

async function listIngestionJobs(req, res) {
    const limit = Math.min(Number(req.query.limit) || 10, 50);
    ok(res, await ingestionService.listJobs(limit));
}

module.exports = {
    uploadFile,
    getIngestionStatus,
    listIngestionJobs
};
