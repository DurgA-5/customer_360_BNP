const sourceService = require("../services/source.service");
const { created } = require("../utils/response");

const respond = (fn) => async (req, res) => {
  const { message, ...result } = await fn(req.body);
  created(res, result, { message });
};

module.exports = {
  createCoreBanking: respond(sourceService.createCoreBanking),
  createCreditCard: respond(sourceService.createCreditCard),
  createLoan: respond(sourceService.createLoan),
};
