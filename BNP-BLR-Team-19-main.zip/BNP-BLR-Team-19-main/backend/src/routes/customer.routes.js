const express = require("express");
const controller = require("../controllers/customer.controller");
const { asyncHandler, AppError } = require("../utils/response");
const { validateBody } = require("../middleware/validation.middleware");

const router = express.Router();

router.get("/", asyncHandler(controller.searchCustomers));

// Customer portal: check the golden table.
//   { query: "GC-1" | "CB001" | "9876543210" | "a@b.com" }  or  { phone, email }
router.post(
  "/lookup",
  (req, res, next) =>
    req.body?.query || req.body?.phone || req.body?.email
      ? next()
      : next(AppError.badRequest("Enter a customer ID, phone number or email")),
  validateBody({ phone: { type: "phone" }, email: { type: "email" } }),
  asyncHandler(controller.lookupCustomer),
);

router.get("/:customerId", asyncHandler(controller.getCustomer));
router.get(
  "/:customerId/products",
  asyncHandler(controller.getCustomerProducts),
);
router.get(
  "/:customerId/transactions",
  asyncHandler(controller.getCustomerTransactions),
);
router.get("/:customerId/lineage", asyncHandler(controller.getCustomerLineage));
router.get("/:customerId/360", asyncHandler(controller.getCustomer360));

module.exports = router;
