/**
 * Customer-portal "Create or Connect" forms.
 */
const express = require("express");
const controller = require("../controllers/source.controller");
const { validateBody } = require("../middleware/validation.middleware");
const { asyncHandler } = require("../utils/response");

const router = express.Router();

const identity = {
    name: { required: true, type: "string", maxLength: 200 },
    phone: { required: true, type: "phone" },
    address: { required: true, type: "string", maxLength: 500 }
};

router.post(
    "/core-banking",
    validateBody({
        customerId: { required: true, type: "string", maxLength: 64 },
        ...identity,
        email: { required: true, type: "email" },
        dob: { required: true, type: "date", past: true }
    }),
    asyncHandler(controller.createCoreBanking)
);

router.post(
    "/credit-card",
    validateBody({
        custRef: { required: true, type: "string", maxLength: 64 },
        ...identity,
        email: { required: true, type: "email" },
        creditLimit: { required: true, type: "number", min: 0 }
    }),
    asyncHandler(controller.createCreditCard)
);

router.post(
    "/loan",
    validateBody({
        loanCustId: { required: true, type: "string", maxLength: 64 },
        ...identity,
        loanAmount: { required: true, type: "number", min: 1 }
    }),
    asyncHandler(controller.createLoan)
);

module.exports = router;
