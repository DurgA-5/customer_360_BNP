const express = require("express");
const controller = require("../controllers/ingestion.controller");
const { upload } = require("../middleware/upload");
const { asyncHandler } = require("../utils/response");

const router = express.Router();

router.post("/upload", upload.single("file"), asyncHandler(controller.uploadFile));
router.get("/jobs", asyncHandler(controller.listIngestionJobs));
router.get("/jobs/:jobId", asyncHandler(controller.getIngestionStatus));

module.exports = router;
