const express = require("express");
const controller = require("../controllers/matching.controller");
const { asyncHandler } = require("../utils/response");

const router = express.Router();

router.post("/run", asyncHandler(controller.runMatching));
router.get("/dry-run", asyncHandler(controller.dryRunMatching));
router.get("/status", asyncHandler(controller.getMatchingStatus));

module.exports = router;
