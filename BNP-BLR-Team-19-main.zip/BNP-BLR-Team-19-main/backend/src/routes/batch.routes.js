const express = require("express");
const controller = require("../controllers/batch.controller");
const { asyncHandler } = require("../utils/response");

const router = express.Router();

router.post("/schedule", asyncHandler(controller.scheduleBatch));
router.post("/run", asyncHandler(controller.triggerBatch));

module.exports = router;
