const express = require("express");
const controller = require("../controllers/admin.controller");
const { asyncHandler } = require("../utils/response");

const router = express.Router();

const batchController = require("../controllers/batch.controller");

router.get("/dashboard", asyncHandler(controller.getDashboard));
router.post("/jobs/schedule", asyncHandler(batchController.scheduleBatch));

module.exports = router;
