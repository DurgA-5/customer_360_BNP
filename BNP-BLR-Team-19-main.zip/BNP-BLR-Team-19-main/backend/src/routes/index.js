const express = require("express");
const { asyncHandler } = require("../utils/response");
const { health } = require("../controllers/health.controller");

const router = express.Router();

router.get("/health", asyncHandler(health));
router.use("/admin", require("./admin.routes"));
router.use("/ingestion", require("./ingestion.routes"));
router.use("/matching", require("./matching.routes"));
router.use("/customers", require("./customer.routes"));
router.use("/sources", require("./source.routes"));
router.use("/batch", require("./batch.routes"));

module.exports = router;
