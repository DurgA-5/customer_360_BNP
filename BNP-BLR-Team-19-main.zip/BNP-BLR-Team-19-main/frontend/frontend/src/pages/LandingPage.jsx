import Hero from "../components/landing/Hero";
import Footer from "../components/landing/Footer";

function LandingPage() {
  return (
    <div className="min-h-screen bg-white text-slate-900">
      <main>
        <Hero />
      </main>

      <Footer />
    </div>
  );
}

export default LandingPage;