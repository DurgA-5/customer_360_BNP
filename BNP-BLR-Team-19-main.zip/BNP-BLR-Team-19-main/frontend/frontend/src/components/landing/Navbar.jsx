import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="sticky top-0 z-50 border-b border-white/10 bg-slate-950/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">

        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-600 font-bold">
            U
          </div>

          <div>
            <h1 className="font-semibold">UniBank MDM</h1>
            <p className="text-xs text-slate-400">
              Customer 360
            </p>
          </div>
        </Link>

        {/* Navigation */}
        <div className="hidden items-center gap-8 text-sm text-slate-300 md:flex">
          <a href="#how-it-works" className="hover:text-white">
            How It Works
          </a>

          <a href="#users" className="hover:text-white">
            Users
          </a>

          <a href="#features" className="hover:text-white">
            Features
          </a>

          <a href="#about" className="hover:text-white">
            About
          </a>
        </div>

        {/* CTA */}
        <a
          href="#access"
          className="rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium hover:bg-violet-500"
        >
          Get Started
        </a>
      </div>
    </nav>
  );
}

export default Navbar;