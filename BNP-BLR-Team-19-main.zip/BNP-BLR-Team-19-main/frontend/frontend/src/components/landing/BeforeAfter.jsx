function BeforeAfter() {
  return (
    <section id="about" className="py-24">
      <div className="mx-auto max-w-7xl px-6">

        <div className="text-center">
          <p className="text-sm uppercase tracking-widest text-violet-400">
            The transformation
          </p>

          <h2 className="mt-3 text-4xl font-bold">
            From fragmented records to one identity.
          </h2>
        </div>

        <div className="mt-12 grid items-center gap-6 md:grid-cols-[1fr_auto_1fr]">

          {/* Before */}
          <div className="rounded-3xl border border-red-500/20 bg-red-500/5 p-7">
            <p className="text-sm font-medium text-red-300">
              BEFORE
            </p>

            <h3 className="mt-2 text-xl font-semibold">
              Fragmented customer data
            </h3>

            <div className="mt-6 space-y-4 text-sm">
              <div className="rounded-xl bg-slate-900 p-4">
                <p className="font-medium">Core Banking</p>
                <p className="mt-2 text-slate-400">
                  John Doe
                  <br />
                  john@gmail.com
                  <br />
                  9876543210
                </p>
              </div>

              <div className="rounded-xl bg-slate-900 p-4">
                <p className="font-medium">Credit Card</p>
                <p className="mt-2 text-slate-400">
                  Jon Doe
                  <br />
                  john@gmail.com
                  <br />
                  987654321
                </p>
              </div>

              <div className="rounded-xl bg-slate-900 p-4">
                <p className="font-medium">Loan</p>
                <p className="mt-2 text-slate-400">
                  John D.
                  <br />
                  9876543210
                  <br />
                  Hyderabad
                </p>
              </div>
            </div>
          </div>

          {/* Arrow */}
          <div className="text-center text-3xl text-violet-400">
            →
          </div>

          {/* After */}
          <div className="rounded-3xl border border-violet-500/20 bg-violet-500/5 p-7">
            <p className="text-sm font-medium text-violet-300">
              AFTER
            </p>

            <h3 className="mt-2 text-xl font-semibold">
              Unified Golden Record
            </h3>

            <div className="mt-6 rounded-2xl bg-slate-900 p-6">

              <div className="flex items-center gap-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-violet-600 text-lg font-bold">
                  JD
                </div>

                <div>
                  <p className="font-semibold">
                    John Doe
                  </p>

                  <p className="text-sm text-slate-400">
                    Unified Customer
                  </p>
                </div>
              </div>

              <div className="mt-6 space-y-3 text-sm text-slate-300">
                <p>
                  <span className="text-slate-500">Email:</span>{" "}
                  john@gmail.com
                </p>

                <p>
                  <span className="text-slate-500">Phone:</span>{" "}
                  9876543210
                </p>

                <p>
                  <span className="text-slate-500">Address:</span>{" "}
                  Hyderabad
                </p>

                <div className="mt-6 grid grid-cols-3 gap-3">
                  <div className="rounded-xl bg-white/5 p-3 text-center">
                    <p className="text-lg font-semibold">2</p>
                    <p className="text-xs text-slate-500">
                      Accounts
                    </p>
                  </div>

                  <div className="rounded-xl bg-white/5 p-3 text-center">
                    <p className="text-lg font-semibold">1</p>
                    <p className="text-xs text-slate-500">
                      Card
                    </p>
                  </div>

                  <div className="rounded-xl bg-white/5 p-3 text-center">
                    <p className="text-lg font-semibold">1</p>
                    <p className="text-xs text-slate-500">
                      Loan
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}

export default BeforeAfter;