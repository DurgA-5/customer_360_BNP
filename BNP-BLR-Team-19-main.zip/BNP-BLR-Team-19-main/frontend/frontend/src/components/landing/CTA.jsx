import { useNavigate } from "react-router-dom";

function CTA() {
  const navigate = useNavigate();

  return (
    <section className="bg-slate-900 py-20">
      <div className="mx-auto max-w-6xl px-6 text-center">

        <h2 className="text-4xl font-bold text-white md:text-5xl">
          One Customer.
          <span className="text-indigo-400"> One Trusted View.</span>
        </h2>

        <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-300">
          Bring fragmented customer information together and create a
          unified, trusted Customer 360 experience.
        </p>

        <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">

          <button
            onClick={() => navigate("/admin/dashboard")}
            className="rounded-lg bg-indigo-600 px-7 py-3 font-semibold text-white transition hover:bg-indigo-500"
          >
            Continue as Admin
          </button>

          <button
            onClick={() => navigate("/customer/dashboard")}
            className="rounded-lg border border-slate-500 px-7 py-3 font-semibold text-white transition hover:bg-slate-800"
          >
            Continue as Customer
          </button>

        </div>

      </div>
    </section>
  );
}

export default CTA;