const users = [
  {
    title: "Admin",
    subtitle: "Data Steward",
    description:
      "Manage the customer data ecosystem and maintain trusted master records.",
    points: [
      "Upload source data",
      "Monitor processing",
      "Review customer records",
      "Trace source information"
    ]
  },
  {
    title: "Customer",
    subtitle: "Banking User",
    description:
      "View a complete and unified representation of your banking relationship.",
    points: [
      "View personal profile",
      "View accounts",
      "View credit cards",
      "View loans and transactions"
    ]
  }
];

function UsersSection() {
  return (
    <section id="users" className="py-24">
      <div className="mx-auto max-w-7xl px-6">

        <div className="text-center">
          <p className="text-sm uppercase tracking-widest text-violet-400">
            Built for both sides
          </p>

          <h2 className="mt-3 text-4xl font-bold">
            One platform, two experiences.
          </h2>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2">
          {users.map((user) => (
            <div
              key={user.title}
              className="rounded-3xl border border-white/10 bg-white/5 p-8"
            >
              <p className="text-sm text-violet-400">
                {user.subtitle}
              </p>

              <h3 className="mt-2 text-3xl font-bold">
                {user.title}
              </h3>

              <p className="mt-4 leading-7 text-slate-400">
                {user.description}
              </p>

              <div className="mt-6 space-y-3">
                {user.points.map((point) => (
                  <div
                    key={point}
                    className="flex items-center gap-3 text-sm text-slate-300"
                  >
                    <span className="text-violet-400">✓</span>
                    {point}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default UsersSection;