const steps = [
  {
    number: "01",
    title: "Ingest",
    description:
      "Bring customer data together from multiple banking systems."
  },
  {
    number: "02",
    title: "Standardize",
    description:
      "Clean and standardize names, addresses, contact details and other fields."
  },
  {
    number: "03",
    title: "Match",
    description:
      "Identify duplicate identities using exact and fuzzy matching."
  },
  {
    number: "04",
    title: "Survive",
    description:
      "Resolve conflicting values using source-priority rules."
  },
  {
    number: "05",
    title: "Unify",
    description:
      "Create a trusted Golden Record and Customer 360 view."
  }
];

function HowItWorks() {
  return (
    <section
      id="how-it-works"
      className="border-t border-white/10 py-24"
    >
      <div className="mx-auto max-w-7xl px-6">

        <div className="max-w-2xl">
          <p className="text-sm font-medium uppercase tracking-widest text-violet-400">
            How it works
          </p>

          <h2 className="mt-3 text-4xl font-bold">
            From fragmented data to one trusted identity.
          </h2>

          <p className="mt-4 text-slate-400">
            A complete MDM pipeline for creating a unified
            Customer 360.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-5">
          {steps.map((step) => (
            <div
              key={step.number}
              className="rounded-2xl border border-white/10 bg-white/5 p-5"
            >
              <span className="text-sm text-violet-400">
                {step.number}
              </span>

              <h3 className="mt-4 text-lg font-semibold">
                {step.title}
              </h3>

              <p className="mt-3 text-sm leading-6 text-slate-400">
                {step.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default HowItWorks;