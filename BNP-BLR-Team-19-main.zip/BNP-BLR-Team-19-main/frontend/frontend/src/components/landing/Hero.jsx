import { useState } from "react";
import { useNavigate } from "react-router-dom";
import bnpLogo from "../../assets/BNP_LOGO.jpg";

function Hero() {
  const [role, setRole] = useState("admin");
  const navigate = useNavigate();

  const handleContinue = () => {
    if (role === "admin") {
      navigate("/admin/dashboard");
    } else {
      navigate("/customer/dashboard");
    }
  };

  return (
    <section className="relative min-h-[calc(100vh-80px)] overflow-hidden bg-white">

      {/* Soft green background shapes */}
      <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-emerald-100/60 blur-3xl" />

      <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-green-50 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6">

        {/* Navbar */}
        <nav className="flex items-center justify-between border-b border-slate-100 py-5">

          {/* BNP Logo */}
          <div className="flex items-center">
            <img
              src={bnpLogo}
              alt="BNP Paribas"
              className="h-11 w-auto object-contain"
            />
          </div>

          {/* Platform label */}
          <div className="hidden items-center gap-2 text-sm text-slate-500 sm:flex">
            <span className="h-2 w-2 rounded-full bg-[#009464]" />
            Customer Data Platform
          </div>

        </nav>

        {/* Main Hero */}
        <div className="grid items-center gap-16 py-20 lg:grid-cols-2 lg:py-28">

          {/* LEFT */}
          <div>

            {/* Badge */}
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-medium text-[#007A54]">

              <span className="h-2 w-2 rounded-full bg-[#009464]" />

              Automated Master Data Management

            </div>

            {/* Heading */}
            <h1 className="max-w-3xl text-5xl font-bold leading-[1.08] tracking-tight text-slate-900 md:text-6xl">

              One Customer.

              <span className="block text-[#009464]">
                One Trusted View.
              </span>

            </h1>

            {/* Description */}
            <p className="mt-7 max-w-xl text-lg leading-8 text-slate-600">

              Unify customer information across banking systems,
              resolve duplicate identities, and create a trusted
              Golden Record for a complete Customer 360 view.

            </p>

            {/* Buttons */}
            <div className="mt-9 flex flex-wrap gap-4">

              <button
                onClick={handleContinue}
                className="rounded-xl bg-[#009464] px-7 py-3.5 font-semibold text-white shadow-lg shadow-emerald-900/10 transition hover:bg-[#007A54]"
              >
                Enter as {role === "admin" ? "Admin" : "Customer"}
              </button>

              <a
                href="#how-it-works"
                className="rounded-xl border border-slate-200 bg-white px-7 py-3.5 font-semibold text-slate-700 transition hover:border-emerald-300 hover:bg-emerald-50"
              >
                Explore Platform
              </a>

            </div>

            {/* Trust indicators */}
            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-slate-500">

              <div className="flex items-center gap-2">
                <span className="text-[#009464]">✓</span>
                Multi-source data
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[#009464]">✓</span>
                Identity matching
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[#009464]">✓</span>
                Golden Records
              </div>

            </div>

          </div>

          {/* RIGHT */}
          <div
            id="access"
            className="relative"
          >

            {/* Card */}
            <div className="rounded-3xl border border-slate-200 bg-white p-7 shadow-xl shadow-slate-200/60">

              <p className="mb-5 text-sm font-medium text-slate-500">
                Choose your portal
              </p>

              {/* Role tabs */}
              <div className="grid grid-cols-2 rounded-xl bg-slate-100 p-1">

                <button
                  onClick={() => setRole("admin")}
                  className={`rounded-lg px-4 py-3 text-sm font-semibold transition ${
                    role === "admin"
                      ? "bg-[#009464] text-white shadow-sm"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  Admin
                </button>

                <button
                  onClick={() => setRole("customer")}
                  className={`rounded-lg px-4 py-3 text-sm font-semibold transition ${
                    role === "customer"
                      ? "bg-[#009464] text-white shadow-sm"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                >
                  Customer
                </button>

              </div>

              {/* Dynamic card */}
              <div className="mt-6 rounded-2xl border border-emerald-100 bg-emerald-50/50 p-6">

                {role === "admin" ? (
                  <>
                    <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-[#009464] text-xl text-white shadow-sm">
                      ◈
                    </div>

                    <h2 className="text-2xl font-bold text-slate-900">
                      Data Steward Portal
                    </h2>

                    <p className="mt-3 text-sm leading-6 text-slate-600">
                      Manage source data, monitor ingestion, review
                      customer records, and maintain trusted Golden
                      Records.
                    </p>

                    <div className="mt-6 space-y-3 text-sm text-slate-700">

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Data ingestion
                      </p>

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Customer search
                      </p>

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Customer 360
                      </p>

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Data lineage
                      </p>

                    </div>
                  </>
                ) : (
                  <>
                    <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-[#009464] text-xl text-white shadow-sm">
                      ◉
                    </div>

                    <h2 className="text-2xl font-bold text-slate-900">
                      Customer Portal
                    </h2>

                    <p className="mt-3 text-sm leading-6 text-slate-600">
                      Access your unified banking profile, products,
                      accounts, loans, cards, and transactions.
                    </p>

                    <div className="mt-6 space-y-3 text-sm text-slate-700">

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Unified profile
                      </p>

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Accounts
                      </p>

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Credit cards
                      </p>

                      <p>
                        <span className="mr-2 text-[#009464]">✓</span>
                        Loans & transactions
                      </p>

                    </div>
                  </>
                )}

              </div>

            </div>

            {/* Small decorative element */}
            <div className="absolute -bottom-5 -right-5 -z-10 h-32 w-32 rounded-3xl bg-emerald-100" />

          </div>

        </div>

      </div>

    </section>
  );
}

export default Hero;