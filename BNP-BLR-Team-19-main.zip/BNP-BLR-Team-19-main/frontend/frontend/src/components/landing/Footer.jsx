function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto max-w-7xl px-6 py-8">

        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">

          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#009464] text-sm font-bold text-white">
              U
            </div>

            <div>
              <p className="font-semibold text-slate-900">
                UniBank MDM
              </p>
              <p className="text-xs text-slate-500">
                Customer 360 Platform
              </p>
            </div>
          </div>

          {/* Description */}
          <p className="text-center text-sm text-slate-500">
            Unified. Trusted. Connected.
          </p>

        </div>

        {/* Bottom */}
        <div className="mt-6 border-t border-slate-100 pt-5 text-center text-xs text-slate-400">
          © 2026 UniBank MDM. Hackathon Project.
        </div>

      </div>
    </footer>
  );
}

export default Footer;