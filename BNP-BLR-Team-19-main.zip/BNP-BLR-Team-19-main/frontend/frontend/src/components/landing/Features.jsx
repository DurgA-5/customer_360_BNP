const features = [
  {
    number: "01",
    title: "Multi-Source Ingestion",
    description:
      "Bring customer information together from Core Banking, Credit Card and Loan systems."
  },
  {
    number: "02",
    title: "Identity Matching",
    description:
      "Identify duplicate customer identities using exact and fuzzy matching rules."
  },
  {
    number: "03",
    title: "Golden Records",
    description:
      "Resolve conflicting information using source-priority survivorship."
  },
  {
    number: "04",
    title: "Customer 360",
    description:
      "Bring identity, products and transactions into one unified customer view."
  },
  {
    number: "05",
    title: "Data Lineage",
    description:
      "See which source contributed each field in the Golden Record."
  },
  {
    number: "06",
    title: "Data Stewardship",
    description:
      "Allow authorized users to review and manually correct customer information."
  }
];

function Features() {
  return (
    <section
      id="features"
      className="border-y border-white/10 bg-white/[0.02] py-24"
    >
      <div className="mx-auto max-w-7xl px-6">

        <div className="max-w-2xl">
          <p className="text-sm uppercase tracking-widest text-violet-400">
            Platform capabilities
          </p>

          <h2 className="mt-3 text-4xl font-bold">
            Everything needed for trusted customer data.
          </h2>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.number}
              className="group rounded-2xl border border-white/10 bg-slate-900/50 p-6 transition hover:-translate-y-1 hover:border-violet-500/30"
            >
              <span className="text-sm text-violet-400">
                {feature.number}
              </span>

              <h3 className="mt-4 text-xl font-semibold">
                {feature.title}
              </h3>

              <p className="mt-3 text-sm leading-6 text-slate-400">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default Features;