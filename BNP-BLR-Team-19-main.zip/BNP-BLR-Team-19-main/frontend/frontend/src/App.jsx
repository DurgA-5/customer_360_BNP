import { BrowserRouter, Routes, Route ,Navigate} from "react-router-dom";

import LandingPage from "./pages/LandingPage";

import CustomerDashboard from "./views/customer/CustomerDashboard";

import CoreCreation from "./views/customer/pages/CoreCreation";
import CreditCardCreation from "./views/customer/pages/CreditCardCreation";
import LoanCreation from "./views/customer/pages/LoanCreation";


import AdminDashboard from "./views/admin/AdminDashboard";

import Dashboard from "./views/admin/pages/Dashboard";
import Ingestion from "./views/admin/pages/Ingestion";

import CustomerSearch from "./views/admin/pages/CustomerSearch";

import Customer360 from "./views/admin/pages/Customer360";

import JobScheduler from "./views/admin/pages/JobScheduler";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        <Route path="/" element={<LandingPage />} />

        <Route
          path="/customer/dashboard"
          element={<CustomerDashboard />}
        />

        {/* Customer source creation */}
        <Route
          path="/customer/core/create"
          element={<CoreCreation />}
        />

        <Route
          path="/customer/credit-card/create"
          element={<CreditCardCreation />}
        />

        <Route
          path="/customer/loan/create"
          element={<LoanCreation />}
        />
<Route
    path="/admin"
    element={<AdminDashboard />}
  >

    {/* /admin */}
    <Route
      index
      element={
        <Navigate
          to="/admin/dashboard"
          replace
        />
      }
    />

    {/* /admin/dashboard */}
    <Route
      path="dashboard"
      element={<Dashboard />}
    />

    <Route
          path="jobs"
          element={<JobScheduler />}
        />

    {/* /admin/customers */}
    <Route
      path="customers"
      element={<CustomerSearch />}
    />

    {/* /admin/customer-360 (picker) and /admin/customer-360/GC-12 */}
    <Route
      path="customer-360"
      element={<Customer360 />}
    />

    <Route
      path="customer-360/:customerId"
      element={<Customer360 />}
    />

  </Route>

     
      </Routes>
    </BrowserRouter>
  );
}

export default App;