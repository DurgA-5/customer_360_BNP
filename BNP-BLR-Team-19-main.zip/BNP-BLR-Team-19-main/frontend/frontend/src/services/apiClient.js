import axios from "axios";

/**
 * All requests go to /api/v1. In development Vite proxies /api to the
 * Express backend (see vite.config.js), so no CORS setup is needed.
 * Set VITE_API_BASE_URL to call a backend on another origin.
 *
 * Backend envelope:
 *   success -> { success: true, data, meta?, message? }
 *   failure -> { success: false, error: { code, message, details? } }
 */
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api/v1",
  timeout: 120000,
  // No default Content-Type: axios sets JSON for objects and the correct
  // multipart boundary for FormData. A hard-coded "application/json" makes
  // axios serialise FormData uploads into JSON.
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiError = error.response?.data?.error;

    const normalized = new Error(
      apiError?.message ||
        (error.code === "ECONNABORTED"
          ? "The request timed out. Please try again."
          : error.response
            ? `Request failed (${error.response.status})`
            : "Cannot reach the server. Is the backend running?")
    );

    normalized.status = error.response?.status ?? null;
    normalized.code = apiError?.code ?? error.code ?? null;
    normalized.details = apiError?.details ?? null;

    return Promise.reject(normalized);
  }
);

export default apiClient;
