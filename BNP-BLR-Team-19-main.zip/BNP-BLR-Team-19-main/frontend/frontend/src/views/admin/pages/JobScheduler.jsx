import CronExpressionGenerator from "../components/CronExpressionGenerator";
import ScheduledJobCard from "../components/ScheduledJobCard";
import JobHistoryTable from "../components/JobHistoryTable";

function JobScheduler() {
  return (
    <div className="p-8">

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">
          Job Scheduler
        </h1>

        <p className="mt-2 text-sm text-slate-500">
          Schedule and monitor automated MDM processing jobs.
        </p>
      </div>

      {/* Create schedule */}
      <CronExpressionGenerator />

     

    </div>
  );
}

export default JobScheduler;