import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import useIngestion from "../hooks/useIngestion";
import { STATUS_STYLES, shortJobId } from "../components/jobStatus";

const SOURCES = [
  {
    value: "core_banking",
    label: "Core Banking",
    columns: "customer_id, name, email, phone, address, dob",
  },
  {
    value: "credit_card",
    label: "Credit Card",
    columns: "cust_ref, name, email, phone, address, credit_limit",
  },
  {
    value: "loan",
    label: "Loan System",
    columns: "loan_cust_id, name, phone, address, loan_amt",
  },
  {
    value: "transaction_data",
    label: "Transaction Data",
    columns:
      "txn_id, account_id (= Core Banking customer_id), amount, transaction_date, type (CREDIT/DEBIT)",
  },
];

const STEPS = ["queued", "processing", "matching", "completed"];

const Ingestion = () => {
  const [source, setSource] = useState("");
  const [file, setFile] = useState(null);
  const [formError, setFormError] = useState(null);
  const fileInput = useRef(null);

  const { job, loading, error, isProcessing, uploadFile, reset } =
    useIngestion();

  const selectedSource = SOURCES.find((item) => item.value === source);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setFormError(null);

    if (!source) return setFormError("Select a source system.");
    if (!file) return setFormError("Choose a CSV file to upload.");

    const started = await uploadFile(source, file);
    if (started && fileInput.current) {
      fileInput.current.value = "";
      setFile(null);
    }
  };

  const busy = loading || isProcessing;

  return (
    <main className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Data Ingestion</h1>

        <p className="mt-2 text-sm text-gray-500">
          Upload and process customer data from different banking systems.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white border border-gray-200 rounded-xl p-6"
      >
        <h2 className="text-lg font-semibold text-gray-900">Data Source</h2>

        <p className="mt-1 text-sm text-gray-500">
          Select the source system and upload its CSV file.
        </p>

        <div className="mt-6">
          <label
            htmlFor="source"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Source
          </label>

          <select
            id="source"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            disabled={busy}
            className="w-full max-w-md border border-gray-300 rounded-lg px-4 py-3"
          >
            <option value="">Select source</option>
            {SOURCES.map((item) => (
              <option key={item.value} value={item.value}>
                {item.label}
              </option>
            ))}
          </select>

          {selectedSource && (
            <p className="mt-2 text-xs text-gray-500">
              Expected columns:{" "}
              <span className="font-mono">{selectedSource.columns}</span>
            </p>
          )}
        </div>

        <div className="mt-6">
          <label
            htmlFor="file"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            CSV File
          </label>

          <input
            id="file"
            ref={fileInput}
            type="file"
            accept=".csv,text/csv"
            disabled={busy}
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="block w-full max-w-md border border-gray-300 rounded-lg px-4 py-3 text-sm"
          />
        </div>

        {(formError || error) && (
          <p className="mt-4 text-sm text-red-600">{formError || error}</p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="mt-6 bg-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-60"
        >
          {loading
            ? "Uploading..."
            : isProcessing
              ? "Processing..."
              : "Upload & Process"}
        </button>
      </form>

      {job && <JobStatus job={job} onReset={reset} />}
    </main>
  );
};

const JobStatus = ({ job, onReset }) => {
  const currentStep = STEPS.indexOf(job.status);
  const matching = job.summary?.matching;
  const txnSummary = job.summary?.transactions;
  const goldenCheck = job.summary?.golden_check;
  const rows = job.summary?.rows || [];

  return (
    <section className="bg-white border border-gray-200 rounded-xl p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">
            Job <span className="font-mono">{shortJobId(job.jobId)}</span>
          </h2>
          <p className="mt-1 text-sm text-gray-500">
            {job.sourceLabel} · {job.fileName}
          </p>
        </div>

        <span
          className={`px-3 py-1 rounded-full text-xs font-medium ${
            STATUS_STYLES[job.status] || STATUS_STYLES.queued
          }`}
        >
          {job.status}
        </span>
      </div>

      {job.status !== "failed" && (
        <ol className="mt-6 grid grid-cols-4 gap-2 text-xs">
          {STEPS.map((step, index) => (
            <li key={step}>
              <div
                className={`h-1.5 rounded-full ${
                  index <= currentStep ? "bg-purple-600" : "bg-gray-200"
                }`}
              />
              <p className="mt-2 capitalize text-gray-600">{step}</p>
            </li>
          ))}
        </ol>
      )}

      <dl className="mt-6 grid grid-cols-3 gap-4 text-sm">
        <Metric label="Rows received" value={job.recordsReceived} />
        <Metric label="Inserted" value={job.recordsInserted} />
        <Metric label="Rejected" value={job.recordsRejected} />
      </dl>

      {goldenCheck && (
        <dl className="mt-4 grid grid-cols-3 gap-4 text-sm">
          <Metric label="Existing customers" value={goldenCheck.existing} />
          <Metric label="New customers" value={goldenCheck.new} />
          <Metric label="Conflicts (will merge)" value={goldenCheck.conflict} />
        </dl>
      )}

      {job.errorMessage && (
        <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">
          {job.errorMessage}
        </p>
      )}

      {matching && !matching.error && (
        <p className="mt-4 rounded-lg bg-green-50 p-3 text-sm text-green-700">
          Matching complete: {matching.input_records} source records resolved
          into {matching.golden_records} golden customers.
        </p>
      )}

      {txnSummary && (
        <p className="mt-4 rounded-lg bg-green-50 p-3 text-sm text-green-700">
          {txnSummary.transactions} transactions attached to customer accounts
          {txnSummary.unlinked_transactions > 0 &&
            ` · ${txnSummary.unlinked_transactions} waiting for a matching Core Banking account`}
          .
        </p>
      )}

      {rows.length > 0 && (
        <GoldenCheckTable rows={rows} truncated={job.summary.rows_truncated} />
      )}

      {job.summary?.rejected?.length > 0 && (
        <details className="mt-4 text-sm">
          <summary className="cursor-pointer font-medium text-gray-700">
            Rejected rows ({job.recordsRejected})
          </summary>
          <ul className="mt-2 space-y-1 text-gray-600">
            {job.summary.rejected.map((row) => (
              <li key={`${row.line}-${row.reason}`}>
                Line {row.line}: {row.reason}
              </li>
            ))}
          </ul>
        </details>
      )}

      {job.isTerminal && (
        <div className="mt-6 flex gap-4 text-sm">
          <Link
            to="/admin/customers"
            className="font-medium text-purple-600 hover:underline"
          >
            View customers
          </Link>
          <button
            type="button"
            onClick={onReset}
            className="font-medium text-gray-600 hover:underline"
          >
            Dismiss
          </button>
        </div>
      )}
    </section>
  );
};

const CHECK_STYLES = {
  existing: "bg-blue-100 text-blue-700",
  new: "bg-green-100 text-green-700",
  conflict: "bg-yellow-100 text-yellow-800",
};

const checkLabel = (row) => {
  if (row.status === "existing") {
    return `existing → ${row.existingCustomerIds[0]} (${row.matchedOn.join(" + ")})`;
  }
  if (row.status === "conflict") {
    return `matches ${row.existingCustomerIds.join(" & ")} → merging`;
  }
  return "new customer";
};

/** Per-row result of the golden_customer check + where each row ended up. */
const GoldenCheckTable = ({ rows, truncated }) => (
  <details className="mt-4 text-sm" open={rows.length <= 20}>
    <summary className="cursor-pointer font-medium text-gray-700">
      Golden customer check ({rows.length}
      {truncated ? "+" : ""} rows)
    </summary>

    <div className="mt-3 max-h-96 overflow-auto rounded-lg border border-gray-200">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-gray-50 text-left">
          <tr>
            <th className="px-4 py-2 font-medium text-gray-500">Line</th>
            <th className="px-4 py-2 font-medium text-gray-500">Name</th>
            <th className="px-4 py-2 font-medium text-gray-500">Check</th>
            <th className="px-4 py-2 font-medium text-gray-500">Customer</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.line} className="border-t border-gray-100">
              <td className="px-4 py-2 text-gray-500">{row.line}</td>
              <td className="px-4 py-2 text-gray-800">{row.name}</td>
              <td className="px-4 py-2">
                <span
                  className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                    CHECK_STYLES[row.status]
                  }`}
                >
                  {checkLabel(row)}
                </span>
              </td>
              <td className="px-4 py-2">
                {row.goldenCustomerId ? (
                  <Link
                    to={`/admin/customer-360/${row.goldenCustomerId}`}
                    className="font-medium text-purple-600 hover:underline"
                  >
                    {row.goldenCustomerId}
                  </Link>
                ) : (
                  <span className="text-gray-400">pending matching</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>

    {truncated && (
      <p className="mt-2 text-xs text-gray-500">
        Showing the first {rows.length} rows.
      </p>
    )}
  </details>
);

const Metric = ({ label, value }) => (
  <div className="rounded-lg bg-gray-50 p-4">
    <dt className="text-gray-500">{label}</dt>
    <dd className="mt-1 text-xl font-bold text-gray-900">
      {(value ?? 0).toLocaleString("en-IN")}
    </dd>
  </div>
);

export default Ingestion;
