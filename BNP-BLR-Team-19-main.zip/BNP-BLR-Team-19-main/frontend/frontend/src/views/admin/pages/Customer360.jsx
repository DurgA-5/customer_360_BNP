import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import useCustomer360 from "../hooks/useCustomer360";

const formatINR = (value) =>
  typeof value === "number" ? `₹${value.toLocaleString("en-IN")}` : "—";

const IDENTITY_FIELDS = [
  { key: "name", label: "Full Name" },
  { key: "email", label: "Email" },
  { key: "phone", label: "Phone" },
  { key: "dob", label: "Date of Birth" },
  { key: "address", label: "Address" },
];

const Customer360 = () => {
  const { customerId } = useParams();
  const { data, loading, error, refetch } = useCustomer360(customerId);
  const [activeTab, setActiveTab] = useState("overview");

  if (!customerId) return <CustomerPicker />;

  if (loading && !data) {
    return (
      <main className="p-6">
        <div className="h-48 animate-pulse rounded-xl border border-gray-200 bg-white" />
      </main>
    );
  }

  if (error || !data) {
    return (
      <main className="p-6 space-y-4">
        <div className="rounded-xl bg-red-50 p-6 text-red-700">
          {error || "Customer could not be loaded."}
        </div>
        <div className="flex gap-4 text-sm">
          <button
            type="button"
            onClick={refetch}
            className="font-medium text-purple-600 hover:underline"
          >
            Retry
          </button>
          <Link
            to="/admin/customers"
            className="font-medium text-gray-600 hover:underline"
          >
            Back to search
          </Link>
        </div>
      </main>
    );
  }

  // Defaults so a partial API response never crashes the page.
  const customer = data.customer || {};
  const products = {
    accounts: data.products?.accounts || [],
    creditCards: data.products?.creditCards || [],
    loans: data.products?.loans || [],
  };
  const transactions = Array.isArray(data.transactions)
    ? data.transactions
    : [];
  const lineage = Array.isArray(data.lineage) ? data.lineage : [];
  const sources = Array.isArray(customer.sources) ? customer.sources : [];

  // field -> contributing source label, from survivorship lineage
  const sourceByField = Object.fromEntries(
    lineage.map((item) => [item.field, item.sourceLabel]),
  );

  return (
    <main className="p-6 space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Link to="/admin/customers" className="hover:text-gray-800">
            Customers
          </Link>
          <span>/</span>
          <span className="text-gray-700">Customer 360</span>
        </div>

        <div className="mt-2 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Customer 360</h1>

            <p className="mt-1 text-sm text-gray-500">
              Unified view of customer {customer.goldenCustomerId}
              {sources.length > 0 &&
                ` · merged from ${sources
                  .map((s) => `${s.records} ${s.label}`)
                  .join(", ")}`}
            </p>
          </div>

          <button
            type="button"
            onClick={refetch}
            className="border border-gray-300 px-4 py-2 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Refresh
          </button>
        </div>
      </div>

      {/* Golden Record */}
      <section className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        <div className="bg-gradient-to-r from-purple-700 to-indigo-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-100">Golden Record</p>

              <h2 className="text-2xl font-bold mt-1">
                {customer.name || "Unnamed customer"}
              </h2>

              <p className="text-sm text-purple-100 mt-1">
                {customer.goldenCustomerId}
              </p>
            </div>

            <div className="text-right">
              <p className="text-xs text-purple-100">Data Quality</p>

              <p className="text-3xl font-bold">{customer.qualityScore}%</p>
            </div>
          </div>
        </div>

        {/* Identity fields */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {IDENTITY_FIELDS.map(({ key, label }) => (
            <Field
              key={key}
              label={label}
              value={customer[key]}
              source={sourceByField[key]}
            />
          ))}

          <Field
            label="Golden Customer ID"
            value={customer.goldenCustomerId}
            source="MDM"
          />
        </div>
      </section>

      {/* Tabs */}
      <div className="bg-white border border-gray-200 rounded-xl">
        <div className="border-b border-gray-200 px-6">
          <div className="flex gap-6">
            {[
              ["overview", "Overview"],
              ["products", "Products"],
              ["transactions", `Transactions (${transactions.length})`],
              ["lineage", "Source Trace"],
            ].map(([key, label]) => (
              <TabButton
                key={key}
                active={activeTab === key}
                onClick={() => setActiveTab(key)}
              >
                {label}
              </TabButton>
            ))}
          </div>
        </div>

        <div className="p-6">
          {activeTab === "overview" && (
            <Overview products={products} transactions={transactions} />
          )}

          {activeTab === "products" && <Products products={products} />}

          {activeTab === "transactions" && (
            <Transactions transactions={transactions} />
          )}

          {activeTab === "lineage" && <SourceLineage lineage={lineage} />}
        </div>
      </div>
    </main>
  );
};

/* =========================
   CUSTOMER PICKER (no id in URL)
========================= */

const CustomerPicker = () => {
  const navigate = useNavigate();
  const [value, setValue] = useState("");

  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold text-gray-900">Customer 360</h1>
      <p className="mt-1 text-sm text-gray-500">
        Open a customer from{" "}
        <Link to="/admin/customers" className="text-purple-600 hover:underline">
          Customer Search
        </Link>
        , or enter a golden customer ID.
      </p>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (value.trim()) navigate(`/admin/customer-360/${value.trim()}`);
        }}
        className="mt-6 flex max-w-md gap-3"
      >
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="GC-1"
          className="flex-1 border border-gray-300 rounded-lg px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-purple-500"
        />
        <button
          type="submit"
          className="bg-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-purple-700"
        >
          Open
        </button>
      </form>
    </main>
  );
};

/* =========================
   FIELD
========================= */

const Field = ({ label, value, source }) => {
  return (
    <div>
      <p className="text-xs uppercase tracking-wide text-gray-400">{label}</p>

      <p className="mt-1 text-sm font-medium text-gray-900 break-words">
        {value ?? "—"}
      </p>

      {source && (
        <span className="inline-block mt-2 px-2 py-1 rounded-md bg-purple-50 text-purple-700 text-xs">
          Source: {source}
        </span>
      )}
    </div>
  );
};

/* =========================
   TAB BUTTON
========================= */

const TabButton = ({ active, onClick, children }) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`py-4 text-sm font-medium border-b-2 ${
        active
          ? "border-purple-600 text-purple-600"
          : "border-transparent text-gray-500 hover:text-gray-800"
      }`}
    >
      {children}
    </button>
  );
};

/* =========================
   OVERVIEW
========================= */

const Overview = ({ products, transactions }) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900">
          Customer Overview
        </h3>

        <p className="text-sm text-gray-500 mt-1">
          Summary of the customer&apos;s products and recent activity.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <SummaryCard title="Bank Accounts" value={products.accounts.length} />
        <SummaryCard title="Credit Cards" value={products.creditCards.length} />
        <SummaryCard title="Loans" value={products.loans.length} />
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Recent Transactions
        </h3>

        <Transactions transactions={transactions.slice(0, 3)} />
      </div>
    </div>
  );
};

const SummaryCard = ({ title, value }) => {
  return (
    <div className="border border-gray-200 rounded-xl p-5">
      <p className="text-sm text-gray-500">{title}</p>

      <p className="mt-2 text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
};

/* =========================
   PRODUCTS
========================= */

const Empty = ({ children }) => (
  <p className="rounded-xl border border-dashed border-gray-200 p-5 text-sm text-gray-500">
    {children}
  </p>
);

const Products = ({ products }) => {
  return (
    <div className="space-y-8">
      <ProductSection title="Bank Accounts">
        {products.accounts.length === 0 && <Empty>No bank accounts.</Empty>}
        {products.accounts.map((account) => (
          <div
            key={account.accountId}
            className="border border-gray-200 rounded-xl p-5"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Field
                label="Account ID"
                value={account.accountId}
                source="Core Banking"
              />
              <Field
                label="Source Account"
                value={account.sourceAccountId}
                source="Core Banking"
              />
              <Field
                label="Type"
                value={account.accountType}
                source="Core Banking"
              />
              <Field
                label="Status"
                value={account.status}
                source="Core Banking"
              />
            </div>
          </div>
        ))}
      </ProductSection>

      <ProductSection title="Credit Cards">
        {products.creditCards.length === 0 && <Empty>No credit cards.</Empty>}
        {products.creditCards.map((card) => (
          <div
            key={card.creditCardId}
            className="border border-gray-200 rounded-xl p-5"
          >
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Field
                label="Card ID"
                value={card.creditCardId}
                source="Credit Card"
              />
              <Field
                label="Customer Reference"
                value={card.sourceCustRef}
                source="Credit Card"
              />
              <Field
                label="Credit Limit"
                value={formatINR(card.creditLimit)}
                source="Credit Card"
              />
            </div>
          </div>
        ))}
      </ProductSection>

      <ProductSection title="Loans">
        {products.loans.length === 0 && <Empty>No loans.</Empty>}
        {products.loans.map((loan) => (
          <div
            key={loan.loanId}
            className="border border-gray-200 rounded-xl p-5"
          >
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Field label="Loan ID" value={loan.loanId} source="Loan System" />
              <Field
                label="Loan Customer ID"
                value={loan.sourceLoanCustId}
                source="Loan System"
              />
              <Field
                label="Loan Amount"
                value={formatINR(loan.loanAmount)}
                source="Loan System"
              />
            </div>
          </div>
        ))}
      </ProductSection>
    </div>
  );
};

const ProductSection = ({ title, children }) => {
  return (
    <section>
      <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>

      <div className="space-y-3">{children}</div>
    </section>
  );
};

/* =========================
   TRANSACTIONS
========================= */

const Transactions = ({ transactions }) => {
  if (transactions.length === 0) {
    return <Empty>No transactions recorded.</Empty>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-200 text-left">
            <th className="pb-3 text-gray-500 font-medium">Transaction ID</th>
            <th className="pb-3 text-gray-500 font-medium">Account</th>
            <th className="pb-3 text-gray-500 font-medium">Date</th>
            <th className="pb-3 text-gray-500 font-medium">Type</th>
            <th className="pb-3 text-gray-500 font-medium text-right">
              Amount
            </th>
          </tr>
        </thead>

        <tbody>
          {transactions.map((transaction) => (
            <tr key={transaction.id} className="border-b border-gray-100">
              <td className="py-4 font-medium">{transaction.transactionId}</td>
              <td className="py-4 text-gray-600">{transaction.accountId}</td>
              <td className="py-4 text-gray-600">
                {transaction.transactionDate}
              </td>
              <td className="py-4">
                <span
                  className={`px-2 py-1 rounded-md text-xs font-medium ${
                    transaction.type === "CREDIT"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {transaction.type}
                </span>
              </td>
              <td className="py-4 text-right font-medium">
                {formatINR(transaction.amount)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

/* =========================
   SOURCE LINEAGE (source trace)
========================= */

const CANDIDATE_STYLES = {
  winner: "bg-green-100 text-green-800 border-green-200",
  "lower priority": "bg-gray-50 text-gray-600 border-gray-200",
  "no value": "bg-white text-gray-400 border-dashed border-gray-300",
};

const SourceLineage = ({ lineage }) => {
  return (
    <div>
      <div className="mb-5">
        <h3 className="text-lg font-semibold text-gray-900">Source Trace</h3>

        <p className="text-sm text-gray-500 mt-1">
          Which source supplied each Golden Record value, and why it won.
        </p>
      </div>

      {lineage.length === 0 ? (
        <Empty>No lineage recorded for this customer.</Empty>
      ) : (
        <div className="border border-gray-200 rounded-xl overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="text-left">
                <th className="px-5 py-3 font-medium text-gray-500">Field</th>
                <th className="px-5 py-3 font-medium text-gray-500">
                  Golden Value
                </th>
                <th className="px-5 py-3 font-medium text-gray-500">
                  Source Trace
                </th>
                <th className="px-5 py-3 font-medium text-gray-500">Why</th>
              </tr>
            </thead>

            <tbody>
              {lineage.map((item) => (
                <tr
                  key={item.field}
                  className="border-t border-gray-100 align-top"
                >
                  <td className="px-5 py-4 font-medium text-gray-800">
                    {item.fieldLabel || item.field}
                  </td>

                  <td className="px-5 py-4 text-gray-700">
                    {item.goldenValue ?? (
                      <span className="text-gray-400">—</span>
                    )}
                  </td>

                  <td className="px-5 py-4">
                    {item.sourceLabel ? (
                      <>
                        <span className="whitespace-nowrap px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-medium">
                          {item.sourceLabel}
                        </span>
                        <span className="ml-2 whitespace-nowrap text-xs text-gray-400">
                          record #{item.sourceRawId}
                        </span>
                      </>
                    ) : (
                      <span className="text-xs text-gray-400">no source</span>
                    )}
                  </td>

                  <td className="px-5 py-4">
                    <p className="text-gray-700">{item.why}</p>

                    {item.priority?.length > 0 && (
                      <p className="mt-2 text-xs text-gray-500">
                        Priority:{" "}
                        {item.priority.map((p, index) => (
                          <span key={p.source}>
                            {index > 0 && " → "}
                            <span
                              className={
                                p.source === item.source
                                  ? "font-semibold text-purple-700"
                                  : undefined
                              }
                            >
                              {p.rank}. {p.label}
                            </span>
                          </span>
                        ))}
                      </p>
                    )}

                    {item.candidates?.length > 1 && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {item.candidates.map((c) => (
                          <span
                            key={`${c.source}-${c.rawId}`}
                            title={c.status}
                            className={`rounded-md border px-2 py-1 text-xs ${
                              CANDIDATE_STYLES[c.status] ||
                              CANDIDATE_STYLES["lower priority"]
                            }`}
                          >
                            {c.label} #{c.rawId}: {c.value ?? "no value"}
                          </span>
                        ))}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Customer360;
