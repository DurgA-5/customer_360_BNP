import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import useCustomers from "../hooks/useCustomers";

const PAGE_SIZE = 20;

const qualityBadge = (score) =>
  score >= 90
    ? "bg-green-100 text-green-700"
    : score >= 70
      ? "bg-yellow-100 text-yellow-700"
      : "bg-red-100 text-red-700";

const CustomerSearch = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // The URL is the source of truth so searches are shareable and survive back-navigation.
  const q = searchParams.get("q") || "";
  const page = Number(searchParams.get("page")) || 1;

  const [input, setInput] = useState(q);
  const { customers, meta, loading, error, search } = useCustomers();

  useEffect(() => {
    search({ q: q || undefined, page, limit: PAGE_SIZE });
  }, [q, page, search]);

  const submit = (event) => {
    event.preventDefault();
    const next = {};
    if (input.trim()) next.q = input.trim();
    setSearchParams(next);
  };

  const goToPage = (nextPage) => {
    const next = { page: String(nextPage) };
    if (q) next.q = q;
    setSearchParams(next);
  };

  return (
    <main className="p-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Customer Search</h1>

        <p className="mt-1 text-sm text-gray-500">
          Search and manage unified customer records.
        </p>
      </div>

      {/* Search */}
      <form
        onSubmit={submit}
        className="mt-6 bg-white border border-gray-200 rounded-xl p-6"
      >
        <h2 className="text-lg font-semibold text-gray-900">
          Search Customers
        </h2>

        <div className="mt-4 flex gap-3">
          <input
            type="search"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search by name, email, phone or GC-id..."
            className="flex-1 border border-gray-300 rounded-lg px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-purple-500"
          />

          <button
            type="submit"
            className="bg-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-purple-700"
          >
            Search
          </button>
        </div>
      </form>

      {/* Customer table */}
      <div className="mt-6 bg-white border border-gray-200 rounded-xl p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Customers</h2>
          {meta && (
            <p className="text-sm text-gray-500">
              {meta.total.toLocaleString("en-IN")} result
              {meta.total === 1 ? "" : "s"}
            </p>
          )}
        </div>

        {error && (
          <p className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">
            {error}
          </p>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-left">
                <th className="pb-3 text-gray-500 font-medium">Customer ID</th>
                <th className="pb-3 text-gray-500 font-medium">Name</th>
                <th className="pb-3 text-gray-500 font-medium">Email</th>
                <th className="pb-3 text-gray-500 font-medium">Phone</th>
                <th className="pb-3 text-gray-500 font-medium">Quality</th>
                <th className="pb-3 text-gray-500 font-medium">Action</th>
              </tr>
            </thead>

            <tbody className={loading ? "opacity-50" : undefined}>
              {customers.map((customer) => (
                <tr
                  key={customer.goldenCustomerId}
                  className="border-b border-gray-100"
                >
                  <td className="py-4 font-medium">
                    {customer.goldenCustomerId}
                  </td>
                  <td className="py-4">{customer.name || "—"}</td>
                  <td className="py-4 text-gray-600">
                    {customer.email || "—"}
                  </td>
                  <td className="py-4 text-gray-600">
                    {customer.phone || "—"}
                  </td>
                  <td className="py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${qualityBadge(
                        customer.qualityScore
                      )}`}
                    >
                      {customer.qualityScore}%
                    </span>
                  </td>
                  <td className="py-4">
                    <button
                      type="button"
                      onClick={() =>
                        navigate(
                          `/admin/customer-360/${customer.goldenCustomerId}`
                        )
                      }
                      className="text-purple-600 font-medium hover:underline"
                    >
                      View 360
                    </button>
                  </td>
                </tr>
              ))}

              {!loading && customers.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-gray-500">
                    {q
                      ? `No customers match "${q}".`
                      : "No golden customers yet. Ingest data and run matching."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {meta && meta.totalPages > 1 && (
          <div className="mt-4 flex items-center justify-end gap-3 text-sm">
            <button
              type="button"
              disabled={page <= 1 || loading}
              onClick={() => goToPage(page - 1)}
              className="rounded-lg border border-gray-300 px-3 py-1.5 disabled:opacity-40"
            >
              Previous
            </button>
            <span className="text-gray-600">
              Page {meta.page} of {meta.totalPages}
            </span>
            <button
              type="button"
              disabled={page >= meta.totalPages || loading}
              onClick={() => goToPage(page + 1)}
              className="rounded-lg border border-gray-300 px-3 py-1.5 disabled:opacity-40"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </main>
  );
};

export default CustomerSearch;
