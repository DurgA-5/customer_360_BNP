import { useState } from "react";
import DashboardStats from "../components/DashboardStats";
import DataQualityCard from "../components/DataQualityCard";
import RecentIngestion from "../components/RecentIngestion";
import useAdminDashboard from "../hooks/useAdminDashboard";
import { runMatching } from "../api/adminApi";

const Dashboard = () => {
  const { data, loading, error, refetch } = useAdminDashboard();

  const [matching, setMatching] = useState(false);
  const [matchMessage, setMatchMessage] = useState(null);

  const handleRunMatching = async () => {
    try {
      setMatching(true);
      setMatchMessage(null);
      const response = await runMatching();
      const summary = response.data.summary;
      setMatchMessage({
        type: "success",
        text: `Matched ${summary.input_records} records into ${summary.golden_records} golden customers.`,
      });
      await refetch();
    } catch (err) {
      setMatchMessage({ type: "error", text: err.message });
    } finally {
      setMatching(false);
    }
  };

  return (
    <main className="p-6 space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>

          <p className="mt-1 text-sm text-gray-500">
            Monitor your customer master data and ingestion pipeline.
          </p>
        </div>

        <div className="flex gap-3">
          <button
            type="button"
            onClick={refetch}
            disabled={loading}
            className="border border-gray-300 px-4 py-2 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
          >
            Refresh
          </button>

          <button
            type="button"
            onClick={handleRunMatching}
            disabled={matching}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 disabled:opacity-60"
          >
            {matching ? "Running matching..." : "Run Matching"}
          </button>
        </div>
      </div>

      {matchMessage && (
        <div
          className={`rounded-lg p-4 text-sm ${
            matchMessage.type === "success"
              ? "bg-green-50 text-green-700"
              : "bg-red-50 text-red-700"
          }`}
        >
          {matchMessage.text}
        </div>
      )}

      {error && (
        <div className="rounded-lg bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      )}

      {loading && !data ? (
        <DashboardSkeleton />
      ) : data ? (
        <>
          <DashboardStats stats={data.stats} />

          {data.unlinkedRecords > 0 && (
            <div className="rounded-lg bg-yellow-50 p-4 text-sm text-yellow-800">
              {data.unlinkedRecords.toLocaleString("en-IN")} source records
              are not linked to a golden customer yet. Run matching to resolve
              them.
            </div>
          )}

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <DataQualityCard quality={data.quality} />
            <RecentIngestion jobs={data.jobs} />
          </div>
        </>
      ) : null}
    </main>
  );
};

const DashboardSkeleton = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 animate-pulse">
    {[0, 1, 2, 3].map((i) => (
      <div key={i} className="h-28 rounded-xl border border-gray-200 bg-white" />
    ))}
  </div>
);

export default Dashboard;
