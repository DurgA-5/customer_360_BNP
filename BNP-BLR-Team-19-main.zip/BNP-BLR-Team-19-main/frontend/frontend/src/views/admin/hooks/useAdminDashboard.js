import { useCallback, useEffect, useState } from "react";
import { getAdminDashboard } from "../api/adminApi";

const useAdminDashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await getAdminDashboard();
      setData(response.data);
    } catch (err) {
      console.error("Failed to load admin dashboard:", err);
      setError(err.message || "Unable to load dashboard data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { data, loading, error, refetch: load };
};

export default useAdminDashboard;
