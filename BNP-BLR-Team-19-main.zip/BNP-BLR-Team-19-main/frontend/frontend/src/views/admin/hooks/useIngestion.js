import { useCallback, useEffect, useRef, useState } from "react";
import { uploadIngestionFile, getIngestionStatus } from "../api/adminApi";

const POLL_INTERVAL_MS = 1500;
const MAX_POLL_ERRORS = 5;

/**
 * Upload a CSV and poll the ingestion job until it reaches a terminal
 * status ("completed" | "failed"). The backend processes uploads in the
 * background: queued -> processing -> matching -> completed.
 */
const useIngestion = () => {
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const timer = useRef(null);
  const pollErrors = useRef(0);

  const stopPolling = useCallback(() => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  }, []);

  useEffect(() => stopPolling, [stopPolling]);

  const startPolling = useCallback((jobId) => {
    pollErrors.current = 0;

    const tick = async () => {
      try {
        const response = await getIngestionStatus(jobId);
        pollErrors.current = 0;
        setJob(response.data);

        if (!response.data?.isTerminal) {
          timer.current = setTimeout(tick, POLL_INTERVAL_MS);
        }
      } catch (err) {
        pollErrors.current += 1;
        if (pollErrors.current >= MAX_POLL_ERRORS) {
          setError(err.message || "Unable to check processing status.");
          return;
        }
        timer.current = setTimeout(tick, POLL_INTERVAL_MS * 2);
      }
    };

    timer.current = setTimeout(tick, POLL_INTERVAL_MS);
  }, []);

  const uploadFile = useCallback(
    async (source, file) => {
      stopPolling();
      setError(null);
      setJob(null);
      setLoading(true);

      try {
        const response = await uploadIngestionFile({ source, file });
        setJob(response.data);
        startPolling(response.data.jobId);
        return response.data;
      } catch (err) {
        console.error("File upload failed:", err);
        setError(err.message || "Unable to upload file.");
        return null;
      } finally {
        setLoading(false);
      }
    },
    [startPolling, stopPolling]
  );

  const reset = useCallback(() => {
    stopPolling();
    setJob(null);
    setError(null);
  }, [stopPolling]);

  return {
    job,
    jobId: job?.jobId ?? null,
    status: job?.status ?? null,
    isProcessing: Boolean(job && !job.isTerminal),
    loading,
    error,
    uploadFile,
    reset,
  };
};

export default useIngestion;
