import { useCallback, useEffect, useState } from "react";
import { getAdminCustomer360 } from "../api/adminApi";

const useCustomer360 = (customerId) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(Boolean(customerId));
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    if (!customerId) {
      setData(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const response = await getAdminCustomer360(customerId);
      setData(response.data);
    } catch (err) {
      console.error("Failed to load customer 360:", err);
      setData(null);
      setError(
        err.status === 404
          ? `Customer ${customerId} was not found.`
          : err.message || "Unable to load customer."
      );
    } finally {
      setLoading(false);
    }
  }, [customerId]);

  useEffect(() => {
    load();
  }, [load]);

  return { data, loading, error, refetch: load };
};

export default useCustomer360;
