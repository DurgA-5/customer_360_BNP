import { useCallback, useRef, useState } from "react";
import { searchCustomers } from "../api/adminApi";

const useCustomers = () => {
  const [customers, setCustomers] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Ignore responses from searches that were superseded by a newer one.
  const latestRequest = useRef(0);

  const search = useCallback(async (params = {}) => {
    const requestId = ++latestRequest.current;

    try {
      setLoading(true);
      setError(null);

      const response = await searchCustomers(params);
      if (requestId !== latestRequest.current) return;

      setCustomers(response.data || []);
      setMeta(response.meta || null);
    } catch (err) {
      if (requestId !== latestRequest.current) return;
      console.error("Customer search failed:", err);
      setError(err.message || "Unable to search customers.");
    } finally {
      if (requestId === latestRequest.current) setLoading(false);
    }
  }, []);

  return { customers, meta, loading, error, search };
};

export default useCustomers;