import { Outlet } from "react-router-dom";
import AdminNavbar from "./components/AdminNavbar";
import AdminSidebar from "./components/AdminSidebar";

const AdminDashboard = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navbar */}
      <AdminNavbar />

      <div className="flex">
        {/* Sidebar */}
        <div className="fixed left-0 top-16 bottom-0 w-64">
          <AdminSidebar />
        </div>

        {/* Main Content */}
        <main className="ml-64 flex-1 min-h-[calc(100vh-64px)]">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;