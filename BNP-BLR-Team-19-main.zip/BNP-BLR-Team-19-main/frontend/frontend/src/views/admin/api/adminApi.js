import apiClient from "../../../services/apiClient";
import adminEndpoints from "./adminEndpoints";

// All functions return the backend envelope: { success, data, meta?, message? }

// =========================
// Dashboard
// =========================

export const getAdminDashboard = async () => {
  const response = await apiClient.get(adminEndpoints.dashboard);
  return response.data;
};

// =========================
// Ingestion
// =========================

export const uploadIngestionFile = async ({ source, file }) => {
  const formData = new FormData();
  formData.append("source", source);
  formData.append("file", file);

  const response = await apiClient.post(adminEndpoints.uploadFile, formData);
  return response.data;
};

export const getIngestionStatus = async (jobId) => {
  const response = await apiClient.get(adminEndpoints.ingestionStatus(jobId));
  return response.data;
};

export const getIngestionJobs = async (limit = 10) => {
  const response = await apiClient.get(adminEndpoints.ingestionJobs, {
    params: { limit },
  });
  return response.data;
};

// =========================
// Matching
// =========================

export const runMatching = async () => {
  const response = await apiClient.post(adminEndpoints.runMatching);
  return response.data;
};

// =========================
// Customer Search
// =========================

/** @param {{ q?: string, page?: number, limit?: number }} params */
export const searchCustomers = async (params) => {
  const response = await apiClient.get(adminEndpoints.customers, { params });
  return response.data;
};

// =========================
// Customer 360
// =========================

export const getAdminCustomer360 = async (customerId) => {
  const response = await apiClient.get(adminEndpoints.customer360(customerId));
  return response.data;
};


export const scheduleJob = async (payload) => {
  const response = await apiClient.post(
    adminEndpoints.scheduleJob,
    payload
  );

  return response.data;
};