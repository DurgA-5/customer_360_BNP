const adminEndpoints = {
  // Dashboard
  dashboard: "/admin/dashboard",

  // Ingestion
  uploadFile: "/ingestion/upload",
  ingestionJobs: "/ingestion/jobs",
  ingestionStatus: (jobId) => `/ingestion/jobs/${jobId}`,

  // Matching
  runMatching: "/matching/run",
  dryRunMatching: "/matching/dry-run",

  // Customer search
  customers: "/customers",

  // Customer 360 (profile + products + transactions + lineage in one call)
  customer360: (customerId) => `/customers/${customerId}/360`,
};

export default adminEndpoints;
