export const STATUS_STYLES = {
  completed: "bg-green-100 text-green-700",
  processing: "bg-yellow-100 text-yellow-700",
  matching: "bg-blue-100 text-blue-700",
  queued: "bg-gray-100 text-gray-700",
  failed: "bg-red-100 text-red-700",
};

export const shortJobId = (jobId) => {
  const text = String(jobId ?? "");
  return text.length > 8 ? text.slice(0, 8) : text;
};
