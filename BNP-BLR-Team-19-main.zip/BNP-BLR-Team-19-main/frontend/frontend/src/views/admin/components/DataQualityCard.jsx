const DataQualityCard = ({ quality }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">
            Data Quality
          </h2>

          <p className="text-sm text-gray-500 mt-1">
            Current master data quality
          </p>
        </div>

        <div className="text-2xl font-bold text-purple-600">
          {quality.overall}%
        </div>
      </div>

      <div className="mt-6 space-y-4">
        <QualityRow
          label="Completeness"
          value={quality.completeness}
        />

        <QualityRow
          label="Duplicate Resolution"
          value={quality.duplicateResolution}
        />

        <QualityRow
          label="Standardization"
          value={quality.standardization}
        />
      </div>
    </div>
  );
};

const QualityRow = ({ label, value }) => {
  return (
    <div>
      <div className="flex justify-between text-sm mb-2">
        <span className="text-gray-600">
          {label}
        </span>

        <span className="font-medium text-gray-800">
          {value}%
        </span>
      </div>

      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-purple-600 rounded-full"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
};

export default DataQualityCard;