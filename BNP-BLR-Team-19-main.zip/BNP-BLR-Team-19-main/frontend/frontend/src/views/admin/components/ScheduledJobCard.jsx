function ScheduledJobCard() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            Scheduled Jobs
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Manage your active MDM processing schedules.
          </p>
        </div>

        <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-[#009464]">
          Active
        </span>
      </div>

      <div className="mt-6 rounded-xl border border-slate-100 bg-slate-50 p-5">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">

          <div>
            <p className="font-medium text-slate-900">
              MDM Processing
            </p>

            <p className="mt-1 font-mono text-sm text-[#009464]">
              */5 * * * *
            </p>

            <p className="mt-1 text-xs text-slate-500">
              Every 5 minutes
            </p>
          </div>

          <div className="flex gap-2">
            <button className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 hover:bg-slate-100">
              Pause
            </button>

            <button className="rounded-lg border border-red-200 bg-white px-4 py-2 text-sm text-red-600 hover:bg-red-50">
              Delete
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}

export default ScheduledJobCard;