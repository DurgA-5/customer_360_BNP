import { NavLink } from "react-router-dom";

const AdminSidebar = () => {
  const menuItems = [
    {
      name: "Dashboard",
      path: "/admin/dashboard",
    },
    {
  name: "Job Scheduler",
  path: "/admin/jobs",
},
    {
      name: "Customer Search",
      path: "/admin/customers",
    },
    {
      name: "Customer 360",
      path: "/admin/customer-360",
    },
  ];

  return (
    <aside className="w-64 min-h-[calc(100vh-64px)] border-r border-gray-200 bg-white p-4">
      <div className="mb-6">
        <p className="text-xs font-semibold uppercase tracking-wider text-gray-400">
          Administration
        </p>
      </div>

      <nav className="space-y-2">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `block rounded-lg px-4 py-3 text-sm font-medium transition ${
                isActive
                  ? "bg-purple-100 text-purple-700"
                  : "text-gray-600 hover:bg-gray-100"
              }`
            }
          >
            {item.name}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default AdminSidebar;