import { Link } from "react-router-dom";
import { STATUS_STYLES, shortJobId } from "./jobStatus";

const RecentIngestion = ({ jobs = [] }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">
            Recent Ingestion
          </h2>

          <p className="text-sm text-gray-500">Latest data processing jobs</p>
        </div>

        <Link
          to="/admin/ingestion"
          className="text-sm font-medium text-purple-600 hover:underline"
        >
          Upload
        </Link>
      </div>

      {jobs.length === 0 ? (
        <p className="py-6 text-sm text-gray-500">
          No ingestion jobs yet. Upload a CSV to get started.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-left">
                <th className="pb-3 font-medium text-gray-500">Job ID</th>
                <th className="pb-3 font-medium text-gray-500">Source</th>
                <th className="pb-3 font-medium text-gray-500">Records</th>
                <th className="pb-3 font-medium text-gray-500">Status</th>
              </tr>
            </thead>

            <tbody>
              {jobs.map((job) => (
                <tr key={job.jobId} className="border-b border-gray-100">
                  <td
                    className="py-4 font-mono text-xs text-gray-800"
                    title={String(job.jobId)}
                  >
                    {shortJobId(job.jobId)}
                  </td>

                  <td className="py-4 text-gray-600">
                    {job.sourceLabel || job.source}
                  </td>

                  <td className="py-4 text-gray-600">
                    {job.records?.toLocaleString("en-IN")}
                  </td>

                  <td className="py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        STATUS_STYLES[job.status] || STATUS_STYLES.queued
                      }`}
                      title={job.errorMessage || undefined}
                    >
                      {job.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RecentIngestion;
