function JobHistoryTable() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6">
      <h2 className="text-lg font-semibold text-slate-900">
        Job History
      </h2>

      <p className="mt-2 text-sm text-slate-500">
        Recent MDM job executions will appear here.
      </p>
    </div>
  );
}

export default JobHistoryTable;