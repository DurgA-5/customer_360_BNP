const formatNumber = (value) =>
  typeof value === "number" ? value.toLocaleString("en-IN") : "—";

const DashboardStats = ({ stats }) => {
  const cards = [
    {
      title: "Total Customers",
      value: formatNumber(stats.totalCustomers),
      description: "Golden customer records",
    },
    {
      title: "Records Processed",
      value: formatNumber(stats.recordsProcessed),
      description: "Across all sources",
    },
    {
      title: "Duplicates Resolved",
      value: formatNumber(stats.duplicatesResolved),
      description: "Source records merged",
    },
    {
      title: "Data Quality",
      value: `${stats.dataQuality ?? 0}%`,
      description: "Overall score",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
      {cards.map((card) => (
        <div
          key={card.title}
          className="bg-white border border-gray-200 rounded-xl p-5"
        >
          <p className="text-sm text-gray-500">{card.title}</p>

          <p className="mt-2 text-3xl font-bold text-gray-900">{card.value}</p>

          <p className="mt-1 text-xs text-gray-500">{card.description}</p>
        </div>
      ))}
    </div>
  );
};

export default DashboardStats;
