import { useState } from "react";
import cronstrue from "cronstrue";
import { CronExpressionParser } from "cron-parser";
import { scheduleJob } from "../api/adminApi";

function CronExpressionGenerator() {
  const [cronExpression, setCronExpression] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const validateAndDescribeCron = (value) => {
  const expression = value.trim();

  if (!expression) {
    setDescription("");
    setError("");
    return false;
  }

  const fields = expression.split(/\s+/);

  if (fields.length !== 6) {
    setDescription("");
    setError(
      "Cron expression must contain exactly 6 fields: second minute hour day-of-month month day-of-week."
    );
    return false;
  }

  try {
    const english = cronstrue.toString(expression, {
      use24HourTimeFormat: true,
    });

    setDescription(english);
    setError("");

    return true;
  } catch (err) {
    setDescription("");
    setError("Invalid 6-field cron expression.");
    return false;
  }
};

  const handleCronChange = (e) => {
    const value = e.target.value;

    setCronExpression(value);

    validateAndDescribeCron(value);
  };

  const handleSchedule = async () => {
    const isValid = validateAndDescribeCron(cronExpression);

    if (!isValid) {
      return;
    }

    try {
      setLoading(true);

      const response = await scheduleJob({
        jobType: "mdm_processing",
        cronExpression: cronExpression.trim(),
      });

      console.log("Schedule response:", response);

      alert("Job scheduled successfully");

    } catch (error) {
      console.error("Failed to schedule job:", error);
      alert("Failed to schedule job");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6">

      <h2 className="text-lg font-semibold text-slate-900">
        Create Schedule
      </h2>

      <p className="mt-1 text-sm text-slate-500">
        Configure when the MDM processing job should run.
      </p>

      {/* Cron input */}
      <div className="mt-6">

        <label className="text-sm font-medium text-slate-700">
          Cron Expression
        </label>

        <input
          type="text"
          value={cronExpression}
          onChange={handleCronChange}
          placeholder="0 */5 * * * *"
          className={`mt-2 w-full rounded-lg border px-4 py-3 font-mono text-lg outline-none ${
            error
              ? "border-red-300 focus:border-red-500"
              : "border-slate-200 focus:border-[#009464]"
          }`}
        />

        {/* Error */}
        {error && (
          <p className="mt-2 text-sm text-red-600">
            {error}
          </p>
        )}

        {/* English description */}
        {!error && description && (
          <div className="mt-3 rounded-lg bg-emerald-50 px-4 py-3">
            <p className="text-sm text-slate-500">
              Schedule
            </p>

            <p className="mt-1 font-medium text-[#009464]">
              {description}
            </p>
          </div>
        )}

      </div>

      {/* Schedule button */}
      <button
        onClick={handleSchedule}
        disabled={loading || !!error || !cronExpression.trim()}
        className="mt-6 rounded-lg bg-[#009464] px-6 py-3 font-medium text-white hover:bg-[#007A54] disabled:cursor-not-allowed disabled:opacity-50"
      >
        {loading ? "Scheduling..." : "Schedule Job"}
      </button>

    </div>
  );
}

export default CronExpressionGenerator;