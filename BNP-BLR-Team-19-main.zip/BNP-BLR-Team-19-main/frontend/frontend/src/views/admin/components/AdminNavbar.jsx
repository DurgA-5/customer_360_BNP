const AdminNavbar = () => {
  return (
    <header className="h-16 border-b border-gray-200 bg-white px-6 flex items-center justify-between">
      <div>
        <h1 className="text-xl font-bold text-gray-900">
          UniBank MDM
        </h1>

        <p className="text-xs text-gray-500">
          Master Data Management
        </p>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className="text-sm font-medium text-gray-800">
            Data Administrator
          </p>

          <p className="text-xs text-gray-500">
            Admin
          </p>
        </div>

        <div className="w-9 h-9 rounded-full bg-purple-600 text-white flex items-center justify-center font-semibold">
          A
        </div>
      </div>
    </header>
  );
};

export default AdminNavbar;