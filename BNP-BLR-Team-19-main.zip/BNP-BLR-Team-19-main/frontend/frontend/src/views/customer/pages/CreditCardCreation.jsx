import { useNavigate, useSearchParams } from "react-router-dom";
import { useState } from "react";
import { createCreditCard } from "../api/customerApi";
import useSourceForm from "../hooks/useSourceForm";

function CreditCardCreation() {
  const navigate = useNavigate();
  // Pre-filled when the customer came from "Find your profile" and wasn't found.
  const [searchParams] = useSearchParams();

  const [formData, setFormData] = useState({
    custRef: "",
    name: "",
    email: searchParams.get("email") || "",
    phone: searchParams.get("phone") || "",
    creditLimit: "",
    address: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const { submit, submitting, error, fieldErrors } = useSourceForm(
    createCreditCard,
    (form) => ({ ...form, creditLimit: Number(form.creditLimit) }),
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    submit(formData);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-700 text-white">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <button
            onClick={() => navigate("/customer/dashboard")}
            className="mb-6 text-sm text-blue-100 hover:text-white"
          >
            ← Back to Dashboard
          </button>

          <h1 className="text-3xl font-bold">Create Credit Card Record</h1>

          <p className="mt-2 text-blue-100">
            Add your credit card information from the Credit Card system.
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="mx-auto max-w-5xl px-6 py-10">
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl bg-white p-8 shadow-sm"
        >
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900">
              Credit Card Details
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Enter the customer and credit card source details.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <FormInput
              label="Customer Reference"
              name="custRef"
              error={fieldErrors.custRef}
              value={formData.custRef}
              onChange={handleChange}
              placeholder="CC-77821"
              required
            />

            <FormInput
              label="Full Name"
              name="name"
              error={fieldErrors.name}
              value={formData.name}
              onChange={handleChange}
              placeholder="John Doe"
              required
            />

            <FormInput
              label="Email"
              name="email"
              error={fieldErrors.email}
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="john@gmail.com"
              required
            />

            <FormInput
              label="Phone"
              name="phone"
              error={fieldErrors.phone}
              value={formData.phone}
              onChange={handleChange}
              placeholder="9876543210"
              required
            />

            <FormInput
              label="Credit Limit"
              name="creditLimit"
              error={fieldErrors.creditLimit}
              type="number"
              value={formData.creditLimit}
              onChange={handleChange}
              placeholder="150000"
              required
            />

            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-medium text-gray-700">
                Address
              </label>

              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="12 Main Street, Hyderabad"
                rows="4"
                required
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />

              {fieldErrors.address && (
                <p className="mt-1 text-xs text-red-600">
                  {fieldErrors.address}
                </p>
              )}
            </div>
          </div>

          {error && (
            <div className="mt-6 rounded-xl bg-red-50 p-4 text-sm text-red-700">
              {error}
            </div>
          )}

          <div className="mt-8 flex justify-end gap-4">
            <button
              type="button"
              onClick={() => navigate("/customer/dashboard")}
              className="rounded-xl border border-gray-300 px-6 py-3 font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="rounded-xl bg-blue-600 px-6 py-3 font-semibold text-white hover:bg-blue-700 disabled:opacity-60"
            >
              {submitting ? "Saving & linking..." : "Create Credit Card"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function FormInput({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  required = false,
  error,
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-gray-700">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required={required}
        aria-invalid={Boolean(error)}
        className={`w-full rounded-xl border px-4 py-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100 ${
          error ? "border-red-400" : "border-gray-300"
        }`}
      />

      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}

export default CreditCardCreation;
