import { useNavigate, useSearchParams } from "react-router-dom";
import { useState } from "react";
import { createLoan } from "../api/customerApi";
import useSourceForm from "../hooks/useSourceForm";

function LoanCreation() {
  const navigate = useNavigate();
  // Pre-filled when the customer came from "Find your profile" and wasn't found.
  const [searchParams] = useSearchParams();

  const [formData, setFormData] = useState({
    loanCustId: "",
    name: "",
    phone: searchParams.get("phone") || "",
    loanAmount: "",
    address: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const { submit, submitting, error, fieldErrors } = useSourceForm(
    createLoan,
    (form) => ({ ...form, loanAmount: Number(form.loanAmount) }),
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    submit(formData);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <button
            onClick={() => navigate("/customer/dashboard")}
            className="mb-6 text-sm text-emerald-100 hover:text-white"
          >
            ← Back to Dashboard
          </button>

          <h1 className="text-3xl font-bold">Create Loan Record</h1>

          <p className="mt-2 text-emerald-100">
            Add your loan information from the Loan system.
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="mx-auto max-w-5xl px-6 py-10">
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl bg-white p-8 shadow-sm"
        >
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900">
              Loan Details
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Enter the loan customer and loan source information.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <FormInput
              label="Loan Customer ID"
              name="loanCustId"
              error={fieldErrors.loanCustId}
              value={formData.loanCustId}
              onChange={handleChange}
              placeholder="LN-C-77821"
              required
            />

            <FormInput
              label="Full Name"
              name="name"
              error={fieldErrors.name}
              value={formData.name}
              onChange={handleChange}
              placeholder="John Doe"
              required
            />

            <FormInput
              label="Phone"
              name="phone"
              error={fieldErrors.phone}
              value={formData.phone}
              onChange={handleChange}
              placeholder="9876543210"
              required
            />

            <FormInput
              label="Loan Amount"
              name="loanAmount"
              error={fieldErrors.loanAmount}
              type="number"
              value={formData.loanAmount}
              onChange={handleChange}
              placeholder="500000"
              required
            />

            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-medium text-gray-700">
                Address
              </label>

              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="12 Main Street, Hyderabad"
                rows="4"
                required
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
              />

              {fieldErrors.address && (
                <p className="mt-1 text-xs text-red-600">
                  {fieldErrors.address}
                </p>
              )}
            </div>
          </div>

          {error && (
            <div className="mt-6 rounded-xl bg-red-50 p-4 text-sm text-red-700">
              {error}
            </div>
          )}

          <div className="mt-8 flex justify-end gap-4">
            <button
              type="button"
              onClick={() => navigate("/customer/dashboard")}
              className="rounded-xl border border-gray-300 px-6 py-3 font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="rounded-xl bg-emerald-600 px-6 py-3 font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
            >
              {submitting ? "Saving & linking..." : "Create Loan"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function FormInput({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  required = false,
  error,
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-gray-700">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required={required}
        aria-invalid={Boolean(error)}
        className={`w-full rounded-xl border px-4 py-3 outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 ${
          error ? "border-red-400" : "border-gray-300"
        }`}
      />

      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}

export default LoanCreation;
