import { useNavigate, useSearchParams } from "react-router-dom";
import { useState } from "react";
import { createCoreRecord } from "../api/customerApi";
import useSourceForm from "../hooks/useSourceForm";

function CoreCreation() {
  const navigate = useNavigate();
  // Pre-filled when the customer came from "Find your profile" and wasn't found.
  const [searchParams] = useSearchParams();

  const [formData, setFormData] = useState({
    customerId: "",
    name: "",
    email: searchParams.get("email") || "",
    phone: searchParams.get("phone") || "",
    dob: "",
    address: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const { submit, submitting, error, fieldErrors } = useSourceForm(
    createCoreRecord,
    (form) => form,
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    submit(formData);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-700 to-indigo-700 text-white">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <button
            onClick={() => navigate("/customer/dashboard")}
            className="mb-6 text-sm text-purple-100 hover:text-white"
          >
            ← Back to Dashboard
          </button>

          <h1 className="text-3xl font-bold">Create Core Banking Record</h1>

          <p className="mt-2 text-purple-100">
            Add your customer information from the Core Banking system.
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="mx-auto max-w-5xl px-6 py-10">
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl bg-white p-8 shadow-sm"
        >
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900">
              Core Banking Details
            </h2>

            <p className="mt-1 text-sm text-gray-500">
              Enter the details exactly as they appear in the source system.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {/* Customer ID */}
            <FormInput
              label="Customer ID"
              name="customerId"
              error={fieldErrors.customerId}
              value={formData.customerId}
              onChange={handleChange}
              placeholder="CORE-1234"
              required
            />

            {/* Name */}
            <FormInput
              label="Full Name"
              name="name"
              error={fieldErrors.name}
              value={formData.name}
              onChange={handleChange}
              placeholder="John Doe"
              required
            />

            {/* Email */}
            <FormInput
              label="Email"
              name="email"
              error={fieldErrors.email}
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="john@gmail.com"
              required
            />

            {/* Phone */}
            <FormInput
              label="Phone"
              name="phone"
              error={fieldErrors.phone}
              value={formData.phone}
              onChange={handleChange}
              placeholder="9876543210"
              required
            />

            {/* DOB */}
            <FormInput
              label="Date of Birth"
              name="dob"
              error={fieldErrors.dob}
              type="date"
              value={formData.dob}
              onChange={handleChange}
              required
            />

            {/* Address */}
            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-medium text-gray-700">
                Address
              </label>

              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="12 Main Street, Hyderabad"
                rows="4"
                required
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none transition focus:border-purple-500 focus:ring-2 focus:ring-purple-100"
              />

              {fieldErrors.address && (
                <p className="mt-1 text-xs text-red-600">
                  {fieldErrors.address}
                </p>
              )}
            </div>
          </div>

          {/* Buttons */}
          {error && (
            <div className="mt-6 rounded-xl bg-red-50 p-4 text-sm text-red-700">
              {error}
            </div>
          )}

          <div className="mt-8 flex justify-end gap-4">
            <button
              type="button"
              onClick={() => navigate("/customer/dashboard")}
              className="rounded-xl border border-gray-300 px-6 py-3 font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="rounded-xl bg-purple-600 px-6 py-3 font-semibold text-white hover:bg-purple-700 disabled:opacity-60"
            >
              {submitting ? "Saving & linking..." : "Create Core Record"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function FormInput({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  required = false,
  error,
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-gray-700">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required={required}
        aria-invalid={Boolean(error)}
        className={`w-full rounded-xl border px-4 py-3 outline-none transition focus:border-purple-500 focus:ring-2 focus:ring-purple-100 ${
          error ? "border-red-400" : "border-gray-300"
        }`}
      />

      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}

export default CoreCreation;
