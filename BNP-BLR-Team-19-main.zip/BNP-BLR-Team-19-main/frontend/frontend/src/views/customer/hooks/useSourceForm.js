import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { storeCustomerId } from "../customerSession";

/**
 * Shared submit logic for the Core Banking / Credit Card / Loan forms.
 * The backend checks the golden table, stores the record, runs matching and
 * returns the golden customer id plus a message ("Welcome back!..." / "Welcome to UniBank!...").
 */
const useSourceForm = (createFn, toPayload = (form) => form) => {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [fieldErrors, setFieldErrors] = useState({});

  const submit = async (form) => {
    setSubmitting(true);
    setError(null);
    setFieldErrors({});

    try {
      const response = await createFn(toPayload(form));
      const { goldenCustomerId } = response.data;

      if (goldenCustomerId) storeCustomerId(goldenCustomerId);

      navigate(
        goldenCustomerId
          ? `/customer/dashboard?id=${encodeURIComponent(goldenCustomerId)}`
          : "/customer/dashboard",
        { state: { flash: response.message } },
      );
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
      if (err.details && typeof err.details === "object") {
        setFieldErrors(err.details);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return { submit, submitting, error, fieldErrors };
};

export default useSourceForm;
