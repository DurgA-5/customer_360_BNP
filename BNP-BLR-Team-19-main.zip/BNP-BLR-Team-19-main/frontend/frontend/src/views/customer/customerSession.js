/**
 * There is no authentication yet, so the "logged in" customer is identified
 * by their golden customer id (e.g. GC-12), taken from ?id= in the URL or
 * remembered in localStorage after they look themselves up or create a record.
 * Replace with the auth session once login exists.
 */
const STORAGE_KEY = "unibank.customerId";

export function getStoredCustomerId() {
  try {
    return localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

export function storeCustomerId(customerId) {
  try {
    if (customerId) localStorage.setItem(STORAGE_KEY, customerId);
  } catch {
    // Storage unavailable (private mode) - the URL param still works.
  }
}

export function clearStoredCustomerId() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
