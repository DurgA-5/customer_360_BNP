function CustomerHero({ customer }) {
  const firstName = customer?.name?.split(" ")[0];

  return (
    <section className="overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-700 via-indigo-600 to-purple-700 px-6 py-12 text-white shadow-lg md:px-10">
      <div className="max-w-3xl">
        <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-indigo-200">
          UniBank Customer 360
        </p>

        <h1 className="text-4xl font-bold tracking-tight md:text-5xl">
          {firstName ? `Welcome back, ${firstName}` : "Welcome to UniBank"}
        </h1>

        <p className="mt-5 max-w-2xl text-lg leading-8 text-indigo-100">
          Manage your banking relationships from one unified customer profile.
          View your products, transactions, and connected services in one place.
        </p>
      </div>
    </section>
  );
}

export default CustomerHero;
