import { useState } from "react";
import {
  createCoreRecord,
  createCreditCard,
  createLoan,
} from "../api/customerApi";

/**
 * Inline "Add new details" form for the customer portal.
 * On submit the backend runs the usual process:
 *   1. check the golden table (phone OR email) -> existing / new
 *   2. save the raw record
 *   3. run matching -> linked to an existing GC-id or a new one is created
 */
const TYPES = {
  core: {
    label: "Core Banking",
    create: createCoreRecord,
    fields: [
      { name: "customerId", label: "Customer ID", placeholder: "CB001" },
      { name: "name", label: "Full Name", placeholder: "Rahul Sharma" },
      {
        name: "email",
        label: "Email",
        type: "email",
        placeholder: "rahul@gmail.com",
      },
      { name: "phone", label: "Phone", placeholder: "9876543210" },
      { name: "dob", label: "Date of Birth", type: "date" },
      {
        name: "address",
        label: "Address",
        placeholder: "12 MG Road, Hyderabad",
        wide: true,
      },
    ],
  },
  card: {
    label: "Credit Card",
    create: createCreditCard,
    fields: [
      { name: "custRef", label: "Customer Reference", placeholder: "CC001" },
      { name: "name", label: "Full Name", placeholder: "Rahul Sharma" },
      {
        name: "email",
        label: "Email",
        type: "email",
        placeholder: "rahul@gmail.com",
      },
      { name: "phone", label: "Phone", placeholder: "9876543210" },
      {
        name: "creditLimit",
        label: "Credit Limit",
        type: "number",
        placeholder: "150000",
      },
      {
        name: "address",
        label: "Address",
        placeholder: "12 MG Road, Hyderabad",
        wide: true,
      },
    ],
  },
  loan: {
    label: "Loan",
    create: createLoan,
    fields: [
      { name: "loanCustId", label: "Loan Customer ID", placeholder: "LN001" },
      { name: "name", label: "Full Name", placeholder: "Rahul Sharma" },
      { name: "phone", label: "Phone", placeholder: "9876543210" },
      {
        name: "loanAmount",
        label: "Loan Amount",
        type: "number",
        placeholder: "500000",
      },
      {
        name: "address",
        label: "Address",
        placeholder: "12 MG Road, Hyderabad",
        wide: true,
      },
    ],
  },
};

const ID_FIELD = { core: "customerId", card: "custRef", loan: "loanCustId" };
const NUMBER_FIELDS = ["creditLimit", "loanAmount"];

/** Turn what was typed in the search box into initial form values. */
function prefillFromQuery(query) {
  const term = (query || "").trim();
  if (!term) return {};
  if (term.includes("@")) return { email: term };
  if (/^[+\d\s()-]+$/.test(term) && term.replace(/\D/g, "").length >= 10) {
    return { phone: term };
  }
  if (/^gc-?\d+$/i.test(term)) return {};
  return { sourceId: term };
}

function emptyValues(type, prefill) {
  const values = {};
  for (const field of TYPES[type].fields)
    values[field.name] = prefill[field.name] || "";
  if (prefill.sourceId) values[ID_FIELD[type]] = prefill.sourceId;
  return values;
}

function AddDetailsForm({ initialQuery, onOpenProfile, onCancel }) {
  const prefill = prefillFromQuery(initialQuery);

  const [type, setType] = useState("core");
  const [values, setValues] = useState(() => emptyValues("core", prefill));
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const [result, setResult] = useState(null);

  const changeType = (nextType) => {
    // Keep what the user already typed in shared fields (name, phone, email, address).
    const next = emptyValues(nextType, prefill);
    for (const key of Object.keys(next)) {
      if (values[key]) next[key] = values[key];
    }
    setType(nextType);
    setValues(next);
    setFieldErrors({});
    setError("");
  };

  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    setFieldErrors({});
    setResult(null);

    const payload = { ...values };
    for (const key of NUMBER_FIELDS) {
      if (key in payload) payload[key] = Number(payload[key]);
    }

    try {
      const response = await TYPES[type].create(payload);
      setResult({
        message: response.message,
        goldenCustomerId: response.data.goldenCustomerId,
        status: response.data.goldenCheck?.status,
        trace: response.data.trace,
      });
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
      if (err.details && typeof err.details === "object")
        setFieldErrors(err.details);
    } finally {
      setSubmitting(false);
    }
  };

  if (result) {
    const isExisting =
      result.status === "existing" || result.status === "conflict";
    return (
      <div className="mt-6 rounded-xl border border-green-200 bg-green-50 p-5">
        <p className="text-sm font-semibold uppercase tracking-wide text-green-700">
          {isExisting ? "Existing customer" : "New customer"}
        </p>
        <p className="mt-1 text-green-800">{result.message}</p>

        {result.trace && <RecordTrace trace={result.trace} />}

        <div className="mt-4 flex flex-wrap gap-3">
          {result.goldenCustomerId && (
            <button
              type="button"
              onClick={() => onOpenProfile(result.goldenCustomerId)}
              className="rounded-xl bg-indigo-600 px-5 py-2.5 font-semibold text-white hover:bg-indigo-700"
            >
              Open profile {result.goldenCustomerId}
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setResult(null);
              setValues(emptyValues(type, {}));
            }}
            className="rounded-xl border border-gray-300 bg-white px-5 py-2.5 font-medium text-gray-700 hover:bg-gray-50"
          >
            Add more details
          </button>
        </div>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="mt-6 rounded-xl border border-indigo-100 bg-indigo-50/40 p-5"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-semibold text-gray-900">Add new details</h3>

        <div className="flex rounded-xl border border-gray-200 bg-white p-1 text-sm">
          {Object.entries(TYPES).map(([key, config]) => (
            <button
              key={key}
              type="button"
              onClick={() => changeType(key)}
              className={`rounded-lg px-3 py-1.5 font-medium ${
                type === key
                  ? "bg-indigo-600 text-white"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              {config.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        {TYPES[type].fields.map((field) => (
          <div key={field.name} className={field.wide ? "md:col-span-2" : ""}>
            <label
              htmlFor={`add-${field.name}`}
              className="mb-1 block text-sm font-medium text-gray-700"
            >
              {field.label}
            </label>
            <input
              id={`add-${field.name}`}
              name={field.name}
              type={field.type || "text"}
              value={values[field.name] ?? ""}
              onChange={handleChange}
              placeholder={field.placeholder}
              required
              aria-invalid={Boolean(fieldErrors[field.name])}
              className={`w-full rounded-xl border bg-white px-4 py-2.5 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 ${
                fieldErrors[field.name] ? "border-red-400" : "border-gray-300"
              }`}
            />
            {fieldErrors[field.name] && (
              <p className="mt-1 text-xs text-red-600">
                {fieldErrors[field.name]}
              </p>
            )}
          </div>
        ))}
      </div>

      {error && (
        <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">
          {error}
        </p>
      )}

      <div className="mt-5 flex justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-xl border border-gray-300 bg-white px-5 py-2.5 font-medium text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={submitting}
          className="rounded-xl bg-indigo-600 px-5 py-2.5 font-semibold text-white hover:bg-indigo-700 disabled:opacity-60"
        >
          {submitting ? "Checking & saving..." : "Submit"}
        </button>
      </div>
    </form>
  );
}

/**
 * Source trace for the record just submitted: per golden field, the value
 * before -> now, which source supplied it and why.
 */
function RecordTrace({ trace }) {
  const summary = trace.isNewCustomer
    ? "New profile created from this record."
    : trace.changedCount === 0
      ? "No profile values changed: existing sources rank higher for every field."
      : `${trace.changedCount} profile value${trace.changedCount === 1 ? "" : "s"} changed.`;

  return (
    <div className="mt-4 rounded-xl border border-green-200 bg-white">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-green-100 px-4 py-3">
        <p className="text-sm font-semibold text-gray-900">
          What this record changed
        </p>
        <p className="text-xs text-gray-500">{summary}</p>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wide text-gray-500">
            <tr>
              <th className="px-4 py-2 font-medium">Field</th>
              {!trace.isNewCustomer && (
                <th className="px-4 py-2 font-medium">Before</th>
              )}
              <th className="px-4 py-2 font-medium">Now</th>
              <th className="px-4 py-2 font-medium">Source</th>
              <th className="px-4 py-2 font-medium">Why</th>
            </tr>
          </thead>
          <tbody>
            {trace.fields.map((f) => (
              <tr
                key={f.field}
                className={`border-t border-gray-100 align-top ${
                  f.changed && !trace.isNewCustomer ? "bg-amber-50" : ""
                }`}
              >
                <td className="px-4 py-2 font-medium text-gray-800">
                  {f.label}
                </td>
                {!trace.isNewCustomer && (
                  <td className="px-4 py-2 text-gray-500">
                    {f.changed ? <s>{f.before ?? "—"}</s> : (f.before ?? "—")}
                  </td>
                )}
                <td className="px-4 py-2 text-gray-900">
                  {f.now ?? <span className="text-gray-400">—</span>}
                  {f.changed && !trace.isNewCustomer && (
                    <span className="ml-2 rounded bg-amber-200 px-1.5 py-0.5 text-xs font-semibold text-amber-900">
                      updated
                    </span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {f.sourceLabel ? (
                    <span
                      className={`whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ${
                        f.fromThisRecord
                          ? "bg-indigo-600 text-white"
                          : "bg-purple-100 text-purple-700"
                      }`}
                    >
                      {f.fromThisRecord ? "This record" : f.sourceLabel}
                    </span>
                  ) : (
                    <span className="text-xs text-gray-400">—</span>
                  )}
                </td>
                <td className="px-4 py-2 text-xs text-gray-600">{f.why}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AddDetailsForm;
