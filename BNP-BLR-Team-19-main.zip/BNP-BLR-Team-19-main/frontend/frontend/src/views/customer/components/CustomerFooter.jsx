function CustomerFooter() {
  return (
    <footer className="border-t border-gray-200 pt-8">

      <div className="flex flex-col justify-between gap-4 text-sm text-gray-500 md:flex-row">

        <div>
          <p className="font-semibold text-gray-800">
            UniBank MDM
          </p>

          <p className="mt-1">
            One customer. One trusted view.
          </p>
        </div>

        <div className="flex gap-6">
          <span>Customer 360</span>
          <span>Products</span>
          <span>Transactions</span>
        </div>

      </div>

      <p className="mt-8 border-t border-gray-100 pt-5 text-center text-xs text-gray-400">
        © 2026 UniBank MDM. Customer Portal.
      </p>

    </footer>
  );
}

export default CustomerFooter;