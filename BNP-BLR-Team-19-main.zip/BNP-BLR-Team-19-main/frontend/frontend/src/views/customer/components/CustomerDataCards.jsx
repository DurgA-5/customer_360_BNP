import { useEffect, useState } from "react";
import {
  getCustomerProducts,
  getCustomerTransactions,
} from "../api/customerApi";

function CustomerDataCards({ customerId }) {
  const [products, setProducts] = useState(null);
  const [transactions, setTransactions] = useState([]);

  const [loadingProducts, setLoadingProducts] = useState(true);
  const [loadingTransactions, setLoadingTransactions] = useState(true);

  const [error, setError] = useState("");

  useEffect(() => {
    if (!customerId) return;

    const loadData = async () => {
      try {
        setError("");
        setLoadingProducts(true);
        setLoadingTransactions(true);

        const [productsResponse, transactionsResponse] =
          await Promise.all([
            getCustomerProducts(customerId),
            getCustomerTransactions(customerId),
          ]);

        setProducts(productsResponse.data);
        setTransactions(
          transactionsResponse.data?.transactions || []
        );
      } catch (err) {
        console.error(err);
        setError(err.message || "Unable to load customer data.");
      } finally {
        setLoadingProducts(false);
        setLoadingTransactions(false);
      }
    };

    loadData();
  }, [customerId]);

  const accounts = products?.accounts || [];
  const cards = products?.creditCards || [];
  const loans = products?.loans || [];

  return (
    <section>

      <div className="mb-6">
        <p className="text-sm font-semibold uppercase tracking-wider text-indigo-600">
          Customer 360
        </p>

        <h2 className="mt-1 text-3xl font-bold text-gray-900">
          Your Data
        </h2>
      </div>

      {error && (
        <div className="mb-5 rounded-xl bg-red-50 p-4 text-red-700">
          {error}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">

        {/* PRODUCTS */}

        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-900">
                My Products
              </h3>

              <p className="mt-1 text-sm text-gray-500">
                Your connected banking relationships
              </p>
            </div>

            <span className="rounded-xl bg-indigo-50 px-3 py-2 text-xl">
              📦
            </span>
          </div>

          {loadingProducts ? (
            <p className="mt-8 text-gray-500">
              Loading products...
            </p>
          ) : (
            <div className="mt-6 space-y-3">

              <ProductRow
                title="Bank Accounts"
                count={accounts.length}
              />

              <ProductRow
                title="Credit Cards"
                count={cards.length}
              />

              <ProductRow
                title="Loans"
                count={loans.length}
              />

            </div>
          )}

        </div>

        {/* TRANSACTIONS */}

        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-900">
                Transactions
              </h3>

              <p className="mt-1 text-sm text-gray-500">
                Recent account activity
              </p>
            </div>

            <span className="rounded-xl bg-green-50 px-3 py-2 text-xl">
              💳
            </span>
          </div>

          {loadingTransactions ? (
            <p className="mt-8 text-gray-500">
              Loading transactions...
            </p>
          ) : transactions.length === 0 ? (
            <p className="mt-8 text-gray-500">
              No transactions available.
            </p>
          ) : (
            <div className="mt-5 space-y-3">

              {transactions.slice(0, 4).map((transaction) => (
                <div
                  key={transaction.id ?? transaction.transactionId}
                  className="flex items-center justify-between rounded-xl bg-gray-50 p-3"
                >
                  <div>
                    <p className="font-medium text-gray-900">
                      {transaction.type}
                    </p>

                    <p className="text-xs text-gray-500">
                      {transaction.transactionDate}
                    </p>
                  </div>

                  <p className="font-bold text-gray-900">
                    ₹{transaction.amount?.toLocaleString("en-IN")}
                  </p>
                </div>
              ))}

            </div>
          )}

        </div>

      </div>

    </section>
  );
}

function ProductRow({ title, count }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-gray-50 p-4">
      <span className="font-medium text-gray-700">
        {title}
      </span>

      <span className="rounded-full bg-indigo-100 px-3 py-1 text-sm font-bold text-indigo-700">
        {count}
      </span>
    </div>
  );
}

export default CustomerDataCards;