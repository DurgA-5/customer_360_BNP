function GoldenTruthCard({ customer, loading }) {
  if (loading) {
    return (
      <div className="rounded-2xl border border-yellow-200 bg-white p-6 shadow-sm">
        <div className="animate-pulse space-y-4">
          <div className="h-6 w-40 rounded bg-gray-200" />
          <div className="h-4 w-56 rounded bg-gray-200" />
          <div className="h-4 w-48 rounded bg-gray-200" />
          <div className="h-4 w-64 rounded bg-gray-200" />
        </div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50 p-6">
        <p className="font-medium text-red-700">
          Customer profile could not be loaded.
        </p>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-2xl border border-yellow-300 bg-gradient-to-br from-yellow-50 via-white to-amber-50 p-6 shadow-sm">

      <div className="absolute right-0 top-0 h-24 w-24 rounded-full bg-yellow-200/30 blur-2xl" />

      <div className="relative">

        <div className="mb-5 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-amber-600">
              Golden Truth
            </p>

            <h2 className="mt-1 text-2xl font-bold text-gray-900">
              Unified Customer Profile
            </h2>
          </div>

          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-yellow-400 text-xl shadow">
            ★
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-2">

          <ProfileField
            label="Customer ID"
            value={customer.goldenCustomerId}
          />

          <ProfileField
            label="Full Name"
            value={customer.name}
          />

          <ProfileField
            label="Email"
            value={customer.email}
          />

          <ProfileField
            label="Phone"
            value={customer.phone}
          />

          <ProfileField
            label="Date of Birth"
            value={customer.dob}
          />

          <ProfileField
            label="Address"
            value={customer.address}
          />

        </div>

        <div className="mt-6 flex items-center justify-between rounded-xl bg-white/80 p-4">

          <span className="text-sm text-gray-600">
            Profile completeness
          </span>

          <span className="font-bold text-amber-600">
            {customer.profileCompleteness ?? 0}%
          </span>

        </div>

      </div>
    </div>
  );
}

function ProfileField({ label, value }) {
  return (
    <div>
      <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
        {label}
      </p>

      <p className="mt-1 break-words font-medium text-gray-900">
        {value || "Not available"}
      </p>
    </div>
  );
}

export default GoldenTruthCard;