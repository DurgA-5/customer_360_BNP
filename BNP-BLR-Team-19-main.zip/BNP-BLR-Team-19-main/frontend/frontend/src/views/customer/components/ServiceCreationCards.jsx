import { useNavigate } from "react-router-dom";

const services = [
  {
    title: "Core Banking",
    description: "Create or connect your core banking customer account.",
    icon: "🏦",
    path: "/customer/core/create",
    button: "Open Core Form",
  },
  {
    title: "Credit Card",
    description: "Create a credit-card relationship for your customer profile.",
    icon: "💳",
    path: "/customer/credit-card/create",
    button: "Open Card Form",
  },
  {
    title: "Loan",
    description: "Create and connect a loan relationship to your profile.",
    icon: "💰",
    path: "/customer/loan/create",
    button: "Open Loan Form",
  },
];

/** @param {{ prefill?: { phone?: string, email?: string } }} props */
function ServiceCreationCards({ prefill } = {}) {
  const navigate = useNavigate();

  return (
    <section>
      <div className="mb-6">
        <p className="text-sm font-semibold uppercase tracking-wider text-indigo-600">
          Services
        </p>

        <h2 className="mt-1 text-3xl font-bold text-gray-900">
          Create or Connect
        </h2>

        <p className="mt-2 text-gray-600">
          Connect your banking relationships to your unified customer profile.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {services.map((service) => (
          <div
            key={service.title}
            className="group rounded-2xl border border-gray-200 bg-white p-6 shadow-sm transition duration-200 hover:-translate-y-1 hover:border-indigo-300 hover:shadow-lg"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-2xl">
              {service.icon}
            </div>

            <h3 className="mt-5 text-xl font-bold text-gray-900">
              {service.title}
            </h3>

            <p className="mt-2 min-h-12 text-sm leading-6 text-gray-600">
              {service.description}
            </p>

            <button
              onClick={() => navigate(withPrefill(service.path, prefill))}
              className="mt-6 w-full rounded-xl bg-indigo-600 px-4 py-3 font-semibold text-white transition hover:bg-indigo-700"
            >
              {service.button}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

function withPrefill(path, prefill) {
  if (!prefill) return path;
  const params = new URLSearchParams();
  if (prefill.phone) params.set("phone", prefill.phone);
  if (prefill.email) params.set("email", prefill.email);
  const query = params.toString();
  return query ? `${path}?${query}` : path;
}

export default ServiceCreationCards;
