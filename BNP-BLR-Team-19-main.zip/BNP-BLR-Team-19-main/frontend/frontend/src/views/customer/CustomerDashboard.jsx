import { useEffect, useState } from "react";
import { useLocation, useSearchParams } from "react-router-dom";

import CustomerHero from "./components/CustomerHero";
import GoldenTruthCard from "./components/GoldenTruthCard";
import ServiceCreationCards from "./components/ServiceCreationCards";
import CustomerDataCards from "./components/CustomerDataCards";
import CustomerFooter from "./components/CustomerFooter";
import AddDetailsForm from "./components/AddDetailsForm";

import { getCustomerProfile, searchCustomer } from "./api/customerApi";
import {
  clearStoredCustomerId,
  getStoredCustomerId,
  storeCustomerId,
} from "./customerSession";

function CustomerDashboard() {
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  // Until authentication exists: ?id=GC-12 in the URL, else the last id used on this device.
  const customerId = searchParams.get("id") || getStoredCustomerId();

  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(Boolean(customerId));
  const [error, setError] = useState("");
  const [prefill, setPrefill] = useState(null);
  const flash = location.state?.flash;

  useEffect(() => {
    if (!customerId) {
      setLoading(false);
      return;
    }

    let cancelled = false;

    const loadCustomer = async () => {
      try {
        setLoading(true);
        setError("");

        const response = await getCustomerProfile(customerId);
        if (cancelled) return;

        setCustomer(response.data);
        storeCustomerId(response.data.goldenCustomerId);
      } catch (err) {
        if (cancelled) return;
        console.error(err);
        setCustomer(null);
        if (err.status === 404) clearStoredCustomerId();
        setError(
          err.status === 404
            ? `We couldn't find customer ${customerId}.`
            : err.message || "Unable to load customer profile.",
        );
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadCustomer();

    return () => {
      cancelled = true;
    };
  }, [customerId]);

  const openProfile = (goldenCustomerId) => {
    setPrefill(null);
    setError("");
    setSearchParams({ id: goldenCustomerId });
  };

  const signOut = () => {
    clearStoredCustomerId();
    setCustomer(null);
    setError("");
    setSearchParams({});
  };

  const showFinder = !customerId || Boolean(error);

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="mx-auto max-w-7xl space-y-10 px-5 py-8 md:px-8">
        <CustomerHero customer={customer} />

        {flash && (
          <div className="rounded-xl bg-green-50 p-4 text-green-700">
            {flash}
          </div>
        )}

        {error && (
          <div className="rounded-xl bg-red-50 p-4 text-red-700">{error}</div>
        )}

        {showFinder ? (
          <FindProfile onOpen={openProfile} onNotFound={setPrefill} />
        ) : (
          <>
            <GoldenTruthCard customer={customer} loading={loading} />
            <p className="-mt-6 text-right text-sm">
              <button
                type="button"
                onClick={signOut}
                className="text-gray-500 hover:text-gray-800 hover:underline"
              >
                Not you? Look up a different profile
              </button>
            </p>
          </>
        )}

        <ServiceCreationCards prefill={prefill} />

        {customer && !showFinder && (
          <CustomerDataCards customerId={customer.goldenCustomerId} />
        )}

        <CustomerFooter />
      </main>
    </div>
  );
}

/**
 * Find your profile:
 *   Search  - by customer ID (GC-1 or a bank ID like CB001 / CC001 / LN001),
 *             phone or email -> list of matching golden customers -> Open
 *   Add     - enter new details (Core Banking / Credit Card / Loan) -> golden check
 *             -> save -> matching -> linked to an existing or a new customer
 */
function FindProfile({ onOpen, onNotFound }) {
  const [query, setQuery] = useState("");
  // The term of the last completed search (the live input can change while the form is open).
  const [searchedTerm, setSearchedTerm] = useState("");
  const [searching, setSearching] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const handleSearch = async (event) => {
    event.preventDefault();
    setError("");
    setResult(null);

    const term = query.trim();
    if (!term) {
      setError("Enter your customer ID, phone number or email.");
      return;
    }

    try {
      setSearching(true);
      const response = await searchCustomer(term);
      setResult(response.data);
      setSearchedTerm(term);
      if (!response.data.found) onNotFound?.(prefillFor(term));
    } catch (err) {
      setError(err.message || "Unable to search right now. Please try again.");
    } finally {
      setSearching(false);
    }
  };

  return (
    <section className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Find your profile</h2>
          <p className="mt-1 text-sm text-gray-500">
            Search with your customer ID (for example GC-1, CB001, CC001 or
            LN001), phone number or email.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAdd((open) => !open)}
          className="rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-100"
        >
          {showAdd ? "Close form" : "+ Add new details"}
        </button>
      </div>

      <form onSubmit={handleSearch} className="mt-5 flex max-w-2xl gap-3">
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Customer ID, phone or email"
          className="flex-1 rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
        />
        <button
          type="submit"
          disabled={searching}
          className="rounded-xl bg-indigo-600 px-6 py-3 font-semibold text-white hover:bg-indigo-700 disabled:opacity-60"
        >
          {searching ? "Searching..." : "Search"}
        </button>
      </form>

      {error && <p className="mt-4 text-sm text-red-600">{error}</p>}

      {result?.found && (
        <ul className="mt-5 divide-y divide-gray-100 rounded-xl border border-gray-200">
          {result.customers.map((customer) => (
            <li
              key={customer.goldenCustomerId}
              className="flex flex-wrap items-center justify-between gap-3 px-4 py-3"
            >
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <span className="rounded-md bg-indigo-50 px-2 py-1 font-semibold text-indigo-700">
                  {customer.goldenCustomerId}
                </span>
                <span className="font-medium text-gray-900">
                  {customer.firstName || "Customer"}
                </span>
                {customer.phone && (
                  <span className="text-gray-500">{customer.phone}</span>
                )}
                {customer.email && (
                  <span className="text-gray-500">{customer.email}</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => onOpen(customer.goldenCustomerId)}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700"
              >
                Open
              </button>
            </li>
          ))}
        </ul>
      )}

      {result && !result.found && (
        <div className="mt-5 rounded-xl bg-amber-50 p-4 text-sm text-amber-800">
          {result.pendingMatch ? (
            <p>
              We found your {result.sources?.join(" / ")} record, but it
              isn&apos;t linked to a customer profile yet. Please try again in a
              moment.
            </p>
          ) : (
            <>
              <p className="font-semibold">
                No profile found for &quot;{searchedTerm}&quot;.
              </p>
              <p className="mt-1">
                Add your details and we&apos;ll create or link your customer
                profile.
              </p>
              {!showAdd && (
                <button
                  type="button"
                  onClick={() => setShowAdd(true)}
                  className="mt-3 rounded-lg bg-amber-600 px-4 py-2 font-semibold text-white hover:bg-amber-700"
                >
                  + Add new details
                </button>
              )}
            </>
          )}
        </div>
      )}

      {showAdd && (
        <AddDetailsForm
          key={searchedTerm}
          initialQuery={result && !result.found ? searchedTerm : ""}
          onOpenProfile={onOpen}
          onCancel={() => setShowAdd(false)}
        />
      )}
    </section>
  );
}

/** Phone / email typed in the search box, reused to pre-fill the product forms. */
function prefillFor(term) {
  if (term.includes("@")) return { email: term };
  if (term.replace(/\D/g, "").length >= 10) return { phone: term };
  return null;
}

export default CustomerDashboard;
