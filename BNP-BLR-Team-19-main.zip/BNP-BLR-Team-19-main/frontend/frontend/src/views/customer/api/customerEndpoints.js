export const customerEndpoints = {
  lookup: "/customers/lookup",

  profile: (id) => `/customers/${id}`,

  products: (id) => `/customers/${id}/products`,

  transactions: (id) => `/customers/${id}/transactions`,

  createCore: "/sources/core-banking",

  createCreditCard: "/sources/credit-card",

  createLoan: "/sources/loan",
};
