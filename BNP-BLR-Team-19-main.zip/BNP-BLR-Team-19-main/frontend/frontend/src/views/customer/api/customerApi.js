import apiClient from "../../../services/apiClient.js";
import { customerEndpoints } from "./customerEndpoints";

export const getCustomerProfile = async (customerId) => {
  const response = await apiClient.get(customerEndpoints.profile(customerId));
  return response.data;
};

export const getCustomerProducts = async (customerId) => {
  const response = await apiClient.get(customerEndpoints.products(customerId));
  return response.data;
};

export const getCustomerTransactions = async (customerId) => {
  const response = await apiClient.get(
    customerEndpoints.transactions(customerId),
  );
  return response.data;
};

export const createCoreRecord = async (payload) => {
  const response = await apiClient.post(customerEndpoints.createCore, payload);
  return response.data;
};

export const createCreditCard = async (payload) => {
  const response = await apiClient.post(
    customerEndpoints.createCreditCard,
    payload,
  );
  return response.data;
};

export const createLoan = async (payload) => {
  const response = await apiClient.post(customerEndpoints.createLoan, payload);
  return response.data;
};

/** Check the golden table by phone and/or email: { found, status, customers } */
export const lookupCustomer = async ({ phone, email }) => {
  const response = await apiClient.post(customerEndpoints.lookup, {
    phone: phone || undefined,
    email: email || undefined,
  });
  return response.data;
};

/**
 * One search box: golden id (GC-1), bank id (CB001 / CC001 / LN001),
 * phone or email. Returns { found, status, searchType, customers, pendingMatch }.
 */
export const searchCustomer = async (query) => {
  const response = await apiClient.post(customerEndpoints.lookup, { query });
  return response.data;
};
